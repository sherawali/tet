# UTET 2025 — Paper I (कक्षा 1–5) — प्रश्न पुस्तिका XXV-1, SET-B

## खण्ड 4 : गणित / Mathematics
**प्रश्न 91 – 120** | प्रत्येक प्रश्न 1 अंक

---

**91.** एक व्यक्ति A से B तक 20 किमी/घंटे तथा B से A तक 30 किमी/घंटे की गति से जाता है। उसकी औसत चाल ........ किमी/घंटा होगी।
*A person moves from A to B with a speed of 20 km/hr while from B to A with 30 km/hr. His average speed will be ........ km/hr.*

- (A) 25
- (B) 22
- (C) 24 ✅
- (D) 26

**उत्तर : (C)**  *(2×20×30/50 = 24)*

---

**92.** माना y का साधारण ब्याज x तथा z का साधारण ब्याज y है। दोनों स्थितियों में दर प्रतिशत तथा समय समान है। तब x, y, z में सम्बन्ध है –
*If simple interest of y is x while that of z is y for the same period with same rate, then relation among x, y, z is :*

- (A) z = xy
- (B) z² = xy
- (C) x² = yz
- (D) y² = xz ✅

**उत्तर : (D)**

---

**93.** गणित शिक्षण में सबसे महत्त्वपूर्ण पहलू क्या है?
*Most important thing in Mathematics teaching is :*

- (A) प्रक्रिया याद रखना / remembering process
- (B) सूत्र याद करना / remembering formulae
- (C) सही उत्तर प्राप्त करना / to find exact answer
- (D) अवधारणात्मक समझ / conceptual clarity ✅

**उत्तर : (D)**

---

**94.** निम्नलिखित अनुक्रम में अगला पद होगा : **2, 6, 12, 20, ........**
*Next term in the following sequence will be :*

- (A) 28
- (B) 30 ✅
- (C) 32
- (D) 36

**उत्तर : (B)**  *(अंतर 4, 6, 8, 10 ⟹ 20 + 10 = 30)*

---

**95.** त्रिभुज के लिए सदैव सत्य कथन होगा –
*For a triangle, a true statement will be :*

- (A) त्रिभुज के सभी कोण सदैव न्यूनकोण होते हैं।
- (B) एक कोण सदैव अधिक कोण होता है।
- (C) एक कोण सदैव समकोण होता है।
- (D) कम से कम दो कोण सदैव न्यूनकोण होंगे। ✅

**उत्तर : (D)**

---

**96.** A एक काम को 15 दिन तथा B उसी काम को 10 दिनों में करता है। एक साथ मिलकर दोनों इस काम को कितने दिनों में समाप्त कर सकते हैं?
*A completes some work in 15 days while B in 10 days. Together they will finish in :*

- (A) 8.6 दिन
- (B) 5 दिन
- (C) 6 दिन ✅
- (D) 7 दिन

**उत्तर : (C)**  *(1/15 + 1/10 = 1/6)*

---

**97.** यदि 6 व्यक्ति प्रतिदिन 8 घंटे काम करके एक सप्ताह में ₹8400 कमाते हैं, तो 9 व्यक्ति प्रतिदिन 6 घंटे काम करके एक सप्ताह में कितना कमायेंगे?
*If 6 people earn ₹8400 in a week doing 8 hours work daily, how much will 9 people earn weekly doing 6 hours daily?*

- (A) 9800
- (B) 9700
- (C) 9500
- (D) 9450 ✅

**उत्तर : (D)**  *(8400 × 54/48 = 9450)*

---

**98.** यदि एक बच्चे ने सीखा कि : "सभी वर्ग, आयत हैं लेकिन सभी आयत, वर्ग नहीं हैं।" यह बताता है कि बच्चे ने –
*This indicates that the child has :*

- (A) ज्यामितीय आकारों तथा चित्रों के अन्तर्सम्बन्ध को समझा है / recognized the relationship between types of geometrical shapes and figures ✅
- (B) ज्यामितीय आकारों को ही समझा है
- (C) चित्र को समझा है
- (D) आयत तथा वर्ग की परिभाषा याद की है

**उत्तर : (A)**

---

**99.** यदि आयत की एक भुजा को 20% बढ़ाया जाता है तथा दूसरी भुजा को 5% बढ़ाया जाता है, तो क्षेत्रफल में प्रतिशत परिवर्तन होगा –
*If one side of a rectangle is increased by 20% and the other by 5%, percentage change in area will be :*

- (A) 15%
- (B) 20%
- (C) 26% ✅
- (D) 25%

**उत्तर : (C)**  *(1.20 × 1.05 = 1.26)*

---

**100.** यदि x संख्याओं का औसत y हो तथा y संख्याओं का औसत x हो, तो सभी संख्याओं का औसत होगा –
*If average of x numbers is y while that of y numbers is x, then average of all numbers is :*

- (A) (x + y)/2
- (B) xy
- (C) 2xy/(x + y) ✅
- (D) इनमें से कोई नहीं / None of these

**उत्तर : (C)**

---

**101.** एक टंकी में दो पाइप A तथा B लगे हैं। पाइप A टंकी को 2 घंटे में तथा B, 3 घंटे में भर सकता है। यदि दोनों पाइपों को एक साथ खोला जाये, तो टंकी कितने समय में भर जायेगी?
*Pipe A can fill a tank in 2 hours while B in 3 hours. If both are opened simultaneously, tank will be filled in :*

- (A) 1 घंटा 12 मिनट ✅
- (B) 2 घंटा 30 मिनट
- (C) 1 घंटा
- (D) 1 घंटा 21 मिनट

**उत्तर : (A)**  *(6/5 घंटे)*

---

**102.** 110 मी लम्बी ट्रेन, स्टेशन को 36 किमी/घंटे की चाल से पार करती है। एक बिन्दु को पार करने में समय लगेगा –
*A 110 m long train with speed 36 km/hr will cross a point in :*

- (A) 11 सेकण्ड ✅
- (B) 10 सेकण्ड
- (C) 9 सेकण्ड
- (D) 2 सेकण्ड

**उत्तर : (A)**  *(36 km/hr = 10 m/s; 110/10 = 11 s)*

---

**103.** गणित में यदि शिक्षक को "चक्रवृद्धि ब्याज" के बारे में पढ़ाना है, तो इसके अधिगम उद्देश्य होंगे –
*Learning objectives for teaching "compound interest" should be :*

- (A) मात्र विश्लेषण / analysis only
- (B) मात्र बोध / comprehension only
- (C) ज्ञान, बोध तथा अनुप्रयोग / knowledge, comprehension and application ✅
- (D) मात्र संश्लेषण / synthesis only

**उत्तर : (C)**

---

**104.** निम्नलिखित में से कौन-से अध्ययन में "उपचारात्मक शिक्षण" को "आत्मसात्करण" भी कहा जाता है?
*Which study for "remedial teaching" is also known as "assimilation"?*

- (A) ट्यूटोरियल / Tutorial
- (B) पर्यवेक्षित अध्ययन / Supervised study ✅
- (C) क्रियात्मक अनुसंधान / Action research
- (D) व्याख्यान शिक्षण / Lecture teaching

**उत्तर : (B)**

---

**105.** "एक दिये हुए चित्र में कुल आयतों की संख्या गिनिए" — यह प्रश्न जाँच करता है –
*"Count total number of rectangles in a given figure." This question tests :*

- (A) शिक्षार्थी की समझ का / understanding of learner ✅
- (B) शिक्षार्थी के ज्ञान का / knowledge of learner
- (C) शिक्षार्थी की रचनाशीलता का / creativity of learner
- (D) शिक्षार्थी की याददाश्त का / memory of learner

**उत्तर : (A)**

---

**106.** ₹15 प्रति किग्रा वाली चीनी को, ₹20 प्रति किग्रा चीनी के साथ 2 : 3 में मिलाया गया, तो मिश्रण का प्रति किग्रा मूल्य होगा –
*Sugar of ₹15/kg is mixed with sugar of ₹20/kg in the ratio 2 : 3, then per kg rate of mixture is :*

- (A) ₹17
- (B) ₹18 ✅
- (C) ₹16
- (D) ₹19

**उत्तर : (B)**  *((30 + 60)/5 = 18)*

---

**107.** एक समबाहु त्रिभुज के अन्तःकेन्द्र, परिकेन्द्र तथा लम्बकेन्द्र होते हैं –
*Incentre, circumcentre and orthocentre of an equilateral triangle are :*

- (A) संपाती / Coincident ✅
- (B) संरेख / Collinear
- (C) संचक्रीय / Concyclic
- (D) इनमें से कोई नहीं / None of these

**उत्तर : (A)**

---

**108.** निम्नलिखित में से कौन केन्द्रीय प्रवृत्ति की माप **नहीं** है?
*Which of the following is not the measure of central tendency?*

- (A) परास / Range ✅
- (B) माध्य / Mean
- (C) बहुलक / Mode
- (D) माध्यिका / Median

**उत्तर : (A)**

---

**109.** एक संख्या का 20% यदि 240 है, तो इसी संख्या का 120% होगा –
*If 20% of a number is 240, then 120% of the same number will be :*

- (A) 1440 ✅
- (B) 1400
- (C) 1450
- (D) 1460

**उत्तर : (A)**  *(संख्या = 1200)*

---

**110.** यदि दो संख्याओं का योग एवं गुणनफल क्रमशः 25 तथा 144 हों, तो उनका अन्तर होगा –
*If sum and product of two numbers are 25 and 144 respectively, their difference will be :*

- (A) 8
- (B) 7 ✅
- (C) 6
- (D) 5

**उत्तर : (B)**  *(16 और 9)*

---

**111.** गणित शिक्षण में "मूल्यांकन" का क्या महत्त्व है?
*Importance of 'Evaluation' in Mathematics teaching is :*

- (A) छात्रों की प्रगति का आकलन / evaluation of progress of students
- (B) शिक्षण विधि का मूल्यांकन / evaluation of teaching methodology
- (C) पाठ्यक्रम में सुधार / improvement in syllabus
- (D) उपर्युक्त सभी / all of these ✅

**उत्तर : (D)**

---

**112.** समान्तर चतुर्भुज का एक कोण अपने सबसे नजदीकी (संलग्न) कोण का दो-तिहाई है। समान्तर चतुर्भुज का न्यूनतम कोण होगा –
*If an angle of a parallelogram is two-third of its adjacent angle, then the smallest angle is :*

- (A) 108°
- (B) 72° ✅
- (C) 36°
- (D) 90°

**उत्तर : (B)**

---

**113.** तीन क्रमिक छूटों 20%, 10% और 5% का एक समतुल्य छूट होगी –
*Equivalent discount of three successive discounts of 20%, 10% and 5% will be :*

- (A) 30%
- (B) 35%
- (C) 31.6% ✅
- (D) 25%

**उत्तर : (C)**  *(0.8 × 0.9 × 0.95 = 0.684)*

---

**114.** एक नाविक धारा की दिशा में 5 मिनट में 1 किमी चलता है, जबकि धारा के विपरीत 1 घंटे में 6 किमी। धारा की चाल ........ किमी/घंटे है।
*A sailor covers 1 km in 5 min along the stream while 6 km in 1 hour against the stream. Speed of stream is :*

- (A) 3 ✅
- (B) 2
- (C) 9
- (D) 4

**उत्तर : (A)**  *(अनुप्रवाह 12, प्रतिकूल 6 ⟹ (12−6)/2 = 3)*

---

**115.** यदि किसी त्रिभुज की तीनों भुजाओं के मध्य बिन्दुओं को मिलाया जाये, तो 4 त्रिभुज बनते हैं, जिनमें से प्रत्येक –
*The line segments joining the mid points of the sides of a triangle form four triangles, each of which is :*

- (A) मूल त्रिभुज के सर्वांगसम होगा / congruent to original triangle
- (B) समबाहु त्रिभुज होगा / equilateral triangle
- (C) मूल त्रिभुज के समरूप होगा / similar to original triangle ✅
- (D) समद्विबाहु त्रिभुज होगा / isosceles triangle

**उत्तर : (C)**

---

**116.** 1 से 199 के बीच 13 से विभाजित होने वाले पूर्णांकों का औसत होगा –
*Average of integers divisible by 13, between 1 & 199 is :*

- (A) 97
- (B) 99
- (C) 107
- (D) 104 ✅

**उत्तर : (D)**  *((13 + 195)/2 = 104)*

---

**117.** एक बैग में 50 पैसे, 25 पैसे, 20 पैसे तथा 5 पैसे के सिक्कों की संख्या बराबर है। यदि कुल राशि ₹40 हो, तो प्रत्येक प्रकार के सिक्कों की संख्या होगी –
*There are equal numbers of coins of 50, 25, 20 and 5 paise. If total amount is ₹40, then number of each type of coin is :*

- (A) 35
- (B) 45
- (C) 40 ✅
- (D) 42

**उत्तर : (C)**  *(n × 100 पैसे = 4000 पैसे)*

---

**118.** गणित को रुचिकर बनाने के लिए शिक्षक को क्या करना चाहिए?
*To make mathematics interesting, what should a teacher do?*

- (A) केवल कठिन प्रश्नों को हल करना चाहिए
- (B) पहेली, खेल, कहानी का उपयोग ✅
- (C) कक्षा में सख्त अनुशासन का माहौल
- (D) इनमें से कोई नहीं

**उत्तर : (B)**

---

**119.** किस वार्षिक चक्रवृद्धि ब्याज की दर से ₹625, दो वर्ष में ₹676 हो जायेंगे?
*At which rate of compound interest will ₹625 become ₹676 in two years?*

- (A) 5%
- (B) 4% ✅
- (C) 2%
- (D) 6%

**उत्तर : (B)**  *((1+r)² = 676/625 = 1.0816)*

---

**120.** एक वस्तु को ₹240 में बेचने पर व्यक्ति को 10% की हानि होती है। अब वह इसे कितने में बेचे, जिससे उसे 20% का लाभ हो?
*On selling an article at ₹240, a person has 10% loss. What should be the selling price to get 20% profit?*

- (A) 330
- (B) 290
- (C) 320 ✅
- (D) 300

**उत्तर : (C)**  *(क्रय मूल्य = 240/0.9 = 266.67; 20% लाभ ⟹ 320)*

---

*खण्ड 4 (गणित) समाप्त*
