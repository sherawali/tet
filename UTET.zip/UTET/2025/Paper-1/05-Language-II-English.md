# UTET 2025 — Paper I (Class I–V) — Booklet XXV-1, SET-B

## Section 3 : Second Language — English
**Questions 61 – 90** | 1 mark each

---

**61.** I can't **bear** this heat.
Identify the part of speech of the underlined word :

- (A) Verb ✅
- (B) Noun
- (C) Adjective
- (D) Pronoun

**Answer : (A)**

---

### Direction (Q. No. 62 & 63) :
Fill in the blanks with appropriate preposition.

**62.** He has been absent ............ Monday.

- (A) since ✅
- (B) at
- (C) in
- (D) for

**Answer : (A)**

---

**63.** She congratulated me ............ my success.

- (A) in
- (B) at
- (C) since
- (D) on ✅

**Answer : (D)**

---

### Direction (Q. No. 64 to 68) :
Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> There exists a language older than words, spoken not through the tongue but through textures, colours, rhythms and silences. It is the language of nature — a soft, persistent whisper that surrounds us, though few have the patience to listen. In the rustling of leaves, the migration of birds, the bloom of a lone flower amidst a barren field, nature offers a narrative both timeless and ever-changing. At dawn, the sky does not shout but blushes in subtle hues of amber and rose, as though shy to announce the new day. Trees sway not with urgency but with quiet grace, teaching that strength and stillness are not opposing forces. The river, unhurried, carries through mountains and meadows alike, murmuring ancient truths about perseverance and purpose. Even the decay of autumn, so often associated with death, carries within it the promise of renewal, of a spring yet to come. Yet, in our rush to modernize, we have dulled our senses to these subtle signs. We measure success in speed and numbers, often forgetting that not all value can be calculated. Technology may have extended our reach, but it has also narrowed our gaze.

---

**64.** What does the phrase "a language older than words" suggest about nature?

- (A) Nature communicating through ancient scripts
- (B) Nature uses sounds and words we don't yet understand
- (C) Nature expresses itself through non-verbal, timeless means ✅
- (D) Nature only communicates with animals

**Answer : (C)**

---

**65.** What quality of trees is emphasized in the line "Trees sway not with urgency but with quiet grace"?

- (A) Their unpredictable nature
- (B) Their aggressive growth
- (C) Their violent reaction to wind
- (D) Their calm strength and balance ✅

**Answer : (D)**

---

**66.** What lesson does the river teach?

- (A) That speed is essential to success
- (B) That water is the strongest element in nature
- (C) That perseverance and purpose matter more than haste ✅
- (D) That mountains can be easily eroded

**Answer : (C)**

---

**67.** What literary device is used in "the sky ........ blushes in subtle hues of amber and rose"?

- (A) Irony
- (B) Simile
- (C) Metaphor
- (D) Personification ✅

**Answer : (D)**

---

**68.** Identify the literary device in the phrase : "There exists a language older than words".

- (A) Simile
- (B) Metaphor ✅
- (C) Hyperbole
- (D) Alliteration

**Answer : (B)**

---

**69.** Which of the following is spelt correctly?

- (A) Comittment
- (B) Neccessary
- (C) Sucessful
- (D) Occasion ✅

**Answer : (D)**

---

**70.** The audio-lingual method is based largely on :

- (A) Behaviourist theory of habit formation ✅
- (B) Cognitive theory
- (C) Sociocultural theory
- (D) Constructivist learning

**Answer : (A)**

---

### Direction (Q. No. 71 & 72) :
Substitute the following phrases with the most appropriate word.

**71.** A speech delivered without preparation :

- (A) Extempore ✅
- (B) Monologue
- (C) Dialogue
- (D) Sermon

**Answer : (A)**

---

**72.** A person who loves mankind :

- (A) Humanitarian
- (B) Philanthropist ✅
- (C) Altruist
- (D) Social worker

**Answer : (B)**

---

**73.** Which is an example of productive skill?

- (A) Reading a newspaper
- (B) Listening to a lecture
- (C) Writing an essay ✅
- (D) Understanding a story

**Answer : (C)**

---

**74.** Which of the following skills is considered receptive in language learning?

- (A) speaking
- (B) writing
- (C) reading ✅
- (D) pronunciation

**Answer : (C)**

---

**75.** The idiom "to spill the beans" means :

- (A) To waste food
- (B) To reveal a secret ✅
- (C) To create a mess
- (D) To cook something

**Answer : (B)**

---

**76.** Choose the correct form of tense :
*By the time she arrives, we .......... our lunch.*

- (A) finish
- (B) finished
- (C) will have finished ✅
- (D) will finish

**Answer : (C)**

---

**77.** The idiom "Burn the midnight oil" means :

- (A) Waste resources
- (B) Work late into the night ✅
- (C) Sleep late
- (D) Stay up chatting

**Answer : (B)**

---

**78.** Select the synonym of "Sagacious" :

- (A) Foolish
- (B) Wise ✅
- (C) Ignorant
- (D) Weak

**Answer : (B)**

---

**79.** Turn the following into indirect speech :
*Ravi said, "I might visit my uncle tomorrow."*

- (A) Ravi said that he might visit his uncle tomorrow.
- (B) Ravi said that he might visit his uncle the next day. ✅
- (C) Ravi said that he may visit his uncle the next day.
- (D) Ravi said that I might visit my uncle the next day.

**Answer : (B)**

---

**80.** Change the given active sentence into passive :
*The teacher is explaining the lesson.*

- (A) The lesson explained by the teacher.
- (B) The lesson was being explained by the teacher.
- (C) The lesson is being explained by the teacher. ✅
- (D) The lesson is explained by the teacher.

**Answer : (C)**

---

### Direction (Q. No. 81 to 85) :
Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> Technological advancement has undeniably transformed human life, often for the better. Innovations in medicine, communications and transportation have expanded horizons and improved living standards. Yet, there remains an underlying paradox: as societies become more technologically advanced, individuals often report feeling more disconnected, anxious and overwhelmed. This contradiction is not merely anecdotal. Numerous studies suggest a correlation between digital dependency and declining mental well-being. The convenience of instant communication, for instance, has paradoxically eroded the depth of interpersonal relationships. Similarly, the promise of efficiency brought by automation and artificial intelligence has, in some sectors, resulted in job displacement and a growing sense of purposelessness. Moreover, the constant pursuit of progress has fostered a culture of perpetual urgency. The pressure to stay updated, to be productive and to remain relevant has blurred the boundaries between personal and professional lives. Instead of liberating individuals, modern technologies often act as invisible shackles, tethering them to devices and schedules.

---

**81.** What is the central paradox discussed in the passage?

- (A) Technology improves life but also increases stress and disconnection. ✅
- (B) Innovation always leads to job creation.
- (C) Progress eliminates the need for interpersonal relationships.
- (D) Mental health is unaffected by digital usage.

**Answer : (A)**

---

**82.** According to the passage, how has instant communication affected relationships?

- (A) It has made them stronger and more intimate.
- (B) It has made communication obsolete.
- (C) It has reduced the depth of human connection. ✅
- (D) It has no significant effect.

**Answer : (C)**

---

**83.** What does the author imply by calling modern technologies "invisible shackles"?

- (A) They are physically dangerous.
- (B) They limit freedom subtly, without people realizing it. ✅
- (C) They are easily removed.
- (D) They are easily destroyed.

**Answer : (B)**

---

**84.** What is the antonym of the word "perpetual"?

- (A) everlasting
- (B) temporary ✅
- (C) eternal
- (D) constant

**Answer : (B)**

---

**85.** What is the synonym of the word "tethering"?

- (A) unleash
- (B) unfasten
- (C) tying ✅
- (D) releasing

**Answer : (C)**

---

### Direction (Q. No. 86) :
Fill in the blank by selecting the appropriate option.

**86.** I prefer tea ............ coffee in the morning.

- (A) over
- (B) than
- (C) to ✅
- (D) for

**Answer : (C)**

---

**87.** Choose the most appropriate articles :
*He goes to ........ school in ........ next town.*

- (A) a, the ✅
- (B) the, a
- (C) an, a
- (D) a, a

**Answer : (A)**

---

**88.** Which method is most closely linked to kinesthetic learning?

- (A) Direct method
- (B) Total Physical Response ✅
- (C) Grammar translation method
- (D) Silent way

**Answer : (B)**

---

**89.** The Silent Way method encourages :

- (A) Teacher speaking most of the time
- (B) Learners discovering language rules independently ✅
- (C) Heavy use of translation
- (D) Rote memorization of dialogues

**Answer : (B)**

---

**90.** Code switching means :

- (A) Mixing two or more languages in speech ✅
- (B) Switching from writing
- (C) Changing a story's plot
- (D) Speaking in a louder voice

**Answer : (A)**

---

*End of Section 3 (Second Language – English)*
