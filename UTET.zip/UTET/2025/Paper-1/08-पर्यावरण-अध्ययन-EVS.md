# UTET 2025 — Paper I (कक्षा 1–5) — प्रश्न पुस्तिका XXV-1, SET-B

## खण्ड 5 : पर्यावरण अध्ययन / Environmental Studies
**प्रश्न 121 – 150** | प्रत्येक प्रश्न 1 अंक

---

**121.** इनमें से कौन-सा पवित्र उपवन विभिन्न जंगली पौधों के लिए जीन बैंक के रूप में कार्य करता है?
*Which of these sacred groves acts as the gene bank for various wild plants?*

- (A) मौहक / Mauhak
- (B) देवराय / Deorais ✅
- (C) जाहेरा / Jahera
- (D) इनमें से कोई नहीं / None of these

**उत्तर : (B)**

---

**122.** निम्नलिखित में से किस क्षेत्र में अधिकतम विविधता है?
*Which of the following regions has the maximum diversity?*

- (A) मैंग्रोव / Mangroves
- (B) समशीतोष्ण वन / Temperate forest
- (C) टैगा / Taiga
- (D) प्रवाल भित्तियाँ / Coral reefs ✅

**उत्तर : (D)**

---

**123.** राइनो डीएनए इंडेक्स सिस्टम (RhoDIS) किस मन्त्रालय द्वारा प्रारम्भ किया गया था?
*Rhino DNA Index System (RhoDIS) was launched by which Ministry?*

- (A) विज्ञान और प्रौद्योगिकी मन्त्रालय
- (B) पर्यटन मन्त्रालय
- (C) पर्यावरण, वन और जलवायु परिवर्तन मन्त्रालय ✅
- (D) शहरी विकास मन्त्रालय

**उत्तर : (C)**

---

**124.** राष्ट्रीय जैव-विविधता प्राधिकरण स्थित है –
*National Biodiversity Authority is located at :*

- (A) तिरुवनन्तपुरम् / Thiruvananthapuram
- (B) चेन्नई / Chennai ✅
- (C) इम्फाल / Imphal
- (D) शिमला / Shimla

**उत्तर : (B)**

---

**125.** डेजर्ट नेशनल पार्क किस लुप्तप्राय पक्षी प्रजाति के लिए प्रसिद्ध है?
*The Desert National Park is renowned for which endangered bird species?*

- (A) ग्रेट इण्डियन बस्टर्ड / Great Indian Bustard ✅
- (B) ग्रेट हॉर्नबिल / Great Hornbill
- (C) बंगाल फ्लोरिकन / Bengal Florican
- (D) मोर / Peacock

**उत्तर : (A)**

---

**126.** पर्यावरण, वन और जलवायु परिवर्तन मंत्रालय ने ग्रीन हाउस गैस उत्सर्जन तीव्रता (GEI) लक्ष्य नियम, 2025 कब अधिसूचित किया?
*When did the MoEFCC notify the Green House Gases Emissions Intensity (GEI) Target Rules, 2025?*

- (A) 16 अप्रैल, 2025 ✅
- (B) 20 मई, 2025
- (C) 30 मार्च, 2025
- (D) 18 जून, 2025

**उत्तर : (A)**  *(प्रारूप/ड्राफ्ट अधिसूचना 16 अप्रैल 2025)*

---

**127.** निम्नलिखित में से कौन-सा उत्तराखण्ड का पहला रामसर स्थल है?
*Which of the following is Uttarakhand's first Ramsar site?*

- (A) नन्दा देवी राष्ट्रीय उद्यान
- (B) गंगोत्री राष्ट्रीय उद्यान
- (C) आसन संरक्षण रिजर्व / Asan Conservation Reserve ✅
- (D) जिम कॉर्बेट राष्ट्रीय उद्यान

**उत्तर : (C)**

---

**128.** भारत में कितने जैव-भौगोलिक क्षेत्र हैं?
*How many bio-geographical zones are in India?*

- (A) 10 ✅
- (B) 20
- (C) 25
- (D) 35

**उत्तर : (A)**

---

**129.** राष्ट्रीय पाठ्यचर्या रूपरेखा (NCF) 2005 के अनुसार, प्राथमिक स्तर पर EVS शिक्षण-अधिगम के दायरे के बारे में निम्नलिखित में से कौन-सा/से कथन सही है/हैं?

I. बच्चों की वास्तविक जीवन स्थितियों के साथ EVS अंतःक्रिया को सीखने की वास्तविक संलग्नता के माध्यम से दिन-प्रतिदिन की गतिविधियों पर विचार के रूप में माना जाता है।
II. पर्यावरण अध्ययन से बच्चों में अपने पर्यावरण के प्रति जागरूकता और समझ बढ़ती है।
III. पर्यावरण अध्ययन का उद्देश्य विद्यार्थियों को वास्तविक जीवन की दुनिया, प्रकृति और समाज से परिचित कराना है, जिसमें वे रहते हैं।

- (A) केवल I
- (B) II और III
- (C) I और II
- (D) I, II और III ✅

**उत्तर : (D)**

---

**130.** निम्नलिखित में से कौन-सा सतत विकास लक्ष्य (SDG) सभी के लिए जल और स्वच्छता की उपलब्धता और सतत प्रबंधन सुनिश्चित करता है?
*Which SDG ensures availability and sustainable management of water and sanitation for all?*

- (A) SDG 4
- (B) SDG 5
- (C) SDG 6 ✅
- (D) SDG 7

**उत्तर : (C)**

---

**131.** राजेश कक्षा 5 के शिक्षक हैं। वह विद्यार्थियों को 'वृक्ष संरक्षण' की अवधारणा के प्रति संवेदनशील बनाने की योजना बना रहे हैं। निम्नलिखित में से कौन-सी गतिविधि इस उद्देश्य के लिए सबसे उपयुक्त है?

- (A) प्रत्येक शिक्षार्थी को एक पौधा अपनाने और उसका पोषण करने के लिए प्रेरित करें ✅
- (B) वाद-विवाद प्रतियोगिता का आयोजन
- (C) पोस्टर प्रतियोगिता में भाग लेने के लिए शिक्षार्थियों को प्रोत्साहित करना
- (D) समूह चर्चा के लिए शिक्षार्थियों का समूहन

**उत्तर : (A)**

---

**132.** निचली कक्षाओं में पर्यावरण अध्ययन विषय में रुचि पैदा करने के लिए उपयोग की जाने वाली शिक्षण पद्धति होनी चाहिए –
*To create interest in EVS in lower classes, the teaching method used must be :*

- (A) आगमनात्मक / Inductive
- (B) मनोरंजनात्मक एवं खेल सम्बन्धी / Recreative and game related ✅
- (C) रटना / Cramming
- (D) निगमनात्मक / Deductive

**उत्तर : (B)**

---

**133.** "मनुष्य प्रकृति से अलग है और प्राकृतिक नियमों के अधीन नहीं है", यह एक अवधारणा है –
*"Humans are apart from nature and not subject to natural laws" — this is a concept of :*

- (A) सीमांत नैतिकता / Frontier Ethics ✅
- (B) सतत नैतिकता / Sustainable Ethics
- (C) पर्यावरणीय नैतिकता / Environmental Ethics
- (D) प्राकृतिक नैतिकता / Natural Ethics

**उत्तर : (A)**

---

**134.** उत्तराखण्ड में दून घाटी के निर्माण के लिए मुख्य रूप से कौन-सी नदी जिम्मेदार है?
*Which river is primarily responsible for forming the Doon Valley in Uttarakhand?*

- (A) गंगा / Ganga
- (B) यमुना / Yamuna
- (C) सौंग / Song ✅
- (D) रिस्पना / Rispana

**उत्तर : (C)**

---

**135.** प्राथमिक छात्रों के लिए EVS में निम्नलिखित में से कौन-सी सबसे उपयुक्त रचनात्मक (formative) मूल्यांकन रणनीति है?

- (A) अध्याय के अंत में छात्रों से एक विस्तृत परीक्षण लिखने के लिए कहना
- (B) केवल नोटबुक पूर्णता के आधार पर अंक देना
- (C) समूह चर्चाओं का अवलोकन करना और वास्तविक घटनाओं का रिकॉर्ड (anecdotal records) रखना ✅
- (D) प्रत्येक पाठ के बाद तथ्यात्मक स्मरण प्रश्न पूछना

**उत्तर : (C)**

---

**136.** जीवाश्म ईंधन को निम्नलिखित में से किस तकनीक द्वारा निकाला जाता है?
*Fossil fuels are extracted by which of the following techniques?*

- (A) हाइड्रो एनर्जी / Hydro Energy
- (B) हाइड्रॉलिक फ्रैक्चरिंग / Hydraulic Fracturing ✅
- (C) हाइड्रॉलिक फ्रैक्शन / Hydraulic Fraction
- (D) हाइपोड्रिलिंग फ्रैक्शन / Hypodrilling Fraction

**उत्तर : (B)**

---

**137.** 'कार्बन फुटप्रिंट' शब्द का तात्पर्य है –
*The term carbon footprint refers to :*

- (A) महासागरों द्वारा कार्बन डाइऑक्साइड अवशोषण की दर
- (B) किसी पारिस्थितिकी तन्त्र में संग्रहित कार्बन की मात्रा
- (C) किसी व्यक्ति या संगठन द्वारा उत्सर्जित ग्रीन हाउस गैसों की कुल मात्रा ✅
- (D) प्रकाश संश्लेषण के दौरान उत्सर्जित कार्बन डाइऑक्साइड की मात्रा

**उत्तर : (C)**

---

**138.** समूह चर्चा के दौरान, प्रिया ने सुझाव दिया कि केवल लड़कों को ही पवनचक्की का मॉडल बनाने के लिए उपकरण चलाने चाहिए, जबकि लड़कियों को उसे सजाने पर ध्यान केन्द्रित करना चाहिए। शिक्षिका ने लड़के और लड़कियों दोनों को गतिविधि के सभी भागों को आजमाने के लिए प्रोत्साहित किया। शिक्षिका का यह कार्य किस EVS पाठ्यचर्या सम्बन्धी अपेक्षा का समर्थन करता है?

- (A) छात्रों में रचनात्मकता और सौन्दर्यबोध को बढ़ावा देना
- (B) समूह शिक्षण और सहयोग को प्रोत्साहित करना
- (C) व्यावहारिक गतिविधियों के माध्यम से वैज्ञानिक सोच का विकास करना
- (D) समानता, न्याय और मानवीय गरिमा से सम्बन्धित मुद्दों की पहचान करना ✅

**उत्तर : (D)**

---

**139.** प्रवाल भित्तियों के संरक्षण के लिए भारत सरकार ने निम्नलिखित में से एक को समुद्री पार्क घोषित किया है –
*To conserve coral reefs, the Government of India declared one of the following as Marine Park :*

- (A) मन्नार की खाड़ी / Gulf of Mannar
- (B) अंडमान द्वीपसमूह / Andaman Islands
- (C) कच्छ की खाड़ी / Gulf of Kutch ✅
- (D) लक्षद्वीप द्वीपसमूह / Lakshadweep Islands

**उत्तर : (C)**  *(आधिकारिक UBSE कुंजी)*

---

**140.** उत्तराखण्ड वन विभाग ने राज्य का पहला 'साइकैड गार्डन' किस स्थान पर स्थापित किया है?
*Where has the Uttarakhand Forest Department established the state's first 'Cycad Garden'?*

- (A) अल्मोड़ा / Almora
- (B) हल्द्वानी / Haldwani ✅
- (C) पिथौरागढ़ / Pithoragarh
- (D) रानीखेत / Ranikhet

**उत्तर : (B)**

---

**141.** वह उपकरण जो वायुमंडल में विभिन्न ऊँचाइयों पर तापमान, दबाव और आर्द्रता को मापता है –
*The instrument that measures temperature, pressure and humidity at various altitudes :*

- (A) बैरोग्राफ / Barograph
- (B) रेडियोसॉन्ड / Radiosonde ✅
- (C) एनेरोइड बैरोमीटर / Aneroid barometer
- (D) अल्टीमीटर / Altimeter

**उत्तर : (B)**

---

**142.** पर्यावरण अध्ययन की पाठ्यपुस्तक बाल-केन्द्रित है, ताकि बच्चे ............ द्वारा सीखें, न कि ............ द्वारा।
*Textbook of EVS is child-centered, so that the children learn by ........ and not by ........*

- (A) अनुसंधान, विषय / Research, Subject
- (B) अन्वेषण, रटकर सीखना / Exploring, Rote learning ✅
- (C) सिद्धान्त, व्यावहारिक / Theory, Practical
- (D) ज्ञान, कौशल / Knowledge, Skills

**उत्तर : (B)**

---

**143.** भारत के पहले एशियन किंग गिद्ध (जटायु) संरक्षण और प्रजनन केन्द्र की स्थापना कहाँ की गई है?
*Where has India's first Asian King Vulture (Jatayu) conservation and breeding centre been established?*

- (A) मसूरी / Mussoorie
- (B) महाराजगंज / Maharajganj ✅
- (C) इंदौर / Indore
- (D) जैसलमेर / Jaisalmer

**उत्तर : (B)**

---

**144.** राष्ट्रीय जलमार्ग संख्या-1 किन नगरों को जलमार्ग से जोड़ती है?
*Which cities are connected by National Waterway No. 1?*

- (A) हल्दिया तथा इलाहाबाद / Haldia and Allahabad ✅
- (B) सदिया तथा धुबरी / Sadiya and Dhubri
- (C) कोट्टापुरम तथा कोल्लम / Kottapuram and Kollam
- (D) काकीनाडा तथा पुडुचेरी / Kakinada and Puducherry

**उत्तर : (A)**

---

**145.** मिट्टी (क्ले) के खनिज हैं –
*Clay minerals are :*

- (A) टेक्टोसिलिकेट्स / Tectosilicates
- (B) सोरोसिलिकेट्स / Sorosilicates
- (C) इनोसिलिकेट्स / Inosilicates
- (D) फाइलोसिलिकेट्स / Phyllosilicates ✅

**उत्तर : (D)**

---

**146.** निम्नलिखित ग्रीन हाउस गैसों को उनकी वैश्विक तापन क्षमता (GWP) के घटते क्रम में व्यवस्थित करें :

I. कार्बन डाइऑक्साइड / Carbon dioxide
II. सल्फर हेक्साफ्लोराइड / Sulphur hexafluoride
III. नाइट्रस ऑक्साइड / Nitrous oxide
IV. मीथेन / Methane

- (A) I, II, III, IV
- (B) IV, III, I, II
- (C) II, III, IV, I ✅
- (D) II, I, IV, III

**उत्तर : (C)**

---

**147.** नैनो-फिल्ट्रेशन तकनीक का उपयोग करके कम लागत वाला आर्सेनिक फिल्टर 'अमृत' किसके द्वारा विकसित किया गया है?
*'Amrit', a low-cost arsenic filter using nano-filtration technology has been developed by :*

- (A) IIT – मद्रास / IIT Madras ✅
- (B) IIT – दिल्ली
- (C) IIT – बॉम्बे
- (D) IISc – बैंगलोर

**उत्तर : (A)**

---

**148.** पर्यावरण के निम्नलिखित घटकों में से कौन पदार्थ का प्रभावी वाहक है?
*Which of the following components of the environment is the effective transporter of matter?*

- (A) वायुमंडल और जलमंडल / Atmosphere and Hydrosphere ✅
- (B) वायुमंडल और स्थलमंडल / Atmosphere and Lithosphere
- (C) जलमंडल और स्थलमंडल / Hydrosphere and Lithosphere
- (D) स्थलमंडल और तापमंडल / Lithosphere and Thermosphere

**उत्तर : (A)**

---

**149.** एक बच्चा पर्यावरण अध्ययन को भौतिक, जैविक, रासायनिक, सामाजिक, सांस्कृतिक और अन्य आयामों से सीख सकता है। यह कथन इस बात की पुष्टि करता है कि पर्यावरण अध्ययन है –
*This statement endorses that EVS is a :*

- (A) प्रासंगिक क्षेत्र / Contextual Area
- (B) समग्र क्षेत्र / Composite Area ✅
- (C) शिक्षार्थी केन्द्रित / Learner Centered
- (D) उपरोक्त में से कोई नहीं / None of the above

**उत्तर : (B)**

---

**150.** पर्यावरण अध्ययन पढ़ाने के लिए निम्नलिखित में से कौन-सा उद्देश्य आवश्यक **नहीं** है?
*Which of the following objectives is not required to teach Environmental Studies?*

- (A) भौतिक और सामाजिक वातावरण के प्रति संवेदनशीलता विकसित करना
- (B) बुनियादी वैज्ञानिक अवधारणाओं और सिद्धान्तों को याद रखना ✅
- (C) पर्यावरण का अन्वेषण करने के अवसर प्रदान करना
- (D) अवलोकन, मापन, पूर्वानुमान और वर्गीकरण जैसे कौशल विकसित करना

**उत्तर : (B)**

---

*खण्ड 5 (पर्यावरण अध्ययन) समाप्त — प्रश्न पत्र समाप्त*
