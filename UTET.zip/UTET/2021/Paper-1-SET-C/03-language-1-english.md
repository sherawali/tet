# First Language — English
**UTET 2021 — Paper I, SET-C | Questions 31 to 60**

---

**Direction (Q. No. 31):** In the question below, a sentence has been given in Direct speech. Out of the four alternatives suggested, select the one which best expresses the same sentence in Indirect speech.

**31.** I said to my friend, "Can you pick me up after work?"
(A) I asked my friend if he can pick me up after work.
(B) I asked my friend if he could pick me up after work.
(C) I told my friend to pick me up after work.
(D) I told my friend if he could pick him up after work.

---

**Direction (Q. No. 32):** Complete the following sentence by selecting the appropriate modal auxiliary out of the given alternatives.

**32.** Had our flights been on time, we ________ reached by now.
(A) will have (B) would have (C) have (D) shall have

---

**Direction (Q. No. 33 to 34):** Identify the figure of speech in the given sentences.

**33.** 'Let not Ambition mock their useful toil'
(A) Simile (B) Oxymoron (C) Personification (D) Metaphor

**34.** "The murmurous haunt of flies on summer eves"
(A) Simile (B) Metaphor (C) Onomatopoeia (D) Oxymoron

---

**35.** What are the productive skills of language?
(A) listening, speaking (B) listening, reading (C) reading, writing (D) speaking, writing

**36.** Role play should be an integral part of every language classroom because —
(A) it is very useful to maintain silence in the classroom.
(B) it enables students to engage in meaningful talk.
(C) it enables students to memorize the story.
(D) it enables girls and boys to interact freely.

**37.** Which one is the theory based on habit formation that says that a human or any creature gives response due to stimulus, or humans learn due to stimulus?
(A) Classical conditioning (B) Operant conditioning (C) Stimulus conditioning (D) None of these

**38.** The scientific study of articulation, transmission and reception of speech sounds is called —
(A) Linguistics (B) Morphology (C) Phonetics (D) Syntax

**39.** According to the National Curriculum Framework 2005, English in India is ________ in a multilingual country.
(A) a foreign language (B) a global language (C) an associate language (D) a first language

**40.** The linguist Noam Chomsky maintains that every child has an innate Language Acquisition Device (LAD) that he/she uses for —
(A) Semantics (B) Phonetics (C) Universal Grammar (D) Complex words

---

## Passage (Q. No. 41 to 45)

**Direction:** Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> It is difficult to reconcile the ideas of different schools of thought on the question of education. Some people maintain that pupils at school should concentrate on a narrow range of subjects which will benefit them directly in their subsequent careers. Others contend that they should study a wide range of subjects so that they have not only the specialised knowledge necessary for their chosen careers but also a sound general knowledge about the world they will have to work and live in. Supporters of the first theory state that the greatest contributions to civilisations are made by those who are most expert in their trade or profession. Those on the other side say that unless they have a broad general education, the experts will be too narrow in their outlook to have sympathy with their fellows or a proper sense of responsibility towards humanity as a whole.

**41.** Broad general knowledge is necessary because —
(A) without it no one would get a job.
(B) it broadens one's outlook.
(C) it teaches us about different things.
(D) specialisation is complete without it.

**42.** 'Schools of thought' can be explained as —
(A) groups of people who are schooled to think.
(B) groups of people whose job is to think.
(C) groups of people who study in a particular school thoughtfully.
(D) groups of people having the same ideas but with different perception on a particular subject.

**43.** Supporters of the first theory say that —
(A) experts have done nothing to save mankind.
(B) experts have contributed most to progress in the modern world.
(C) people with general knowledge are more useful than experts.
(D) people with general knowledge have contributed to civilisation.

**44.** The idea of the first school of thought in the passage is that —
(A) students should concentrate on studies.
(B) students should not undertake any specialised work.
(C) students should study all the subjects they want to.
(D) students should study a few subjects that will help them in their profession.

**45.** According to the second school of thought, education will not be very effective if pupils —
(A) do not have a wide general education.
(B) have nothing but general knowledge.
(C) have inadequate knowledge of their own work.
(D) ignore the study of fine arts.

---

## Poem (Q. No. 46 to 50)

**Direction:** Read the poem given below and answer the questions that follow by selecting the most appropriate option.

> Half a league, half a league,
> Half a league onward,
> All in the valley of Death
> Rode the six hundred.
> "Forward, the Light Brigade!
> Charge for the guns!" he said.
> Into the valley of Death
> Rode the six hundred.
>
> "Forward, the Light Brigade!"
> Was there a man dismay'd?
> Not tho' the soldier knew
> Some one had blunder'd.
> Theirs not to make reply,
> Theirs not to reason why,
> Theirs but to do and die.
> Into the valley of Death
> Rode the six hundred.

**46.** The expression 'the valley of death' refers to —
(A) the place where the dead soldiers are lying buried.
(B) the impending death of soldiers.
(C) the house of death.
(D) a nightmarish place.

**47.** Which of the following adjectives does not apply to the soldiers?
(A) courageous (B) disciplined (C) patriotic (D) impractical

**48.** Name the figure of speech used in 'the Valley of Death' —
(A) Metaphor (B) Simile (C) Synecdoche (D) Metonymy

**49.** Which of the following statements is not true? The military discipline teaches the soldiers —
(A) to do and die.
(B) to obey their commander's order.
(C) to act tactfully in the battlefield.
(D) not to ask any question.

**50.** In the first stanza of the poem, the soldiers are —
(A) talking to each other about their personal problems.
(B) waiting for their commander's order.
(C) thinking about the result of the war.
(D) seen riding fast to the enemy territory.

---

**Direction (Q. No. 51):** Choose the word that is most nearly the same in meaning (synonym) of the numbered word.

**51.** Camouflage
(A) Disguise (B) Uncover (C) Demonstrate (D) Fabric

**Direction (Q. No. 52):** Choose the word that is most nearly opposite in meaning (antonym) of the numbered word.

**52.** Conspicuous
(A) Indifferent (B) Harmless (C) Insignificant (D) Unknown

**Direction (Q. No. 53):** Fill in the blank with the help of a suitable preposition.

**53.** Man cannot live ________ bread alone.
(A) except (B) with (C) by (D) at

**Direction (Q. No. 54):** Out of the four alternatives, choose the one which can be best substituted for the sentence below.

**54.** One who accepts pleasure and pain equally.
(A) Thespian (B) Sadist (C) Humanitarian (D) Stoic

**Direction (Q. No. 55 to 56):** In each group, one word is correctly spelt. Find the correctly spelt word.

**55.** (A) measureable (B) manageable (C) marriagable (D) manoevrable

**56.** (A) impromptue (B) illustrious (C) illusery (D) impetous

**Direction (Q. No. 57 to 58):** Choose the alternative which best expresses the meaning of the underlined idiom.

**57.** Ram is very calculative and always **has an axe to grind**.
(A) has no result (B) works for both sides (C) has a private agenda (D) fails to arouse interest

**58.** The project is carried over to this year, and we need to **keep the ball rolling**.
(A) to continue the work (B) more information (C) to do better (D) new strategies

**Direction (Q. No. 59):** Select the alternative which best expresses the sentence in Passive voice.

**59.** Who is singing such a sweet song?
(A) By whom is such a sweet song sung?
(B) By whom is such a sweet song being sung?
(C) By whom is such a sweet song sang?
(D) By whom has such a sweet song sung?

**Direction (Q. No. 60):** Choose the correct conjunction.

**60.** Hardly had he left ________ his brother came.
(A) then (B) than (C) when (D) that
