# UTET 2021 — Paper I (प्रथम / FIRST)

| विवरण | Detail |
|---|---|
| परीक्षा | UTET (Uttarakhand Teacher Eligibility Test) |
| वर्ष / Year | 2021 |
| प्रश्नपत्र | प्रथम / Paper I (कक्षा 1–5) |
| Booklet Code | XXI-1 |
| SET | C |
| समय / Time | 2 घण्टे 30 मिनट / 2 hours 30 mins |
| पूर्णांक / Max. Marks | 150 |
| कुल प्रश्न | 150 (प्रत्येक 1 अंक) |

## प्रश्नपत्र की संरचना / Structure

| प्रश्न संख्या | विषय | Subject |
|---|---|---|
| 1 – 30 | बाल विकास एवं शिक्षण विज्ञान | Child Development and Pedagogy |
| 31 – 60 | भाषा प्रथम — हिन्दी **अथवा** अंग्रेजी | First Language — Hindi OR English |
| 61 – 90 | भाषा द्वितीय — हिन्दी / अंग्रेजी / संस्कृत / उर्दू | Second Language |
| 91 – 120 | गणित | Mathematics |
| 121 – 150 | पर्यावरण अध्ययन | Environmental Studies |

> नोट: भाषा प्रथम में चुनी गई भाषा, भाषा द्वितीय के रूप में नहीं ली जा सकती।
> Note: The language selected as First language cannot be taken as Second language.

## इस फ़ोल्डर की फाइलें

- `01-child-development-pedagogy.md` — Q 1–30
- `02-language-1-hindi.md` — Q 31–60 (भाषा प्रथम हिन्दी)
- `03-language-1-english.md` — Q 31–60 (First Language English)
- `04-language-2-hindi.md` — Q 61–90 (भाषा द्वितीय हिन्दी)
- `05-language-2-english.md` — Q 61–90 (Second Language English)
- `06-language-2-sanskrit.md` — Q 61–90 (भाषा द्वितीय संस्कृत)
- `07-mathematics.md` — Q 91–120
- `08-environmental-studies.md` — Q 121–150

*उर्दू खण्ड (भाषा द्वितीय — उर्दू) शामिल नहीं किया गया है।*
