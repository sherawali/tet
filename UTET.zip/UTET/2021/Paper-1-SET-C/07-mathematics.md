# गणित / Mathematics
**UTET 2021 — Paper I, SET-C | प्रश्न 91 से 120**

---

**91.** किसी काम को P और Q मिलकर 12 दिनों में, Q और R मिलकर 15 दिनों में तथा R और P मिलकर 20 दिनों में समाप्त कर सकते हैं, तो P अकेले कितने दिनों में काम समाप्त करेगा?
(A) 10 (B) 20 (C) 30 (D) 60

**91.** A work can be completed by P and Q in 12 days, Q and R in 15 days and R and P in 20 days. In how many days can P alone finish the work?
(A) 10 (B) 20 (C) 30 (D) 60

---

**92.** 40 विद्यार्थियों की कक्षा के औसत अंक 86 हैं। यदि 5 सर्वोत्तम अंक हटा दिये जायें, तो औसत अंक 1 कम हो जाता है। सर्वोत्तम 5 विद्यार्थियों के औसत अंक ज्ञात कीजिए —
(A) 92 (B) 96 (C) 93 (D) 97

**92.** The average marks obtained by 40 students of a class is 86. If the 5 highest marks are removed, the average reduces by one mark. Find the average marks of the top 5 students.
(A) 92 (B) 96 (C) 93 (D) 97

---

**93.** प्राथमिक स्तर के गणित अध्यापक के साथ मुख्य समस्या क्या है?
(A) शिक्षणशास्त्रीय प्रशिक्षण का अभाव (B) तैयारी का अभाव (C) अभिलेखीकरण में व्यस्तता (D) इनमें से कोई नहीं

**93.** What is the major problem found in a primary level teacher of mathematics?
(A) Lack of pedagogical training (B) Lack of preparation (C) Busyness in record maintenance (D) None of these

---

**94.** निम्नलिखित में से कौन सी विधि "देखो, सुनो और सीखो" के सिद्धान्तों पर आधारित है?
(A) प्रयोगशाला विधि (B) प्रदर्शन विधि (C) व्याख्यान विधि (D) अनुसंधान विधि

**94.** Which of the following methods is based on the principles of "Watch, listen and learn"?
(A) Laboratory Method (B) Demonstration Method (C) Lecture Method (D) Research Method

---

**95.** यदि x + y = 2a है, तो a/(x−a) + a/(y−a) का मान है —
(A) 2 (B) 2a² (C) 0 (D) 2a

**95.** If x + y = 2a, then the value of a/(x−a) + a/(y−a) is —
(A) 2 (B) 2a² (C) 0 (D) 2a

---

**96.** एक मिश्रधातु के 400 ग्राम में जस्ता तथा ताँबा 5 : 3 के अनुपात में हैं। उस अनुपात को 5 : 6 में परिवर्तित करने के लिए कितने ग्राम ताँबा और मिलाना चाहिए?
(A) 50 (B) 150 (C) 550 (D) 300

**96.** Zinc and Copper are in the ratio 5 : 3 in 400 gm of an alloy. How much copper (in gm) should be added to make the ratio 5 : 6?
(A) 50 (B) 150 (C) 550 (D) 300

---

**97.** एक भिन्न के अंश तथा हर, प्रत्येक में से 1 घटाने पर भिन्न 1/3 हो जाती है। वही भिन्न, उसके अंश तथा हर, प्रत्येक में 1 जोड़ने पर 1/2 हो जाती है। उस भिन्न के अंश तथा हर का योगफल कितना है?
(A) 10 (B) 18 (C) 7 (D) 16

**97.** If 1 is subtracted from both the numerator and the denominator of a fraction, it becomes 1/3. If 1 is added to both the numerator and denominator of that fraction, it becomes 1/2. Then the sum of the numerator and denominator of that fraction is —
(A) 10 (B) 18 (C) 7 (D) 16

---

**98.** एक कार एक निश्चित यात्रा को 48 किमी./घंटा की गति से 10 घंटे में समाप्त कर सकती है। उसी दूरी को 8 घंटे में तय करने के लिए कार की गति में कितनी वृद्धि होनी चाहिए?
(A) 6 किमी./घं. (B) 12 किमी./घं. (C) 15 किमी./घं. (D) 60 किमी./घं.

**98.** A car can finish a certain journey in 10 hours at a speed of 48 km/h. In order to cover the same distance in 8 hours, the speed of the car must be increased by —
(A) 6 km/h (B) 12 km/h (C) 15 km/h (D) 60 km/h

---

**99.** यदि 2160 = 2^a × 3^b × 5^c, तो 3^a × 2^(−b) × 5^(−c) का मान होगा —
(A) 81/40 (B) 37/39 (C) 1/2 (D) 0

**99.** If 2160 = 2^a × 3^b × 5^c, then the value of 3^a × 2^(−b) × 5^(−c) will be —
(A) 81/40 (B) 37/39 (C) 1/2 (D) 0

---

**100.** किसी महीने का तीसरा शुक्रवार 16वीं तारीख को पड़ता है, तो उसी महीने का चौथा मंगलवार किस तारीख को पड़ेगा?
(A) 27 (B) 29 (C) 20 (D) 22

**100.** If the third Friday is on the 16th of a month, then what will be the date of the fourth Tuesday of that month?
(A) 27 (B) 29 (C) 20 (D) 22

---

**101.** यदि एक कमरे की लम्बाई और चौड़ाई क्रमशः 10% और 20% घटायी जाए और उसकी ऊँचाई को 5% बढ़ाया जाए, तो कमरे के आयतन में कितने प्रतिशत का परिवर्तन होगा?
(A) 24.4% (B) 24.6% (C) 24% (D) 24.2%

**101.** If the length and breadth of a room are decreased by 10% and 20% respectively, while the height is increased by 5%, then what percentage change will occur in the volume of the room?
(A) 24.4% (B) 24.6% (C) 24% (D) 24.2%

---

**102.** यदि संख्या 5132416p, 3 से विभाज्य है, तो p के स्थान पर कौन-सा अंक आएगा?
(A) 8 (B) 6 (C) 7 (D) 9

**102.** If the number 5132416p is divisible by 3, then which digit will come in place of p?
(A) 8 (B) 6 (C) 7 (D) 9

---

**103.** √(248 + √(52 + √(108 + √1296))) का मान होगा —
(A) 14 (B) 12 (C) 16 (D) 13

**103.** The value of √(248 + √(52 + √(108 + √1296))) will be —
(A) 14 (B) 12 (C) 16 (D) 13

> *टिप्पणी: मूल OCR में यह प्रश्न अस्पष्ट था; संभावित रूप से नेस्टेड वर्गमूल का प्रश्न है।*

---

**104.** संख्या 3^98 को 5 से भाग देने पर शेष रहता है —
(A) 1 (B) 2 (C) 3 (D) 4

**104.** When the number 3^98 is divided by 5, then the remainder is —
(A) 1 (B) 2 (C) 3 (D) 4

---

**105.** कितने घण्टों में सेकेण्डों की संख्या, 10 दिनों में मिनटों की संख्या के बराबर है?
(A) 2 घण्टे (B) 3 घण्टे (C) 4 घण्टे (D) 5 घण्टे

**105.** In how many hours is the number of seconds equal to the number of minutes in 10 days?
(A) 2 hours (B) 3 hours (C) 4 hours (D) 5 hours

---

**106.** यदि
```
    9 x 7 6
  −   x 6 y 9
  ─────────────
    3 y y 7
```
तो x और y के मान हैं —
(A) x = 9; y = 3 (B) x = 3; y = 9 (C) x = 5; y = 8 (D) x = 4; y = 8

---

**107.** (7 + 2√6) का वर्गमूल है —
(A) √6 + 1 (B) √3 + 2 (C) √2 + √5 (D) 2 + √5

**107.** The square root of (7 + 2√6) is —
(A) √6 + 1 (B) √3 + 2 (C) √2 + √5 (D) 2 + √5

---

**108.** एक घन का आयतन 64 सेमी.³ है। घन का कुल पृष्ठीय क्षेत्रफल होगा —
(A) 12 सेमी.² (B) 24 सेमी.² (C) 48 सेमी.² (D) 96 सेमी.²

**108.** The volume of a cube is 64 cm³. The total surface area of the cube will be —
(A) 12 cm² (B) 24 cm² (C) 48 cm² (D) 96 cm²

---

**109.** एक समकोण त्रिभुज नहीं हो सकता —
(A) एक समबाहु त्रिभुज (B) एक समद्विबाहु त्रिभुज (C) एक विषमबाहु त्रिभुज (D) एक बहुभुज

**109.** A right angled triangle cannot be —
(A) An equilateral triangle (B) An isosceles triangle (C) A scalene triangle (D) A polygon

---

**110.** पाँच अंकों वाली सबसे बड़ी पूर्ण वर्ग संख्या है —
(A) 99999 (B) 99976 (C) 99856 (D) 99764

**110.** The greatest five digit perfect square number is —
(A) 99999 (B) 99976 (C) 99856 (D) 99764

---

**111.** (1/3 + 1/5) ÷ (1/5 − 3/10 + 4/15) का मान होगा —
(A) 21/10 (B) 17/10 (C) 8/10 (D) 12/10

**111.** The value of (1/3 + 1/5) ÷ (1/5 − 3/10 + 4/15) will be —
(A) 21/10 (B) 17/10 (C) 8/10 (D) 12/10

> *टिप्पणी: OCR में भिन्नों का क्रम अस्पष्ट था।*

---

**112.** 3 तथा 200 के बीच कितनी प्राकृत संख्याएँ 7 से विभाजित होंगी?
(A) 27 (B) 28 (C) 29 (D) 30

**112.** How many natural numbers lie between 3 and 200 which are divisible by 7?
(A) 27 (B) 28 (C) 29 (D) 30

---

**113.** यदि म.स. (a, 8) = 4 और ल.स. (a, 8) = 24 हो, तो 'a' का मान है —
(A) 14 (B) 8 (C) 10 (D) 12

**113.** If HCF (a, 8) = 4 and LCM (a, 8) = 24, then the value of 'a' is —
(A) 14 (B) 8 (C) 10 (D) 12

---

**114.** 80 मी. व्यास वाले एक वृत्ताकार पार्क के अन्दर अधिकतम क्षेत्रफल का एक वर्गाकार खेल का मैदान बना है। खेल के मैदान का क्षेत्रफल है —
(A) 6400 मी.² (B) 3200 मी.² (C) 1600 मी.² (D) 12800 मी.²

**114.** In a circular park of diameter 80 m, there is a square shaped playground of maximum area. The area of the playground is —
(A) 6400 m² (B) 3200 m² (C) 1600 m² (D) 12800 m²

---

**115.** वह विधि जिसमें उदाहरणों के द्वारा नए नियमों की स्थापना की जाती है —
(A) निगमन विधि (B) आगमन विधि (C) विश्लेषण विधि (D) संश्लेषण विधि

**115.** The method in which new rules are established by examples is —
(A) Deductive Method (B) Inductive Method (C) Analytical Method (D) Synthesis Method

---

**116.** गणित की सर्वाधिक प्राचीन शाखा है —
(A) बीजगणित (B) अंकगणित (C) रेखागणित (D) ज्योतिष गणित

**116.** The oldest branch of Mathematics is —
(A) Algebra (B) Arithmetic (C) Geometry (D) Astrology Math

---

**117.** प्राथमिक स्तर पर गणित का क्या महत्व है?
(A) सांस्कृतिक (B) सामाजिक (C) धार्मिक (D) मानसिक

**117.** What is the importance of Mathematics at Primary level?
(A) Cultural (B) Social (C) Religious (D) Mental

---

**118.** हॉग्बेन के अनुसार — "गणित सभ्यता का दर्पण है।" यह कथन गणित के किस मूल्य से सम्बन्धित है?
(A) सांस्कृतिक मूल्य (B) सामाजिक मूल्य (C) अनुशासन सम्बन्धी मूल्य (D) इनमें से कोई नहीं

**118.** According to Hogben — "Mathematics is the mirror of Civilization." This statement corresponds to which value of Mathematics?
(A) Cultural Value (B) Social Value (C) Disciplinary Value (D) None of these

---

**119.** यदि x : y = 1 : 2 है, तो (8x + 9y) : (8x + 2y) का मान क्या होगा?
(A) 22 : 29 (B) 29 : 22 (C) 13 : 6 (D) 6 : 13

**119.** If x : y = 1 : 2, then the value of (8x + 9y) : (8x + 2y) will be —
(A) 22 : 29 (B) 29 : 22 (C) 13 : 6 (D) 6 : 13

---

**120.** किसी 30 सेमी. त्रिज्या तथा 45 सेमी. ऊँचे शंकु को पिघलाकर 5 सेमी. त्रिज्या वाली गेंदों में परिवर्तित किया गया। गेंदों की संख्या ज्ञात कीजिए —
(A) 81 (B) 41 (C) 80 (D) 40

**120.** If a metallic cone of radius 30 cm and height 45 cm is melted and recast into metallic spheres of radius 5 cm, find the number of spheres —
(A) 81 (B) 41 (C) 80 (D) 40
