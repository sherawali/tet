# पर्यावरण अध्ययन / Environmental Studies
**UTET 2021 — Paper I, SET-C | प्रश्न 121 से 150**

---

**121.** भोजन खाने के पश्चात् प्लास्टिक की जिन प्लेटों को फेंक दिया जाता है, उन्हें दोबारा से उपयोग नहीं करना चाहिए, क्योंकि —
(A) ये हल्के पदार्थ की बनी होती हैं। (B) ये आविषी (toxic) पदार्थ की बनी होती हैं। (C) ये जैवनिम्नीकरणीय पदार्थों की बनी होती हैं। (D) ये गैर-जैवनिम्नीकरणीय पदार्थों की बनी होती हैं।

**121.** Disposable plastic plates which are thrown away after eating food should not be used because —
(A) they are made of materials with light weight. (B) they are made of toxic materials. (C) they are made of biodegradable materials. (D) they are made of non-biodegradable materials.

---

**122.** विश्व का सबसे तेजी के साथ घटता जा रहा प्राकृतिक संसाधन कौन-सा है?
(A) जल (B) वन (C) पवन (D) सूर्य का प्रकाश

**122.** The most rapidly dwindling natural resource in the world is —
(A) water (B) forests (C) wind (D) sunlight

---

**123.** पर्यावरणीय अध्ययन में शैक्षणिक भ्रमण का मूल उद्देश्य है —
(A) बच्चों की ऊर्जा को विकसित करना (B) छात्रों के लिये प्रत्यक्ष अनुभव (C) समाजीकरण को बढ़ावा देना (D) टीम भावना बढ़ाना

**123.** The basic objective of educational excursion in EVS is —
(A) to develop the energy of children (B) first hand experience to the students (C) to promote socialisation (D) to promote team spirit

---

**124.** पर्यावरण शिक्षा से अभिप्राय है —
(A) विद्यार्थियों पर अतिरिक्त बोझ डालकर व्यस्त रखा जाए (B) पर्यावरण का समग्रता से ज्ञान कराना (C) विद्यार्थियों का मनोरंजन हो (D) शिक्षा के माध्यम से पर्यावरण को दूषित होने से बचाना

**124.** The meaning of environmental education is —
(A) to engage students with a burdensome schedule (B) to make children aware about the environment (C) to entertain children (D) to save the environment from pollution through education

---

**125.** दोपहर के भोजन अवकाश के बाद पर्यावरण अध्ययन पढ़ाते समय आप यह पाते हैं कि बच्चे पाठ में रुचि नहीं ले रहे हैं। आप क्या करेंगे?
(A) पाठ को रोचक बनाने के लिए बहु-आयामी बुद्धि पर आधारित दृश्य-श्रव्य सामग्रियों का प्रयोग करेंगे।
(B) प्रकरण को तुरन्त बदल देंगे।
(C) बच्चों को बाहर मैदान में खेलने के लिए ले जाएँगे।
(D) बच्चों से कहेंगे कि वे डेस्क पर सिर रखकर आराम करें।

**125.** After the lunch break, while teaching EVS, you find that students are not taking interest in the lesson. What would you do?
(A) Use audio-visual aids based on multiple intelligence to make the lesson interesting. (B) Change the topic immediately. (C) Take the children out to play in the ground. (D) Ask them to put their heads down on the desk and relax.

---

**126.** एन.सी.ई.आर.टी. की पाठ्यपुस्तकों में पर्यावरण अध्ययन को उच्च प्राथमिकता और स्थान दिया गया है —
(A) विषय की आधारभूत संकल्पनाओं की व्याख्या करने के लिए।
(B) चिंतन और विस्मय के लिए शिक्षार्थियों को अवसर उपलब्ध कराने के लिए।
(C) तकनीकी शब्दावली की सटीक परिभाषाएँ उपलब्ध कराने के लिए।
(D) अधिक संख्या में अभ्यास प्रश्नों को शामिल करने के लिए।

**126.** Higher priority and space has been given in NCERT textbooks on EVS to —
(A) Explain basic concepts of the subject. (B) Provide opportunities to learners for contemplation and wondering. (C) Provide exact definitions of technical terms. (D) Include a large number of practice questions.

---

**127.** आँचल अपनी कक्षा V में पर्यावरण अध्ययन की कक्षा में अक्सर गहन जाँच-पड़ताल वाले और कल्पनापरक प्रश्न पूछती है। उसके द्वारा इस प्रकार करने का उद्देश्य ________ में सुधार करना है।
(A) अवलोकन कौशलों (B) संवेगात्मक कौशलों (C) चिंतन कौशलों (D) बोलने सम्बन्धी कौशलों

**127.** Aanchal frequently asks probing and imaginative questions in her Class V EVS. By doing so, she aims at improving —
(A) Observation skills (B) Emotional Skills (C) Thinking Skills (D) Speaking Skills

---

**128.** एक शिक्षक प्रत्येक बच्चे को अपने घरों की रद्दी सामग्री से कुछ उपयोगी वस्तु बनाने को कहता है। शिक्षक का शैक्षिक अभिप्राय **नहीं** है —
(A) कक्षा के श्रेष्ठ विद्यार्थी के बारे में निर्णय करना।
(B) बच्चों में सृजनशीलता का विकास करना।
(C) बच्चों को पुनश्चक्रण, पुनःप्रयोग और रूपांतरण को समझाना।
(D) कूड़े से बनी श्रेष्ठ वस्तुओं की प्रदर्शनी आयोजित करना।

**128.** A teacher asks every child to use some waste material from their homes and make something useful out of it. The pedagogical intention of the teacher is **not** to —
(A) Judge the best student of the class. (B) Develop creativity among children. (C) Make children understand the concept of recycle, reuse and reduce. (D) Organize an exhibition of best articles made out of waste.

---

**129.** संसार का सबसे बड़ा पारिस्थितिकी तंत्र है —
(A) जंगल (B) घास का मैदान (C) झील (D) सागर

**129.** The largest ecosystem of the world is —
(A) Forest (B) Grass Land (C) Lake (D) Ocean

---

**130.** भारतवर्ष का प्रथम राष्ट्रीय उद्यान है —
(A) कान्हा (B) पेरियार (C) कार्बेट (D) राजाजी

**130.** The first National Park of India is —
(A) Kanha (B) Periyar (C) Corbett (D) Rajaji

---

**131.** गाँवों में लोग लकड़ी का उपयोग ईंधन के रूप में करते हैं, क्योंकि —
(A) इसे एक आदर्श ईंधन माना जाता है। (B) यह आसानी से उपलब्ध है और सस्ती है। (C) यह पर्यावरण हितैषी है। (D) यह आसानी से आग पकड़ लेती है।

**131.** In villages, people use wood as fuel because —
(A) it is considered to be an ideal fuel. (B) of its easy availability and low cost. (C) it is environment friendly. (D) it catches fire easily.

---

**132.** मृदा अपरदन इसके द्वारा रोका जा सकता है —
(A) वनों का विकास करके (B) वनों की कटाई (C) उर्वरक का अत्यधिक उपयोग (D) जंतुओं द्वारा अतिचारण

**132.** Soil erosion can be prevented by —
(A) raising forests (B) deforestation (C) excessive use of fertilizer (D) overgrazing by animals

---

**133.** गंगा कार्य योजना शुरू हुई थी —
(A) 1986 में (B) 1988 में (C) 1990 में (D) 1983 में

**133.** Ganga Action Plan (G.A.P.) was launched in —
(A) 1986 (B) 1988 (C) 1990 (D) 1983

---

**134.** रेडियोएक्टिवता की तीव्रता मापी जाती है —
(A) डेसिबल में (B) क्यूरी में (C) हर्ट्ज में (D) इनमें से कोई नहीं

**134.** Intensity of radioactivity is measured in —
(A) Decibel (B) Curie (C) Hertz (D) None of these

---

**135.** माइकोराइजा पाया जाता है —
(A) साइकस में (B) गुलाब में (C) पाइनस (चीड़) में (D) बुरांश में

**135.** Mycorrhiza is present in —
(A) Cycas (B) Rose (C) Pinus (Chir) (D) Buransh

---

**136.** टीनीटस रोग में होता है —
(A) कान से निरन्तर घंटी की आवाज (B) कम दृष्टि (C) सूखी त्वचा (D) हृदय की धीमी धड़कन

**136.** The effect of Tinnitus disease is —
(A) Persistent ringing sound in ear (B) Low eye sight (C) Dry Skin (D) Slow Heart Beat

---

**137.** निम्न में से कौन वायु प्रदूषक नहीं है?
(A) X-किरण (B) CO₂, CO गैस (C) SPM कण (D) SO₂ गैस

**137.** Which of the following is/are not an air pollutant?
(A) X-Ray (B) CO₂, CO gas (C) SPM particle (D) SO₂ gas

---

**138.** लघु हिम युग के लिये उत्तरदायी कारक है —
(A) वृक्षारोपण (B) ज्वालामुखी धूल (C) अत्यधिक यातायात वाहन (D) ध्वनि प्रदूषक

**138.** The factor responsible for the Little Ice Age is —
(A) Plantations (B) Volcanic Dust (C) Excessive Transport Vehicles (D) Sound Pollutants

---

**139.** रहीम एक तालाब बनाकर, पानी भरकर उसमें मछलियाँ डालता है, लेकिन तालाब में मछलियाँ जीवित नहीं रह पाती हैं। इसका कारण है —
(A) गहरा तालाब (B) पानी में घुलित ऑक्सीजन की अनुपस्थिति (C) पक्का तालाब (D) उपरोक्त में से कोई नहीं

**139.** Raheem prepares a pond, fills water and then disperses fishes in it, but the fishes do not survive in the pond. Its reason is —
(A) Deep Pond (B) Absence of dissolved oxygen in water (C) Cemented Pond (D) None of the above

---

**140.** सुरेश ने खेत में मटर बोने के बाद, उसी खेत में बिना खाद का प्रयोग करके गेहूँ का ज्यादा उत्पादन प्राप्त किया, इसका कारण है —
(A) प्रकाशसंश्लेषण (B) वाष्पोत्सर्जन (C) राइजोबियम जीवाणु (D) श्वसन गुणांक

**140.** Suresh produced a greater yield of wheat without the use of fertilizers in the same field where peas were cultivated earlier. Its reason is —
(A) Photosynthesis (B) Transpiration (C) Rhizobium Bacteria (D) Respiratory Quotient

---

**141.** मृदा के संबंध में निम्न कथनों पर विचार कीजिये तथा नीचे दिये गये कूटों से सही उत्तर का चयन कीजिए —
1. मृदा भोजन एवं लकड़ी का मुख्य आधार है।
2. मृदा एक प्रमुख संसाधन है।
3. सभी समुदाय एवं उनकी संस्कृतियाँ मृदा पर आधारित होती हैं।

**कूट:** (A) 1 एवं 2 सत्य हैं (B) 1 एवं 3 सत्य हैं (C) 2 एवं 3 सत्य हैं (D) 1, 2 एवं 3 सत्य हैं

**141.** Consider the following statements about soil and select the correct answer using the code given below —
1. Soil is the basic medium for food and timber.
2. Soil is an important resource.
3. All communities and their cultures depend on soil.

**Code:** (A) 1 and 2 are correct (B) 1 and 3 are correct (C) 2 and 3 are correct (D) 1, 2 and 3 are correct

---

**142.** निम्न में से कौन-सा एक पृथ्वी के क्रस्ट का सबसे प्रमुख तत्व है?
(A) एल्यूमिनियम (B) लोहा (C) ऑक्सीजन (D) सिलिकन

**142.** Which one of the following is the dominant element of the Earth's crust?
(A) Aluminium (B) Iron (C) Oxygen (D) Silicon

---

**143.** भारत में निम्न में से किस प्रकार का वनावरण सबसे अधिक पाया जाता है?
(A) उष्णकटिबंधीय नम सदाबहार वन (B) उष्णकटिबंधीय अर्द्ध सदाबहार वन (C) उष्णकटिबंधीय नम पर्णपाती वन (D) शुष्क उष्णकटिबंधीय वन

**143.** Which of the following types of forests covers the largest area in India?
(A) Tropical Wet Evergreen Forests (B) Tropical Semi-Evergreen Forests (C) Tropical Moist Deciduous Forests (D) Dry Tropical Forests

---

**144.** एक प्रजाति के हमेशा के लिए विलुप्त होने की प्रक्रिया में पहला चरण कौन-सा है?
(A) पारिस्थितिकीय विलोपन (B) सामूहिक विलोपन (C) स्थानीय विलोपन (D) जैविक विलोपन

**144.** Which is the first stage in the process of a species becoming irreversibly extinct?
(A) Ecological extinction (B) Mass extinction (C) Local extinction (D) Biological extinction

---

**145.** निम्नलिखित में से कौन-सा कथन वैश्विक स्तर पर जल के बारे में सत्य है?
(A) प्रतिव्यक्ति उपलब्ध जल पर्याप्त नहीं है। (B) हम पानी का पुनः प्रयोग नहीं कर सकते। (C) पानी प्रचुर मात्रा में मौजूद है किन्तु फिर भी इसकी कमी है। (D) विश्व में जल की कुल मात्रा लगातार कम होती जा रही है।

**145.** Which of the following statements is true with regard to water on the global scale?
(A) There is not enough water available per capita. (B) We cannot reuse water. (C) There is a lot of water and yet there is scarcity. (D) The total amount of water in the world is constantly decreasing in quantity.

---

**146.** निम्नलिखित में से कौन-सा ईंधन न्यूनतम पर्यावरणीय प्रदूषण उत्पन्न करता है?
(A) डीजल (B) कोयला (C) हाइड्रोजन (D) केरोसिन

**146.** Which one of the following fuels causes minimum environmental pollution?
(A) Diesel (B) Coal (C) Hydrogen (D) Kerosene

---

**147.** निम्नलिखित में से कौन-सा पारिस्थितिकी तंत्र का अजैविक घटक है?
(A) पौधे (B) कवक (C) ह्यूमस (D) बैक्टीरिया

**147.** Which one of the following is an abiotic component of the ecosystem?
(A) Plants (B) Fungi (C) Humus (D) Bacteria

---

**148.** मानव जब UV-किरणों से अत्यधिक प्रभावित हो जाते हैं तब क्या हो सकता है?
(i) प्रतिरक्षा-तंत्र की क्षति (ii) फेफड़ों की क्षति (iii) त्वचा का कैंसर (iv) आमाशय के अल्सर
(A) (i) और (ii) (B) (ii) और (iv) (C) (i) और (iii) (D) (iii) और (iv)

**148.** Excessive exposure of humans to UV-rays results in —
(i) damage to immune system (ii) damage to lungs (iii) skin cancer (iv) peptic ulcers
(A) (i) and (ii) (B) (ii) and (iv) (C) (i) and (iii) (D) (iii) and (iv)

---

**149.** फ्लोराइड प्रदूषण मुख्य रूप से प्रभावित करता है —
(A) दाँत (B) हृदय (C) किडनी (D) मस्तिष्क

**149.** Fluoride pollution mainly affects —
(A) Teeth (B) Heart (C) Kidney (D) Brain

---

**150.** आगरा में ताजमहल को अधिकतम प्रभावित करने वाले प्रदूषण का प्रकार है —
(A) वायु प्रदूषण (B) जल प्रदूषण (C) मृदा प्रदूषण (D) शोर प्रदूषण

**150.** The type of pollution which is likely to affect the Taj Mahal in Agra to a greater extent is —
(A) air pollution (B) water pollution (C) soil pollution (D) noise pollution
