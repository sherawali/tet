# Second Language — English
**UTET 2021 — Paper I, SET-C | Questions 61 to 90**

---

**Direction (Q. No. 61 to 62):** Choose the correct tense.

**61.** Rohan ________ the movie before he read the review.
(A) watches (B) have watched (C) had watched (D) was watching

**62.** By the next month, we shall ________ the project.
(A) has completed (B) completing (C) completed (D) have completed

---

**Direction (Q. No. 63 to 64):** Choose the most suitable auxiliary or modal verb out of the given alternatives.

**63.** In the Middle Ages, people ________ travel by plane.
(A) could (B) had to (C) can't (D) couldn't

**64.** Kate is ill, so she ________ stay in bed and drink a lot of water.
(A) need (B) can't (C) has to (D) doesn't have to

---

**Direction (Q. No. 65):** Select the word nearest in meaning to the underlined part.

**65.** The maid servant left the police station **contrite**.
(A) penitent (B) sore (C) angry (D) remorseless

---

**Direction (Q. No. 66):** Select the option in which the punctuation mark is appropriately used.

**66.**
(A) It is mentioned in the notice, all of us should read it.
(B) It is mentioned in the notice! all of us should read it.
(C) It is mentioned in the notice? all of us should read it.
(D) It is mentioned in the notice; all of us should read it.

---

**Direction (Q. No. 67):** Complete the following sentence using the appropriate phrase preposition from the given options.

**67.** How can they be going out? Jane has nothing ________ Peter.
(A) in common (B) in common to (C) in common of (D) in common with

---

**68.** Which of the following methods is based on the principle 'From example to generalisation'?
(A) Incidental Method (B) Remedial Teaching Method (C) Deductive Method (D) Inductive Method

---

## Passage (Q. No. 69 to 73)

**Direction:** Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> Stammering is a habit disorder linked with lack of self-confidence. Basically for a child to understand a language, there are four stages. The first is learning to understand the spoken language and the second is speaking. Both of these usually develop around the age of two.
>
> The third stage is speaking complex sentences, which develops at around 3 and the fourth is when the child recognises the written alphabet. In 80% of children, while the 3rd and 4th stages are at play, the first two get disturbed because something new is getting incorporated in the mind.
>
> This is absolutely normal. But what over-cautious mothers do is fret a lot and the child develops a fear which later manifests itself as stammering. In fact, most text books on stammering state in bold that 'Had there not been any over-cautious mothers, hardly anyone would have suffered from stammering'. Fluency can be incorporated in the speech of such patients through hypnosis.

**69.** Stammering is caused because of —
(A) Physical disorder (B) Hindered growth (C) Lack of self-confidence (D) Lack of understanding

**70.** The second stage of a child's understanding the language is —
(A) Speaking (B) Writing (C) Listening (D) Reading

**71.** ________ are basically the reason for developing a fear in the child's mind.
(A) Parents (B) Over-cautious mothers (C) Fathers (D) Uncles

**72.** Fluency in such patients can be incorporated in the speech through —
(A) hypnosis (B) slap (C) punishment (D) symbiosis

**73.** By the time the child becomes 2 years old he/she can —
(A) speak complex sentences.
(B) only understand spoken language.
(C) understand and speak simple language.
(D) write the alphabets.

---

## Passage (Q. No. 74 to 78)

**Direction:** Read the passage given below and answer the questions that follow by selecting the most appropriate answer.

> The last great war, which nearly shook the foundations of the modern world, had little impact on Indian Literature beyond aggravating the popular revulsion against violence and adding to the growing disillusionment with the 'humane pretensions' of the Western World. This was eloquently voiced in Tagore's later poems and his last testament, *Crisis in Civilisation*. The Indian Intelligentsia was in a state of moral dilemma. On the one hand, it could not help sympathising with England's dogged courage in the hour of peril, with the Russians fighting with their backs to the wall against the ruthless Nazi hordes, and with China groaning under the heel of Japanese militarism; on the other hand, their own country was practically under military occupation of their own soil, and an Indian army under Subhas Bose was trying from the opposite camp to liberate their country. No creative impulse could issue from such confusion of loyalties. One would imagine that the achievement of Indian Independence in 1947, which came in the wake of the Allies' victory and was followed by the collapse of colonialism in the neighbouring countries of South-East Asia, would have released an upsurge of creative energy. No doubt it did, but unfortunately it was soon submerged in the great agony of Partition, with its inhuman slaughter of the innocents and the uprooting of millions of people from their homeland followed by the martyrdom of Mahatma Gandhi.

**74.** What was the impact of the last great war on Indian Literature?
(A) It had no impact.
(B) It aggravated popular revulsion against violence.
(C) It shook the foundations of literature.
(D) It offered eloquent support to the western world.

**75.** What did Tagore articulate in his last testament?
(A) Offered support to Subhas Bose.
(B) Exposed the humane pretensions of the Western World.
(C) Expressed loyalty to England.
(D) Encouraged the liberation of countries.

**76.** What was the stance of Indian Intelligentsia during the period of the great war?
(A) Indifference to Russia's plight.
(B) They favoured Japanese militarism.
(C) They prompted creativity out of confused loyalties.
(D) They expressed sympathy for England's dogged courage.

**77.** Find in the passage words that mean (i) Disgust (ii) Disappointment
(A) Upsurge, liberate (B) Violence, aggravating (C) Revulsion, Disillusionment (D) Peril, Dogged

**78.** Which of the following statements is true?
(A) Indian Army under the Nazis was trying to liberate the country.
(B) Indian Army under Subhas Bose was trying to liberate the country.
(C) Indian Army under the Russians was trying to liberate the country.
(D) Indian Army under the Japanese was trying to liberate the country.

---

**79.** According to language teaching experts, the early education of a child should be in —
(A) The first language (B) Second language (C) Foreign language (D) Multi language

**80.** In continuous comprehensive evaluation, the teacher tries to —
(A) Find out to what extent the learning objectives are achieved.
(B) Make the learner assess the teacher.
(C) Identify the special needs of the learners in a group.
(D) Make the learner learn by cramming.

**81.** The alphabetic method, the phonic method, the word method and the sentence method are associated with —
(A) Listening (B) Speaking (C) Reading (D) Writing

**82.** Effective learning takes place when the learners are —
(A) Passive (B) Quiet (C) Interactive (D) Good at preparing for the examination

**83.** In order to assess the all-round development of a learner, a teacher has to take the help of —
(A) Unit-end evaluation (B) Term-end evaluation (C) Continuous and comprehensive evaluation (D) Month-end evaluation

---

**Direction (Q. No. 84):** Rearrange the following words and phrases to form a meaningful sentence. Choose the correct alternative sentence.

**84.** services will / tourism in / air taxi / the state / boost
(A) Tourism in the state services will boost air taxi.
(B) Air taxi boost services will tourism in the state.
(C) Air taxi services will boost tourism in the state.
(D) Services will boost tourism in the state air taxi.

**Direction (Q. No. 85):** Choose the most suitable option that describes the meaning of the underlined idiom/phrase.

**85.** The exam **went down in flames**, I should have studied well.
(A) exam paper got burnt (B) passed with good marks (C) failed spectacularly (D) exam hall caught fire

**Direction (Q. No. 86):** Choose the antonym to the underlined word.

**86.** She was determined not to **dissipate** her energies.
(A) Utilize (B) Conserve (C) Manage (D) Organise

**Direction (Q. No. 87):** Choose the synonym to the underlined word.

**87.** She requested him not to **abandon** her.
(A) Try (B) Join (C) Keep up (D) Forsake

**Direction (Q. No. 88 to 89):** Select the incorrectly spelt word from the following.

**88.** (A) Potassium (B) Possibility (C) Parasology (D) Preamble

**89.** (A) Pursue (B) Persuit (C) Persuade (D) Peruse

**Direction (Q. No. 90):** Select the correct alternative which can be substituted for the sentence below.

**90.** A person who talks in sleep is called —
(A) Philatelist (B) Somnambulist (C) Somniloquist (D) Oneirocritic
