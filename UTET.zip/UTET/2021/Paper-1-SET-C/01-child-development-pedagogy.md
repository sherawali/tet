# बाल विकास एवं शिक्षण विज्ञान / Child Development and Pedagogy
**UTET 2021 — Paper I, SET-C | प्रश्न 1 से 30**

---

**1.** किसने व्यक्तित्व के सिद्धान्त में अनन्यता संकट (identity crisis) की बात कही है?
(A) अल्फ्रेड एडलर (B) सिगमण्ड फ्रॉयड (C) एरिक एरिक्सन (D) इनमें से कोई नहीं

**1.** Who talked about identity crisis in his theory of personality?
(A) Alfred Adler (B) Sigmund Freud (C) Erik Erikson (D) None of these

---

**2.** 'आत्म' (Self) का तात्पर्य —
(A) व्यक्ति के उन गुणों से है जो उसे अन्य दूसरों से भिन्न करते हैं।
(B) व्यक्ति के उन पक्षों से है जो उसे किसी सामाजिक अथवा सांस्कृतिक समूह से संबद्ध करते हैं अथवा जो ऐसे समूहों से व्युत्पन्न होते हैं।
(C) अपने संदर्भ में व्यक्ति के सचेतन अनुभवों, विचारों, चिंतन एवं भावनाओं की समग्रता से है।
(D) इनमें से कोई नहीं

**2.** 'Self' refers to —
(A) those attributes of a person that make her/him different from others.
(B) those aspects of a person that link her/him to a social or cultural group or are derived from it.
(C) the totality of an individual's conscious experiences, ideas, thoughts and feelings with regard to herself or himself.
(D) None of these

---

**3.** निम्नांकित में कौन सी व्यक्तित्व की विशेषताएँ हैं?
(A) इसके अंतर्गत शारीरिक और मनोवैज्ञानिक दोनों ही घटक आते हैं।
(B) किसी व्यक्ति विशेष में व्यवहार के रूप में इसकी अभिव्यक्ति पर्याप्त रूप से अनन्य होती है।
(C) इसकी प्रमुख विशेषताएँ साधारणतया समय के साथ परिवर्तित नहीं होती हैं।
(D) उपरोक्त सभी

**3.** Which of the following is a characteristic of personality?
(A) It has both physical and psychological components.
(B) Its expression in terms of behaviour is fairly unique in a given individual.
(C) Its main features do not easily change with time.
(D) All of the above

---

**4.** 'व्यक्तित्व के विशेषक उपागम' का अग्रणी माना जाता है —
(A) रेमन्ड कैटल को (B) गॉर्डन ऑलपोर्ट को (C) एच. जे. आइसैन्क को (D) सिगमण्ड फ्रॉयड को

**4.** The pioneer of 'trait approach of personality' is —
(A) Raymond Cattell (B) Gordon Allport (C) H. J. Eysenck (D) Sigmund Freud

---

**5.** प्रेक्षणात्मक अधिगम का सिद्धान्त दिया था —
(A) पावलव ने (B) स्किनर ने (C) बंदूरा ने (D) इनमें से कोई नहीं

**5.** The theory of observational learning was given by —
(A) Pavlov (B) Skinner (C) Bandura (D) None of these

---

**6.** एक बालिका अपनी परीक्षा के लिए बहुत मेहनत करती है। उसका यह व्यवहार उसकी ........ का संकेतक है —
(A) तीक्ष्ण संज्ञानात्मक योग्यता (B) उच्च उपलब्धि अभिप्रेरणा (C) अधिक व्यस्त कार्यक्रम (D) माता-पिता को प्रभावित करने की इच्छा

**6.** A girl child is working very hard for her examination. Her behaviour is an indicator of her —
(A) Sharp cognitive abilities (B) High achievement motivation (C) Very busy schedule (D) Desire to impress her parents

---

**7.** "पुरस्कार की अधिगम में महत्वपूर्ण भूमिका है" — यह मुख्य विशेषता किस अधिगम उपागम की है?
(A) व्यवहारवादी (B) संज्ञानात्मक (C) मानवतावादी (D) वैज्ञानिक

**7.** "Rewards play a significant role in learning" — is the main characteristic of which of the following approaches of learning?
(A) Behaviouristic (B) Cognitive (C) Humanistic (D) Scientific

---

**8.** 'नकारात्मक पुनर्बलन' का अर्थ है —
(A) कोई भी उद्दीपन प्रस्तुत न करना (B) अप्रिय उद्दीपन प्रस्तुत करना (C) दण्ड देना (D) अप्रिय उद्दीपन को समाप्त करना

**8.** 'Negative Reinforcement' means —
(A) Not presenting any stimulus (B) Presenting an unpleasant stimulus (C) Punishment (D) Terminating an unpleasant stimulus

---

**9.** अभिक्रमित अधिगम निम्नलिखित में से किस पर आधारित है?
(A) क्षेत्र सिद्धान्त (B) क्रियाप्रसूत अनुबंधन (C) गेस्टाल्ट अधिगम सिद्धान्त (D) शास्त्रीय अनुबंधन

**9.** Programmed Learning is based on —
(A) Field theory (B) Operant conditioning (C) Gestalt learning theory (D) Classical conditioning

---

**10.** गणित का एक अध्यापक कक्षा में कुछ प्रश्न कराता है तथा इसके बाद छात्रों को पुस्तक में दी गई समस्याओं को हल करने के लिए कहता है। इस स्थिति में छात्र जिस नियम का पालन कर रहे हैं वह है —
(A) निकटता का नियम (B) पुनर्बलन का नियम (C) तत्परता का नियम (D) अभ्यास का नियम

**10.** A mathematics teacher discusses some problems in the classroom and then asks the students to work out some problems given in the book. Students are practising the law of —
(A) Contiguity (B) Reinforcement (C) Readiness (D) Exercise

---

**11.** अभिरुचि का अर्थ है —
(A) किसी व्यक्ति द्वारा दूसरी क्रियाओं की अपेक्षा किसी एक अथवा एक से अधिक विशिष्ट क्रियाओं में स्वयं को अधिक व्यस्त रखने की वरीयता।
(B) किसी व्यक्ति की अपेक्षाकृत स्थायी प्रकार की वे विशेषताएँ जो उसे अन्य व्यक्तियों से भिन्न बनाती हैं।
(C) किसी व्यक्ति की कौशलों के अर्जन के लिए अंतर्निहित संभाव्यता।
(D) पर्यावरण को समझने, सविवेक चिंतन करने तथा किसी चुनौती के सामने होने पर उपलब्ध संसाधनों का प्रभावी ढंग से उपयोग करने की व्यापक क्षमता।

**11.** Interest refers to —
(A) An individual's preference for engaging in one or more specific activities relative to others.
(B) Relatively enduring characteristics of a person that make her or him distinct from others.
(C) An individual's underlying potential for acquiring skills.
(D) The global capacity to understand the world, think rationally and use the available resources effectively when faced with challenges.

---

**12.** निम्नांकित किस विधि में परीक्षणकर्ता व्यक्ति से वार्तालाप करके सूचनाएँ एकत्रित करता है?
(A) व्यक्ति अध्ययन (B) आत्म प्रतिवेदन (C) साक्षात्कार (D) प्रेक्षण

**12.** Which of the following methods involves seeking information from a person on a one-to-one basis?
(A) Case study (B) Self-report (C) Interview (D) Observation

---

**13.** विकास के विषय में कौन सा कथन सही नहीं है?
(A) विकास जीवन भर चलने वाली प्रक्रिया है, अर्थात् विकास गर्भाधान से प्रारम्भ होकर वृद्धावस्था तक सभी आयु समूहों में होता है।
(B) विकास ऐतिहासिक दशाओं से प्रभावित होता है।
(C) विकास एक आयामी है।
(D) विकास अत्यधिक लचीला या संशोधन योग्य होता है।

**13.** Which of the following statements is not correct about development?
(A) Development is lifelong, i.e., it takes place across all age groups starting from conception to old age.
(B) Development is influenced by historical conditions.
(C) Development is uni-dimensional.
(D) Development is highly plastic.

---

**14.** पियाजे के अनुसार संज्ञानात्मक विकास की किस अवस्था में प्रतीकात्मक विचारों का विकास तथा वस्तु स्थायित्व उत्पन्न होता है?
(A) संवेदी-प्रेरक (B) पूर्व संक्रियात्मक (C) मूर्त संक्रियात्मक (D) औपचारिक संक्रियात्मक

**14.** Development of symbolic thought and establishment of object permanence is visible in which of the following stages of cognitive development according to Piaget?
(A) Sensori-motor (B) Preoperational (C) Concrete operational (D) Formal operational

---

**15.** जीवन की वह अवस्था जिसका प्रारंभ यौवनारंभ से होता है, जब यौन परिपक्वता या प्रजनन करने की योग्यता प्राप्त कर ली जाती है, साधारणतया कहलाती है —
(A) बाल्यावस्था (B) शैशवावस्था (C) प्रौढ़ावस्था (D) किशोरावस्था

**15.** The stage of life that begins at the onset of puberty, when sexual maturity or the ability to reproduce is attained, is commonly known as —
(A) Childhood (B) Infancy (C) Adulthood (D) Adolescence

---

**16.** किशोरावस्था के सम्बन्ध में कौन सा कथन सही है?
(A) काल्पनिक श्रोता किशोरों का एक विश्वास है कि दूसरे लोग भी उनके प्रति उतने ही ध्यानाकर्षित हैं जितने कि वे स्वयं।
(B) किशोरों में अद्वितीयता का बोध उन्हें यह सोचने के लिए प्रेरित करता है कि कोई भी व्यक्ति उनको या उनकी अनुभूतियों को नहीं समझता।
(C) व्यक्तिगत दंतकथाएँ प्रायः किशोरों की डायरी का भाग होती हैं।
(D) उपरोक्त सभी

**16.** Which of the following statements is correct about adolescence?
(A) Imaginary audience is adolescents' belief that others are as preoccupied with them as they are about themselves.
(B) Adolescents' sense of uniqueness makes them think that no one understands them or their feelings.
(C) Personal fables are often part of adolescent diaries.
(D) All of the above

---

**17.** एनोरैक्सिया नर्वोसा है —
(A) निद्रा संबंधी विकार (B) मानसिक विकार (C) आहार ग्रहण संबंधी विकार (D) शारीरिक विकार

**17.** Anorexia nervosa is a —
(A) sleeping disorder (B) mental disorder (C) eating disorder (D) physical disorder

---

**18.** मंद प्रकाश के प्रभावन के बाद तीव्र प्रकाश से समायोजन की प्रक्रिया कहलाती है —
(A) पुनर्जनन (B) प्रकाश अनुकूलन (C) तम अनुकूलन (D) संतृप्ति

**18.** The process of adjusting to bright light after exposure to dim light is called —
(A) Regeneration (B) Light adaptation (C) Dark adaptation (D) Saturation

---

**19.** निम्नांकित कौन सा कथन अधिगम के संबंध में सही है?
(A) व्यवहार में होने वाला (अपेक्षाकृत) स्थायी परिवर्तन अधिगम है।
(B) अधिगम में सदैव किसी न किसी तरह का अनुभव सम्मिलित रहता है।
(C) अधिगम एक अनुमानित प्रक्रिया है और निष्पादन से भिन्न है।
(D) उपरोक्त सभी

**19.** Which of the following statements is correct about learning?
(A) Learning is any relatively permanent change in behaviour.
(B) Learning always involves some kind of experience.
(C) Learning is an inferred process and is different from performance.
(D) All of the above

---

**20.** निम्नांकित में कौन औपचारिक मूल्यांकन की विशेषता नहीं है?
(A) परिवर्तनशील (B) वस्तुनिष्ठ (C) मानकीकृत (D) व्यवस्थित

**20.** Which of the following is not a characteristic feature of formal assessment?
(A) Varies from case to case (B) Objective (C) Standardized (D) Organised

---

**21.** बुद्धि का द्वि-कारक सिद्धान्त प्रस्तावित किया था —
(A) हॉवर्ड गार्डनर ने (B) रॉबर्ट स्टर्नबर्ग ने (C) चार्ल्स स्पियरमैन ने (D) लेव वायगोत्स्की ने

**21.** The two-factor theory of intelligence was proposed by —
(A) Howard Gardner (B) Robert Sternberg (C) Charles Spearman (D) Lev Vygotsky

---

**22.** अनुक्रिया, व्यवस्थापन और चरित्रकरण किस पक्ष के शैक्षिक उद्देश्यों में सम्मिलित हैं?
(A) ज्ञानात्मक पक्ष (B) भावात्मक पक्ष (C) क्रियात्मक पक्ष (D) इनमें से कोई नहीं

**22.** Response, organization and characterization are included in which domain of educational objectives?
(A) Cognitive domain (B) Affective domain (C) Psychomotor domain (D) None of these

---

**23.** निम्नलिखित में कौन-सी अभिप्रेरणा की प्रविधि नहीं है?
(A) पुरस्कार एवं दण्ड (B) प्रशंसा एवं निन्दा (C) नवीनता (D) प्रत्यास्मरण

**23.** Which of the following is not a technique of motivation?
(A) Reward and Punishment (B) Praise and reproof (C) Novelty (D) Recall

---

**24.** बच्चों के संवेगात्मक विकास को प्रभावित करने वाला कारक है —
(A) स्वास्थ्य एवं शारीरिक विकास (B) पारिवारिक वातावरण और आपसी संबंध (C) पास-पड़ोस, समुदाय और समाज (D) उपरोक्त सभी

**24.** Factor influencing emotional development in children is —
(A) Health and physical development (B) Family atmosphere and relationship (C) Neighbourhood, community and society (D) All of the above

---

**25.** अनुक्रियाजन्य अनुबन्धन (Type R-conditioning) कहते हैं —
(A) शास्त्रीय अनुबंधन को (B) सक्रिय अनुबंधन को (C) संयोजनवाद को (D) अनुभवजन्य अधिगम को

**25.** Type R-conditioning is known as —
(A) Classical conditioning (B) Operant conditioning (C) Connectionism (D) Experiential Learning

---

**26.** आत्म-सिद्धि की आवश्यकताएँ सम्बन्धित हैं —
(A) अन्तःदृष्टि सिद्धान्त से (B) क्षेत्र सिद्धान्त से (C) सूचना प्रक्रियाकरण सिद्धान्त से (D) मास्लो के मानवतावादी अधिगम सिद्धान्त से

**26.** Self-actualization needs are related to —
(A) Theory of insightful learning (B) Field Theory (C) Information Processing Theory (D) Maslow's Humanistic Theory of learning

---

**27.** संवेदी स्मृति कहते हैं —
(A) तात्कालिक स्मृति को (B) अल्पकालिक स्मृति को (C) दीर्घकालिक स्मृति को (D) इनमें से कोई नहीं

**27.** Sensory memory is also known as —
(A) Immediate Memory (B) Short-Term Memory (C) Long-Term Memory (D) None of these

---

**28.** निम्नांकित कौन से कथन सर्जनात्मकता तथा बुद्धि के संदर्भ में सत्य हैं?
(i) सर्जनात्मकता व बुद्धि के बीच सकारात्मक सम्बन्ध है।
(ii) बुद्धिमान हो जाना यह निश्चित नहीं करता कि व्यक्ति सर्जनशील भी होगा।
(iii) सर्जनात्मक परीक्षणों में अपसारी चिंतन का उपयोग होता है जबकि बुद्धि परीक्षणों में अभिसारी चिंतन का उपयोग किया जाता है।
(A) (i) और (ii) (B) (i) और (iii) (C) (ii) और (iii) (D) (i), (ii) और (iii)

**28.** Which of the statements are true about creativity and intelligence?
(i) The relationship between creativity and intelligence is positive.
(ii) Intelligence does not ensure creativity.
(iii) Creativity tests involve divergent thinking whereas intelligence tests involve convergent thinking.
(A) (i) and (ii) (B) (i) and (iii) (C) (ii) and (iii) (D) (i), (ii) and (iii)

---

**29.** चेतना का वह स्तर जो अचेतन मूलप्रवृत्तिक और पाशविक अंतर्नोदों का भंडार होता है —
(A) अचेतन (B) पूर्वचेतन (C) चेतन (D) इनमें से कोई नहीं

**29.** The level of consciousness which is considered as the reservoir of instinctive or animal drives is —
(A) Unconscious (B) Preconscious (C) Conscious (D) None of these

---

**30.** वह रक्षा युक्ति जिसमें दुश्चिंता उत्पन्न करने वाले व्यवहार और विचार पूरी तरह चेतना के स्तर से विलुप्त कर दिए जाते हैं —
(A) अस्वीकरण (B) दमन (C) प्रक्षेपण (D) युक्तिकरण

**30.** The kind of defence mechanism in which anxiety provoking behaviours or thoughts are totally dismissed by the unconscious is —
(A) Denial (B) Repression (C) Projection (D) Rationalisation
