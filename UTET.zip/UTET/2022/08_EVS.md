# UTET 2022 — Paper I (पर्यावरण अध्ययन (Environmental Studies))
**Set – B | Booklet Series: XXII-1 | परीक्षा दिनांक/Exam Date: 30 September 2022 | पूर्णांक/Max Marks: 150 | समय/Time: 2 घंटे 30 मिनट**

**अनुभाग / Section:** पर्यावरण अध्ययन (Environmental Studies) — प्रश्न 121-150

> **✅ उत्तर कुंजी स्रोत (Answer Key Source) — आधिकारिक / OFFICIAL:** यह उत्तर-कुंजी उत्तराखण्ड विद्यालयी शिक्षा परिषद् (UBSE), रामनगर (नैनीताल) द्वारा जारी **आधिकारिक UTET-I 2022 Answer Key (SET-B)** से ली गई है — स्रोत: [static.collegedekho.com/.../answer_key_utet_i.pdf](https://static.collegedekho.com/media/uploads/2022/10/07/answer_key_utet_i.pdf) (PDF के पेज 2 पर SET-B की तालिका है)। चूँकि यह सीधे Set-B हेतु आधिकारिक दस्तावेज़ है, अतः प्रश्न-क्रमांक सीधे हमारे Set-B दस्तावेज़ के प्रश्न-क्रमांकों से मेल खाते हैं — किसी प्रकार के content-matching या अनुमान की आवश्यकता नहीं रही। (पहले इस्तेमाल किया गया theexampillar.com-आधारित/स्वयं-हल किया हुआ उत्तर-कुंजी अब इस आधिकारिक स्रोत से पूर्णतः प्रतिस्थापित कर दिया गया है।)
>
> *(This answer key is taken directly from the **OFFICIAL UTET-I 2022 Answer Key (SET-B)** issued by the Uttarakhand Board of School Education (UBSE), Ramnagar, Nainital — sourced from a PDF hosted on static.collegedekho.com (page 2 = Set-B table). Since this is the official document specifically for Set-B, question numbers match our document's numbering directly — no content-matching or guesswork was required. This fully replaces the earlier theexampillar.com-based / self-solved answers used in an earlier draft.)*

---

# भाग 8: पर्यावरण अध्ययन (Environmental Studies) — प्रश्न 121-150

**121.** आपदा प्रबन्धन निम्न में से किस सूची के अन्तर्गत आता है? (A) केन्द्रीय सूची (B) राज्य सूची (C) समवर्ती सूची (D) इनमें से कोई नहीं

*Disaster management comes under which of the following list? (A) Central list (B) State List (C) Concurrent list (D) None of these*

**✅ सही उत्तर / Correct Answer: (C)**

---
**122.** प्राथमिक कक्षा के छात्रों से इस प्रश्न का उत्तर प्राप्त करना, 'आपको क्यों लगता है कि रेगिस्तानी इलाकों में कई पेड़ नहीं उग सकते हैं'? निश्चित रूप से किस अधिगम संकेतक की उपलब्धि को दर्शाता है? (A) पूछताछ (B) स्पष्टीकरण (C) वर्गीकरण (D) प्रयोग

*Getting the answer from primary class students for the question, 'Why do you think many trees cannot grow in desert areas'? surely represents the achievement of which learning indicator? (A) Questioning (B) Explanation (C) Classification (D) Experimentation*

**✅ सही उत्तर / Correct Answer: (B)**

---
**123.** राजेश कक्षा 5 के शिक्षक हैं। वे 'वृक्ष-संरक्षण' की अवधारणा पर शिक्षार्थियों को संवेदनशील बनाने के लिए योजना बनाते हैं। निम्नलिखित में से कौन-सी एक गतिविधि इस उद्देश्य के लिए सर्वाधिक उपयुक्त है? (A) प्रत्येक शिक्षार्थी को एक पौधे को अपनाने और उसका पोषण करने के लिए अभिप्रेरित करना (B) वाद-विवाद प्रतियोगिता का आयोजन करना (C) पोस्टर प्रतियोगिता में भाग लेने के लिए शिक्षार्थियों को प्रोत्साहित करना (D) समूह चर्चा के लिए शिक्षार्थियों का समूह बनाना

*Rajesh is a teacher of class 5. He plans to sensitize the learners on the concept of 'tree conservation'. Which one of the following activities is most suitable for this purpose? (A) Motivate each learner to adopt and nurture a plant (B) Organizing debate competition (C) To encourage learners to participate in poster competition (D) Grouping of learners for group discussion*

**✅ सही उत्तर / Correct Answer: (A)**

---
**124.** भारत में राष्ट्रीय आपदा प्रबन्धन संस्थान स्थित है- (A) पुणे में (B) मिदनापुर में (C) नई दिल्ली में (D) कोलकाता में

*National Institute of Disaster Management in India is located at- (A) Pune (B) Midnapur (C) New Delhi (D) Kolkata*

**✅ सही उत्तर / Correct Answer: (C)**

---
**125.** 'इकोमार्क' सम्बन्धित है - (A) निर्यात वस्तुओं से (B) आयात वस्तुओं से (C) सर्वोत्तम गुणवत्ता वाली वस्तुओं से (D) पर्यावरण के लिए सुरक्षित वस्तुओं से

*'Ecomark' is related to - (A) Export Commodities (B) Import Commodities (C) Commodities of best quality (D) Environmental Friendly commodities*

**✅ सही उत्तर / Correct Answer: (D)**

---
**126.** 'कार्बन क्रेडिट' की संकल्पना निम्नलिखित में से किससे उद्भूत हुई? (A) पृथ्वी सम्मेलन (रियो-डे-जेनेरो) (B) क्योटो प्रोटोकाल (C) मान्ट्रियाल प्रोटोकाल (D) जी-8 शिखरवार्ता

*The concept of 'Carbon credit' originated in which of the following? (A) Earth Summit (Rio-de-Janeiro) (B) Kyoto protocol (C) Montreal protocol (D) G-8 Summit*

**✅ सही उत्तर / Correct Answer: (B)**

---
**127.** निम्नलिखित में से कौन सा कृत्रिम पारिस्थितिकी तंत्र है- (A) धान का खेत (B) वन (C) घास का मैदान (D) झील

*Which of the following is an artificial Ecosystem - (A) Paddy Field (B) Forest (C) Grassland (D) Lake*

**✅ सही उत्तर / Correct Answer: (A)**

---
**128.** विश्व जल दिवस मनाया जाता है - (A) 22ⁿᵈ अक्टूबर को (B) 22ⁿᵈ जनवरी को (C) 22ⁿᵈ मार्च को (D) 22ⁿᵈ मई को

*World Water Day is celebrated on - (A) 22ⁿᵈ October (B) 22ⁿᵈ January (C) 22ⁿᵈ March (D) 22ⁿᵈ May*

**✅ सही उत्तर / Correct Answer: (C)**

---
**129.** आर्कटिक मरूस्थल का दूसरा नाम है- (A) टुण्ड्रा (B) सवाना (C) टैगा (D) स्टेपीज

*Arctic Desert is also known as - (A) Tundra (B) Savanna (C) Taiga (D) Steppes*

**✅ सही उत्तर / Correct Answer: (A)**

---
**130.** भारत में 1936 में स्थापित प्रथम राष्ट्रीय उद्यान का नाम रखा गया था - (A) कान्हा राष्ट्रीय उद्यान (B) भरतपुर राष्ट्रीय उद्यान (C) हेली राष्ट्रीय उद्यान (D) राजाजी राष्ट्रीय उद्यान

*The first National park in India, established in 1936 was named - (A) Kanha National Park (B) Bharatpur National Park (C) Hailley National Park (D) Rajaji National Park*

**✅ सही उत्तर / Correct Answer: (C)**

---
**131.** एक शिक्षक अपने विद्यार्थियों को विभिन्न पशुओं के चित्र देता है और उन सभी पशुओं पर रंग भरने को कहता है, जो हमारे घरों में नहीं रहते। इस क्रियाकलाप का उद्देश्य है - (i) सृजनात्मकता का विकास करना (ii) अवलोकन का विकास करना (iii) वर्गीकरण कौशल का विकास करना (iv) डाटा संग्रह का विकास करना। उपर्युक्त में से कौन से सही हैं?
(A) (i),(ii) और (iv) (B) (ii),(iii) और (iv) (C) (i),(iii) और (iv) (D) (i),(ii) और (iii)

*A teacher gives his students pictures of different animals and asks them to colour all those animals which do not live in our houses. The motive of this activity is - (i) Development of creative skill (ii) Development of observational skill (iii) Development of classification skill (iv) Development of Data Collection. Which of the aforementioned are correct?*
(A) (i),(ii) and (iv) (B) (ii),(iii) and (iv) (C) (i),(iii) and (iv) (D) (i),(ii) and (iii)

**✅ सही उत्तर / Correct Answer: (D)**

---
**132.** बच्चों को पर्यावरण अध्ययन को सीखने के लिए खोजने का पर्याप्त अवसर दिया जाता है। यह इंगित करता है कि - (A) पर्यावरण अध्ययन बाल-केन्द्रित है। (B) पर्यावरण अध्ययन शिक्षक केन्द्रित है। (C) पर्यावरण अध्ययन याद करके सीखा जाता है। (D) पर्यावरण अध्ययन सूचनाओं द्वारा सीखा जाता है।

*Children get a lot of space to learn EVS through exploration. This indicates that- (A) EVS is child centric. (B) EVS is teacher centric. (C) EVS is learned through craming. (D) EVS is learned through Informations.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**133.** निम्नलिखित पद्धतियों में कौन-सी कृषि में जल संरक्षण में सहायता कर सकती है/हैं? 1. कृषि भूमि की कम या शून्य जुताई 2. खेत में सिंचाई के पूर्व जिप्सम का प्रयोग 3. फसल अवशेष को खेत में ही रहने देना
(A) केवल 1 और 2 (B) केवल 1 और 3 (C) केवल 3 (D) 1, 2 और 3

*Which of the following procedure/s is/are helpful in water conservation in Agriculture? 1. Low or zero tillage of agriculture land 2. Use of Gypsum before irrigation 3. Leaving the crop residues in the field*
(A) Only 1 and 2 (B) Only 1 and 3 (C) Only 3 (D) 1, 2 and 3

**✅ सही उत्तर / Correct Answer: (D)**

---
**134.** भारत के किस राज्य में 'पानी पंचायत' प्रारम्भ हुई? (A) केरल (B) राजस्थान (C) महाराष्ट्र (D) गुजरात

*In which state of India did 'Water Panchayat' start? (A) Kerala (B) Rajasthan (C) Maharashtra (D) Gujarat*

**✅ सही उत्तर / Correct Answer: (C)**

---
**135.** निम्न में से कौन-सा जीवाणु जल प्रदूषण के सूचक के रूप में काम आता है? (A) स्टेफाइलोकोकस (B) स्ट्रेप्टोकोकस (C) डिप्लोकोकस (D) कॉलीफॉर्म

*Which of the following bacteria is an indicator of water pollution? (A) Staphylococcous (B) Streptococcous (C) Diplococcous (D) Coliform*

**✅ सही उत्तर / Correct Answer: (D)**

---
**136.** निम्न में कौन सा पोषक चक्र सूर्य के प्रकाश से सीधे संचालित होता है? (A) कार्बन चक्र (B) नाइट्रोजन चक्र (C) सल्फर चक्र (D) फॉस्फोरस चक्र

*Which of the following nutrient cycle is directly propelled by sunlight? (A) Carbon cycle (B) Nitrogen cycle (C) Sulphur cycle (D) Phosphorus cycle*

**✅ सही उत्तर / Correct Answer: (A)**

---
**137.** जैव-ईंधन के संबंध में निम्न में से कौन सा कथन सत्य नहीं है? (A) जैव-ईंधन पारिस्थितिकी अनुकूल है। (B) जैव-ईंधन लागत प्रभावी होता है। (C) जैव-ईंधन ऊर्जा संकट के समाधान में योगदान दे सकता है। (D) जैव-ईंधन मक्का से भी बनता है।

*Which of the following statements regarding Biofuels is incorrect? (A) Biofuels are Eco Friendly. (B) Biofuels are cost-effective. (C) Biofuels can be instrumental in overcoming the energy crisis. (D) Biofuel can also be prepared from Maize.*

**✅ सही उत्तर / Correct Answer: (B)**

---
**138.** भारत में निम्नलिखित में से कौन नवीकरणीय ऊर्जा स्रोत सर्वाधिक संभाव्यता वाला है? (A) सौर शक्ति (B) लघु जल विद्युत शक्ति (C) जैव पुंज शक्ति (D) अपशिष्ट से अर्जित शक्ति

*Which among the following is the most prospective Renewable source of Energy in India? (A) Solar Energy (B) Small Hydro-electric energy (C) Biological energy (D) Energy derived from wastes*

**✅ सही उत्तर / Correct Answer: (A)**

---
**139.** निम्नलिखित में से किसे जैविक खाद के रूप में प्रयोग किया जाता है? (A) नीम (B) एजोला (C) यूरिया (D) पोटैशियम

*Which of the following is used as a biofertilizer? (A) Neem (B) Azolla (C) Urea (D) Potassium*

**✅ सही उत्तर / Correct Answer: (B)**

---
**140.** निम्नलिखित में से किसकी मात्रा अम्ल वर्षा में सबसे अधिक होती है? (A) HCl (B) HNO₃ (C) H₂SO₄ (D) H₂CO₃

*Which of the following is a major constituent of Acid rain? (A) HCl (B) HNO₃ (C) H₂SO₄ (D) H₂CO₃*

**✅ सही उत्तर / Correct Answer: (C)**

---
**141.** पर्यावरण अध्ययन में बच्चों को जोड़ने की सबसे प्रभावशाली युक्ति है- (A) पाठ्यपुस्तक का पठन (B) शिक्षक द्वारा व्याख्याएँ (C) कक्षा निदर्शन (D) किस्से कहानियाँ

*The most effective strategy to engage children in EVS is - (A) Reading of Text Books (B) Explanation by teachers (C) Classroom demonstration (D) Narratives*

**✅ सही उत्तर / Correct Answer: (D)**

---
**142.** एक शिक्षक प्रत्येक बच्चे को रद्दी सामग्री से कुछ उपयोगी वस्तु बनाने को कहता है। निम्न में से कौन से कथन में शिक्षक का शैक्षिक उद्देश्य नहीं है? (A) कक्षा के श्रेष्ठ विद्यार्थियों के बारे में निर्णय करना। (B) बच्चों में सृजनशीलता का विकास करना। (C) बच्चों को पुनश्चक्रण, पुनः प्रयोग और रूपान्तरण की संकल्पना समझाना। (D) कूड़े से बनी श्रेष्ठ वस्तुओं की प्रदर्शनी आयोजित करना।

*A teacher tells every student to make useful things from waste material. Which of the following statements is not the educational motive of the teacher? (A) Choosing the best students in the class. (B) Developing creativity among students. (C) To give students the concept of recycling, reuse and conversion. (D) Arranging an exhibition of things made from waste material.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**143.** दूसरी कक्षा की शिक्षिका तनुजा को फूल से संबंधित विषय के बारे में पढ़ाना है। उसे क्या करना चाहिए? (A) बच्चों को स्कूल के बगीचे में ले जाये जहाँ बहुत सारे फूल हैं। (B) प्रोजेक्टर पर इनके चित्र दिखायें। (C) ब्लैकबोर्ड पर कई प्रकार के फूल बनायें। (D) ब्लैकबोर्ड पर फूलों के नाम लिखें और छात्रों को अपनी नोटबुक पर उन्हें लिखने को कहें।

*Tanuja, a teacher of 2nd class, has to teach a topic related to flower. What should she do? (A) Take children in the garden of the school where there are numerous flowers. (B) To show its picture on Projector. (C) To draw various types of flowers on Blackboard. (D) To write the name of flowers on the blackboard and ask the students to write it in their copy.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**144.** एकीकृत पर्यावरण विज्ञान के रूप में ई.वी.एस. अध्ययन का क्या महत्व है? (A) प्राकृतिक और सामाजिक-सांस्कृतिक वातावरण से संबंध स्थापित करने में जागरूक और सक्षम होना। (B) सभी गतिविधियों में भाग लेने में सक्षम होना। (C) लिखित एवं प्रायोगिक में A+ प्राप्त करना। (D) विज्ञान की शिक्षा का भाषा की तुलना में अधिक आनंद लेना।

*What is the significance of EVS study, as an integrated environmental science? (A) To be aware of and able to correlate to natural and socio-cultural environment. (B) Being able to participate in all activities. (C) Scoring A+ in theory as well as in practicals. (D) To enjoy learning of science more than that of language.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**145.** देश में पर्यावरण कानूनों की समीक्षा के लिए निम्नलिखित में से किस समिति का गठन किया गया था? (A) कस्तूरी रंगन समिति (B) सुब्रमनियन समिति (C) माधव नायर समिति (D) उल्लास कारंथ समिति

*Which one of the following committees was constituted to review Environmental Laws in the country? (A) Kasturi Rangan Committee (B) Subramanian Committee (C) Madhav Nair Committee (D) Ullas Karanth Committee*

**✅ सही उत्तर / Correct Answer: (B)**

---
**146.** भारत के संविधान में वन्य जीवन का संरक्षण निम्नलिखित में से किसके अन्तर्गत आता है? 1. मौलिक कर्तव्य 2. निर्देशक सिद्धान्त 3. सातवीं अनुसूची — नीचे दिए गए कूट में से सही विकल्प का चयन कीजिए-
(A) 1 और 2 (B) 2 और 3 (C) 1 और 3 (D) 1, 2 और 3

*Protection of wildlife comes under which of the following in the Constitution of India? 1. Fundamental duties 2. Directive principles 3. Seventh schedule — Select the correct option from the codes given below-*
(A) 1 and 2 (B) 2 and 3 (C) 1 and 3 (D) 1, 2 and 3

**✅ सही उत्तर / Correct Answer: (D)**

---
**147.** निम्नताप परिरक्षण (क्रायो-प्रिजरवेशन) तकनीक द्वारा संकटग्रस्त जातियों के बीजों एवं परागकणों को लम्बे समय तक परिरक्षित किया जाता है- (A) बर्फ में (B) कार्बन टेट्राक्लोराइड में (C) तरल नाइट्रोजन में (D) अमोनिया में

*Seed and pollen grains of endangered species are preserved for a long time by cryo-preservation technology in- (A) Ice (B) Carbon tetra chloride (C) liquid nitrogen (D) ammonia*

**✅ सही उत्तर / Correct Answer: (C)**

---
**148.** वे प्रजातियां जो एक विशेष क्षेत्र तक सीमित होती हैं, कहलाती हैं- (A) महामारी प्रजाति (B) दुर्लभ प्रजाति (C) भेद्य प्रजाति (D) स्थानिक प्रजाति

*The species which are confined to a particular area are called- (A) Pandemic species (B) Extinct species (C) Vulnerable species (D) Endemic species*

**✅ सही उत्तर / Correct Answer: (D)**

---
**149.** वायुमंडल की किस परत में वर्षण, आँधी, बादल-गर्जन, बिजली चमक आदि होती हैं? (A) आयनमंडल (B) समतापमंडल (C) क्षोभमंडल (D) ओजोनमंडल

*In which layer of the atmosphere do rainfall, storm, thundering and lightening occur? (A) Ionosphere (B) Stratosphere (C) Troposphere (D) Ozonosphere*

**✅ सही उत्तर / Correct Answer: (C)**

---
**150.** जैविक कचरे से भरपूर घरेलू सीवेज के प्रवाह वाली नदी का परिणाम हो सकता है- (A) जलीय खाद्य जल जीवों की बढ़ी हुई जनसंख्या (B) जैव निम्नीकरणीय पोषक तत्वों के कारण मछली का बढ़ा हुआ उत्पादन (C) आक्सीजन की कमी से मछलियों की मौत (D) शैवाल खिलने के कारण नदी का बहुत जल्दी सूख जाना

*A river with an inflow of domestic sewage rich in organic waste may result in- (A) increased population of aquatic food web organisms (B) an increased production of fish due to biodegradable nutrients (C) death of fishes due to lack of oxygen (D) drying of the river very soon due to algal bloom*

---
**दस्तावेज़ समाप्त / End of Document**

**✅ सही उत्तर / Correct Answer: (C)**

---


## 📋 उत्तर कुंजी सारांश (Official Answer Key Summary)

| प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर |
|---|---|---|---|---|---|
| 121 | C | 122 | B | 123 | A |
| 124 | C | 125 | D | 126 | B |
| 127 | A | 128 | C | 129 | A |
| 130 | C | 131 | D | 132 | A |
| 133 | D | 134 | C | 135 | D |
| 136 | A | 137 | B | 138 | A |
| 139 | B | 140 | C | 141 | D |
| 142 | A | 143 | A | 144 | A |
| 145 | B | 146 | D | 147 | C |
| 148 | D | 149 | C | 150 | C |
