# UTET 2022 — Paper I (कक्षा 1 से 5 तक के लिए / Primary Level)
**Set – B | Booklet Series: XXII-1 | पूर्णांक/Max Marks: 150 | समय/Time: 2 घंटे 30 मिनट**

> नोट: यह दस्तावेज़ उत्तराखण्ड शिक्षक पात्रता परीक्षा (UTET) 2022, प्रथम प्रश्न-पत्र (Set-B) के आधिकारिक प्रश्न-पुस्तिका से तैयार किया गया है। मूल स्रोत: ukutet.com
>
> **नोट (उर्दू भाषा):** यूज़र के निर्देशानुसार "भाषा द्वितीय - उर्दू" (Second Language - Urdu, प्रश्न 61-90 का उर्दू विकल्प) इस दस्तावेज़ में **शामिल नहीं** किया गया है। शेष सभी भाग (बाल विकास, हिन्दी, अंग्रेज़ी, संस्कृत, गणित, पर्यावरण अध्ययन) यहाँ दिए गए हैं।

---

## अनुभाग संरचना (Structure of Sections)
| प्रश्न संख्या | भाग |
|---|---|
| 1 – 30 | बाल विकास एवं शिक्षण विज्ञान (Child Development and Pedagogy) — द्विभाषी |
| 31 – 60 | भाषा प्रथम (First Language) — हिन्दी अथवा अंग्रेज़ी (कोई एक चुनें) |
| 61 – 90 | भाषा द्वितीय (Second Language) — हिन्दी / अंग्रेज़ी / संस्कृत / ~~उर्दू~~ (कोई एक चुनें) |
| 91 – 120 | गणित (Mathematics) — द्विभाषी |
| 121 – 150 | पर्यावरण अध्ययन (Environmental Studies) — द्विभाषी |

---

# भाग 1: बाल विकास एवं शिक्षण विज्ञान (Child Development and Pedagogy) — प्रश्न 1-30

**1.** किस विधि में व्यक्ति समस्या समाधान करने के लिए सभी विकल्पों को नहीं ढूँढता है अपितु केवल उन्हीं विकल्पों का चयन करता है और समस्या का समाधान करने की कोशिश करता है जो उसे संगत प्रतीत होते हैं।
(A) स्वतः शोध अन्वेषण (B) यादृच्छिक अन्वेषण विधि (C) साधन-साध्य विश्लेषण (D) पश्चगामी अन्वेषण

*In which method, a person does not find all the options for problem solving but he only selects those options and tries to solve the problem which he finds appropriate.*
(A) Heuristics (B) Random Search Method (C) Means-ends analysis (D) Backward search

**2.** कॉलम 'A' का मिलान कॉलम 'B' से कीजिए-
कॉलम 'A': (1) ग्रामर (2) सीमैंटिक विकास (3) बेबलिंग (4) फोनोलॉजिकल विकास
कॉलम 'B': (a) पहचानने योग्य भाषा बोलने की क्षमता (b) एक भाषा में निहित नियम (c) भाषा विकास की प्रारंभिक अवस्था (d) बोलने व लिखने की भाषा के अर्थ को समझना
(A) (1-a)(2-b)(3-c)(4-d)  (B) (1-b)(2-d)(3-c)(4-a)  (C) (1-a)(2-c)(3-d)(4-b)  (D) (1-c)(2-a)(3-d)(4-b)

*Match Column A with Column B — Column A: (1) Grammar (2) Semantic development (3) Babbling (4) Phonological development; Column B: (a) ability to produce recognizable speech (b) Rules within a given language (c) An early stage of speech development (d) Understanding of the meaning of spoken and written language*
(A) (1-a)(2-b)(3-c)(4-d)  (B) (1-b)(2-d)(3-c)(4-a)  (C) (1-a)(2-c)(3-d)(4-b)  (D) (1-c)(2-a)(3-d)(4-b)

**3.** शिक्षण अधिगम प्रक्रिया को प्रभावित करने वाले मनोवैज्ञानिक कारक हैं- (1) विद्यार्थियों में अभिप्रेरणा (2) सुंदर कक्षाकक्ष (3) रूचि एवं विद्यार्थियों में अभिक्षमता (4) विद्यालय की आधारभूत संरचना
(A) 1,2,3 (B) 1,2 (C) 1,3 (D) 3,4

*The psychological factors affecting the teaching learning process are - (1) Motivation of students (2) Beautiful classroom (3) Interest and aptitude of students (4) School infrastructure*
(A) 1,2,3 (B) 1,2 (C) 1,3 (D) 3,4

**4.** विशेष आवश्यकता वाले बच्चों के लिए शिक्षण अधिगम सामग्री होनी चाहिए- (A) रंग बिरंगी (B) बहुसंवेदी (C) आकार में बड़ी (D) आकर्षक

*Teaching learning material for children with special needs should be - (A) Colourful (B) Multisensory (C) Big in size (D) Attractive*

**5.** जब एक विद्यार्थी उस व्यवहार को निष्पादित करना सीखता है जो सकारात्मक परिणाम देता है और उस व्यवहार को करने से बचता है जिससे उसे नकारात्मक परिणाम मिले, यह उदाहरण है: (A) क्रिया प्रसूत अनुबंधन का (B) शास्त्रीय अनुबंधन का (C) समक्षणिक अनुबंधन का (D) संकेत कालिक अनुबंधन का

*When a student learns to perform behaviours that produce positive outcomes and to avoid behaviour that yields negative outcome, this is an example of: (A) Operant conditioning (B) Classical conditioning (C) Simultaneous conditioning (D) Trace conditioning*

**6.** आप किस परिस्थिति में विद्यार्थियों को सतत् पुनर्बलन देंगे: (A) पूर्व व्यवहार को स्थापित करने के लिए (B) नए व्यवहार को स्थापित करने के लिए (C) नए व्यवहार को बनाए रखने के लिए (D) (B) और (C) दोनों

*In which situation will you give continuous reinforcement to students: (A) For establishing a past behaviour (B) For establishing a new behaviour (C) In maintaining a new behaviour (D) Both (B) and (C)*

**7.** यदि आपने कभी किसी को अंधेरे कमरे में फ्लैशलाइट लहराते हुए देखा और उसके पीछे आपको रोशनी का पथ दिखाई दिया तो आप विज्ञ हैं ......... स्मृति के संचालन से। (A) लघुकालीन स्मृति (B) दीर्घकालीन स्मृति (C) प्रक्रियात्मक स्मृति (D) संवेदी स्मृति

*If you've ever watched someone wave a flashlight in a darkroom and perceived trails of light behind it, you are familiar with the operation of --------- memory. (A) Short term memory (B) Long term memory (C) Procedural memory (D) Sensory memory*

**8.** निम्नलिखित में से अधिगम अक्षम बच्चे की कौन सी विशेषताएँ हैं: (1) अच्छी ध्यान अवधि (2) लिखते समय अक्षरों को छोड़ना (3) गणितीय चिन्हों को समझने में कठिनाई
(A) 1,2,3 (B) 1,3 (C) 2,3 (D) 1,2

*Which of the following are the characteristics of a learning disabled child: (1) Good attention span (2) Omit words while writing (3) Difficulty in understanding mathematical symbols*
(A) 1,2,3 (B) 1,3 (C) 2,3 (D) 1,2

**9.** निम्नलिखित में से कौन सा विद्यालय में समावेशी वातावरण के विकास में सहायक होगा? (A) सभी गतिविधियों में पूर्ण प्रतिभागिता सुनिश्चित करना (B) बाधारहित वातावरण का सृजन (C) पाठ्यचर्या अनुकूलन एवं कक्षा-कक्ष प्रबंधन (D) उपरोक्त सभी

*Which of the following will help in the development of inclusive environment in school: (A) Ensure full participation in all activities (B) Creation of barrier free environment (C) Curriculum adaptation and classroom management (D) All of the above*

**10.** निम्नलिखित में से कौन सा कथन समावेशित शिक्षा की अवधारणा को अभिव्यक्त करता है? (1) सभी बच्चे साथ सीखते हैं। (2) क्षमताओं के स्थान पर अक्षमताओं पर अधिक ध्यान। (3) व्यक्तिगत सीखने के तरीके पर ध्यान। (4) समतापूर्वक सभी विद्यार्थियों की आवश्यकताओं का सम्मान
(A) 1,2,3 (B) 1,2,3,4 (C) 1,3,4 (D) 2,3,4

*Which of the following statements express the concept of Inclusive education? (1) All children learn together (2) Focus on disabilities rather than abilities (3) Focus on individual learning style (4) Honour the needs of all students equitably*
(A) 1,2,3 (B) 1,2,3,4 (C) 1,3,4 (D) 2,3,4

**11.** एन.ई.पी. 2020 केन्द्रित करती है: (A) रचनात्मक आकलन पर आधारित प्रगति कार्ड पर (B) योगात्मक आकलन पर आधारित प्रगति कार्ड पर (C) व्यापक आकलन पर आधारित प्रगति कार्ड पर (D) 360° समग्र प्रगति कार्ड पर

*NEP 2020 focuses on: (A) Formative assessment based progress card (B) Summative assessment based progress card (C) Comprehensive assessment based progress card (D) 360° holistic progress card*

**12.** निम्नलिखित में से आकलन का कौन सा तरीका शिक्षक को न केवल प्रत्येक बच्चे के सीखने में अंतर को समझने अपितु स्वयं के शिक्षण अधिगम को बच्चों की आवश्यकताओं एवं सीखने के तरीके के अनुसार समीक्षा करने, संशोधित व चिंतन करने में सहायता करता है: (A) अधिगम का आकलन (B) अधिगम के रूप में आकलन (C) अधिगम के लिए आकलन (D) प्रोन्नति के लिए आकलन

*Which of the following way of assessment helps teachers not only to understand the learning gaps of each child but also to reflect, review and modify their teaching learning as per the need and learning styles of students: (A) Assessment of learning (B) Assessment as learning (C) Assessment for learning (D) Assessment for promoting*

**13.** रक्षा अपने सभी काम निर्धारित समय में पूरे करती है। वह नियमित रूप से पढ़ाई करती है क्योंकि वह डॉक्टर बनना चाहती है। वह: (A) आंतरिक रूप से अभिप्रेरित है। (B) बाह्य रूप से अभिप्रेरित है। (C) प्रशंसा पाने के लिए अभिप्रेरित है। (D) कठिन परिश्रमी है किन्तु महत्वाकांक्षी है।

*Raksha completes all her work in due time. She studies regularly because she wants to be a Doctor. She is: (A) Intrinsically motivated. (B) Extrinsically motivated. (C) Motivated to be praised. (D) Hardworking but ambitious.*

**14.** कोई विद्यार्थी विद्यालय में कितना अभिप्रेरित है यह जानने के लिए आप किस तकनीक का सरलता से प्रयोग कर सकते हैं: (A) अवलोकन विधि (B) प्रक्षेपीय विधि (C) प्रश्नावली विधि (D) व्यक्तिवृत विधि

*Which technique can you use easily to know how much a child is motivated in school: (A) Observation technique (B) Projective technique (C) Questionnaire technique (D) Case study technique*

**15.** मैसलो के अनुसार, एक स्थिति जिसमें व्यक्ति अपनी पूर्ण क्षमता तक पहुँच जाता है, को कहते हैं: (A) स्व-जागरूकता (B) आत्मसिद्धि (C) आत्म-सम्मान (D) आत्म-प्रभावकारिता

*According to Maslow, a state in which people reach their fullest potential is called as: (A) self-awareness (B) self-actualization (C) self-esteem (D) self-efficacy*

**16.** यदि किसी बच्चे में प्रशिक्षण के बाद किसी ज्ञान या कौशल को प्राप्त करने की क्षमता है तो यह दर्शाता है उसकी: (A) बुद्धि को (B) अभिक्षमता को (C) रूचि को (D) अभिवृत्ति को

*If a child has a capacity to acquire some specific knowledge or skill after training then this indicates his: (A) Intelligence (B) Aptitude (C) Interest (D) Attitude*

**17.** कथन-1: संवेग के विकास को परिपक्वता तथा अधिगम दोनों ही प्रभावित करते हैं। कथन-2: ये दोनों प्रक्रियाएँ एक दूसरे पर निर्भर करती हैं तथा परस्पर संबंधी हैं।
(A) कथन-1 सत्य है किन्तु कथन-2 असत्य है। (B) केवल कथन-2 सत्य है। (C) दोनों कथन सत्य हैं। (D) दोनों कथन असत्य हैं।

*Statement-1: Maturation and learning both affect the development of emotions. Statement-2: Both these processes depend on each other and are mutually related.*
(A) Statement-1 is true but statement-2 is false. (B) Only statement-2 is true. (C) Both the statements are true. (D) Both the statements are false.

**18.** निम्नलिखित में से कौन सा प्रश्न बच्चों की अवधारणात्मक समझ के परीक्षण हेतु सबसे उपयुक्त है? (A) भारत की राजधानी क्या है? (B) नौ ग्रहों के नाम बताइए। (C) रेगिस्तान में पौधों के काँटे क्यों होते हैं? (D) किसे राष्ट्रपिता कहा जाता है?

*Which of the following question will be most appropriate for testing the conceptual understanding of students? (A) What is the capital of India? (B) Name the nine planets. (C) Why plants in desert have thorns? (D) Who is called the father of the Nation?*

**19.** निम्नलिखित में से आप किस बच्चे को सृजनात्मक कहेंगे? (A) जो नए विचार प्रस्तुत करता है। (B) जो नई वस्तुएँ बनाता है। (C) जो अपने कार्य में नवीनता और मौलिकता का प्रदर्शन करता है। (D) उपरोक्त सभी

*Out of the following, which child will you say is creative? (A) Who presents new thoughts. (B) Who creates new things. (C) Who shows novelty and originality in his work. (D) All of the above*

**20.** 6 से 8 वय वर्ग के बच्चों के विकासात्मक कार्य हैं: (1) दो शब्द बोलना सीखना। (2) सरल खेलों के लिए शारीरिक कौशल सीखना। (3) पढ़ने, गणना करने एवं लिखने के मूलभूत कौशलों का विकास।
(A) केवल 1 (B) 1 एवं 2 (C) 2 एवं 3 (D) केवल 3

*Developmental tasks of children aged 6 to 8 years are: (1) learn to speak two words. (2) learn physical skills for simple games. (3) develops basic skills in reading, calculating and writing.*
(A) only 1 (B) 1 & 2 (C) 2 & 3 (D) only 3

**21.** रीना एक प्रतिभावान छात्रा है। बुद्धि परीक्षण के आधार पर उसे मेधावी कहा जा सकता है। किन्तु वह सदैव महसूस करती है कि उसकी कक्षा नीरस है। एक शिक्षक के रूप में आप रीना की कैसे सहायता कर सकते हैं? (A) उसे सामान्य शिक्षण विधि द्वारा पढ़ाकर (B) उच्च स्तरीय कौशल विकास हेतु रोचक शिक्षण विधि का प्रयोग करके (C) उसको कक्षा का मॉनिटर बनाकर (D) उसको अधिक गृहकार्य देकर

*Reena is a talented girl. On the basis of intelligence testing, she can be said brilliant but she always feels that her class is boring. How can you help Reena as a teacher? (A) Teaching her by simple method (B) Use interesting teaching methods for developing higher order skills (C) Make her class monitor (D) Give her more home assignments*

**22.** विद्यार्थियों में टीम भावना के विकास में निम्नलिखित में से किस प्रकार का वातावरण सहायक होगा? (A) प्रतिस्पर्धात्मक (B) सहयोगात्मक (C) व्यक्तिपरक (D) अनुशासित

*Which of the following environment will help in the development of team spirit among students? (A) Competitive (B) Cooperative (C) Individualistic (D) Disciplined*

**23.** कक्षा शिक्षण के दौरान निम्नलिखित में से कौन सी चीज सुनिश्चित की जानी चाहिए: (A) डिजिटल टी.एल.एम. का प्रयोग (B) आई.सी.टी. का अधिकतम उपयोग (C) वैयक्तिक भिन्नता के अनुरूप शिक्षण (D) व्याख्यान विधि का प्रयोग

*During classroom teaching which of the following should be ensured: (A) Use of digital TLM (B) Maximum use of ICT (C) Teaching according to individual differences (D) Use of lecture method*

**24.** निम्नलिखित में से कौन संवेगात्मक बुद्धि की विशेषताएँ हैं: (1) उच्च आई.क्यू. किन्तु अस्थिर (2) दूसरों को अभिप्रेरित करने में सक्षम (3) स्वयं के संवेगों का प्रबंधन
(A) 1 और 2 (B) 1,2,3 (C) 1 और 3 (D) 2 और 3

*Which of the following are the traits of emotional intelligence: (1) High I.Q. but instable (2) Being able to motivate others (3) Managing one's own emotions*
(A) 1 & 2 (B) 1,2,3 (C) 1 & 3 (D) 2 & 3

**25.** पियाजे के अनुसार, बच्चे विश्व के विषय में बढ़ते ज्ञान का निर्माण निम्न दो प्रक्रियाओं द्वारा करते हैं: (A) आत्मसात्यकरण एवं अनुकूलन (B) आत्मसात्यकरण एवं स्केफोल्डिंग (C) स्कीमा एवं आत्मसात्यकरण (D) स्कीमा एवं अनुकूलन

*According to Piaget, children build increasing knowledge of the world through the following two processes: (A) Assimilation and accommodation (B) Assimilation and scaffolding (C) Schema and assimilation (D) Schema and accommodation*

**26.** छोटे बच्चों में स्वयं के दृष्टिकोण को दूसरों से भिन्न करने में असमर्थता को क्या कहा जाता है? (A) संरक्षण (B) अहंभाव (C) अंतःस्थितीय चिंतन (D) वस्तु-स्थायित्व

*The inability of young children to distinguish their own perspective from that of others is called as: (A) Conservation (B) Egocentrism (C) Interpropositional thinking (D) Object permanence*

**27.** कोलबर्ग के सिद्धांत के पारंपरिक स्तर पर नैतिकता को जाँचा जाता है: (A) समाज के नियम कानून के आधार पर (B) इसके परिणामों के आधार पर (C) अमूर्त सिद्धान्तों और मूल्यों के आधार पर (D) इनमें से कोई नहीं

*At the conventional level of Kohlberg's theory morality is judged in terms of: (A) laws and rules of society (B) its consequences (C) abstract principles and values (D) none of these*

**28.** बहुत प्रकार की बुद्धियाँ होती हैं जैसे शाब्दिक, गणितीय, शारीरिक-गत्यात्मक आदि। इस अवधारणा को किसके द्वारा दिया गया: (A) बीने (B) गार्डनर (C) स्टर्नबर्ग (D) बेचलर

*There are several kinds of intelligence such as verbal, mathematical, bodily-kinesthetic etc. This concept was given by: (A) Binet (B) Gardner (C) Sternberg (D) Wechsler*

**29.** कथन: ऐसे शीलगुण जो अत्यधिक अनुवांशिक होते हैं, उन्हें पर्यावरणीय कारकों से दृढ़तापूर्वक प्रभावित किया जा सकता है। व्याख्या: लम्बाई अत्यधिक अनुवांशिक होती है, किन्तु पोषण एवं अन्य कारकों के परिणामस्वरूप बहुत से देशों में औसत लम्बाई बढ़ी है।
(A) कथन सत्य है व उसकी व्याख्या भी सत्य है। (B) कथन सत्य है किन्तु उसकी व्याख्या असत्य है। (C) कथन व व्याख्या दोनों ही असत्य हैं। (D) कथन असत्य है किन्तु व्याख्या सत्य है।

*Statement: Traits that are highly heritable can be strongly influenced by environmental factors. Explanation: Height is highly heritable yet average height has increased in many countries as a result of improved nutrition and other factors.*
(A) Statement is correct and its explanation is also correct. (B) Statement is true but its explanation is false. (C) Both statement and explanation are false. (D) Statement is false but explanation is true.

**30.** कथन-1: जितना अधिक सूचना के प्रसंस्करण के विस्तार हेतु प्रयास किए जाएँगे उतनी ही सरलता से बाद में सूचना को याद किया जा सकेगा। कथन-2: जब हमें नई सूचना प्राप्त होती है उस समय प्रसंस्करण का स्तर जितना गहरा होता है तो सूचना के दीर्घकालिक स्मृति में प्रवेश करने की संभावना उतनी अधिक होती है।
(A) केवल कथन-1 सही है। (B) केवल कथन-2 सही है। (C) न कथन-1, न ही कथन-2 सही है। (D) दोनों कथन 1 व 2 सही हैं।

*Statement-1: The greater the effort expended in processing information, the more readily the information will be recalled later. Statement-2: Deeper the level of processing that takes place when we encounter new information, the more likely the information is to enter long term memory.*
(A) Only statement-1 is correct. (B) Only statement-2 is correct. (C) Neither statement-1 nor statement-2 is correct. (D) Both the statements 1 & 2 are correct.

---

# भाग 2: भाषा प्रथम - हिन्दी (First Language - Hindi) — प्रश्न 31-60

**31.** निम्नांकित में कौन सा कथन सही है - (A) द्रुत पाठ में मौन पाठ उपयुक्त नहीं है। (B) काव्य शिक्षण में मौन पाठ वर्जित है। (C) मौन पाठ से वाचन क्षमता विकसित होती है। (D) मौन पाठ रसानुभूति में सहायक होता है।

**32.** प्राथमिक स्तर पर भाषा सीखने की सरल-स्वाभाविक विधि क्या है - (A) संसर्ग अथवा अनुकरण विधि (B) अनुवाद विधि (C) प्रत्यक्ष शिक्षण विधि (D) संरचना विधि

**33.** गद्य की नाटक विधा का प्राण तत्व क्या है - (A) कथावस्तु (B) पात्र (C) संवाद (D) भाषा-शैली

**34.** निम्नलिखित में मातृभाषा शिक्षण का भावात्मक उद्देश्य बताइए - (A) छात्रों को विभिन्न लेखन-शैलियों से परिचित कराना (B) सांस्कृतिक मूल्यों एवं धार्मिक विश्वासों का ज्ञान कराना। (C) छात्रों को विषयानुकूल भाषा-शैली में भावाभिव्यक्ति करने की क्षमता प्रदान करना। (D) छात्रों में अपनी भाषा व साहित्य के प्रति आदर व रूचि जगाना।

**35.** मौखिक भाषा शिक्षण की प्रत्यक्ष विधियों में कौन-सी विधि अप्रासंगिक है - (A) वार्तालाप (B) भाषण (C) गद्य शिक्षण (D) अभिनय

**36.** भारत के संविधान की किस अनुसूची में मान्यता-प्राप्त भारतीय भाषाओं का उल्लेख है? (A) तीसरी अनुसूची (B) पाँचवीं अनुसूची (C) सातवीं अनुसूची (D) आठवीं अनुसूची

**37.** रस निरूपण में मनोगत भाव को व्यक्त करने वाले शारीरिक विकार कहलाते हैं- (A) स्थायी भाव (B) विभाव (C) अनुभाव (D) संचारी भाव

**38.** वर्तमान हिन्दी का सही विकास-क्रम बताइए- (A) पालि-प्राकृत-अपभ्रंश-हिन्दी (B) प्राकृत-पालि-अपभ्रंश-हिन्दी (C) अपभ्रंश-पालि-प्राकृत-हिन्दी (D) पालि-अपभ्रंश-प्राकृत-हिन्दी

**39.** उच्चारण की दृष्टि से कौन सा व्यंजन वर्ग तालव्य वर्ग है? (A) क, ख, ग, घ (B) त, थ, द, ध (C) च, छ, ज, झ (D) ट, ठ, ड, ढ

**40.** 'रवि अभाव लखि रैन में, दिन लखि चन्द्र विहीन। सतत उदित इहि हेतु जनु, यश प्रताप मुख कीन।' प्रस्तुत पद में कौन सा अलंकार है? (A) रूपक (B) उत्प्रेक्षा (C) उपमा (D) अनन्वय

**41.** निम्नांकित पद में कौन सा छन्द है- "जो मैं नया ग्रंथ विलोकता हूँ, भाता मुझे सो नव मित्र सा है। देखूँ उसे मैं नित नेम से ही, मानो मिला मित्र मुझे पुराना।।" (A) मालिनी (B) इन्द्रवज्रा (C) उपेन्द्रवज्रा (D) वसन्ततिलका

**42.** 'अंशुमाली' का पर्यायवाची बताइए- (A) कौमुदी (B) आंजनेय (C) पतंग (D) सौदामिनी

**43.** 'बुकर पुरस्कार' विजेता प्रथम हिन्दी उपन्यासकार का नाम बताइए - (A) अरुंधति राय (B) गीतांजलि श्री (C) महाश्वेता देवी (D) उषा प्रियंवदा

**44.** 'यह प्रेम को पंथ कराल महा' के लिए सही लोकोक्ति है- (A) अरु नेह सों नातो बड़ावते है। (B) तलवार की धार पै धावनो है। (C) दुखदायी और घोर सतावनो है। (D) मन ही मन में उर भावनो है।

**45.** निम्नांकित में कौन शब्द अयादि सन्धि का उदाहरण है- (A) अन्वेषण (B) इत्यादि (C) धावक (D) ब्रह्मर्षि

**46.** निम्नलिखित लेखकों का जन्म के आधार पर सही अनुक्रम बताइए- (A) प्रताप नारायण मिश्र - बालकृष्णभट्ट - बालमुकुन्द गुप्त - राजालक्षण सिंह (B) बालमुकुन्द गुप्त - राजालक्षण सिंह - प्रतापनारायण मिश्र - बालकृष्णभट्ट (C) राजा लक्ष्मण सिंह - बालकृष्णभट्ट - प्रतापनारायण मिश्र - बालमुकुन्द गुप्त (D) बालकृष्णभट्ट - प्रताप नारायण मिश्र - बालमुकुन्द गुप्त - राजा लक्ष्मण सिंह

**47.** 'बन्दउ गुरु पद कंज, कृपासिंधु नररूप हरि। महामोह तमपुंज जासु वचन रविकर निकर।।' उक्त पंक्तियाँ किस कवि की हैं? (A) सूरदास (B) तुलसीदास (C) केशवदास (D) कुंभनदास

**48.** 'अतीत के चलचित्र' किसकी रचना है? (A) रामवृक्ष बेनीपुरी (B) महादेवी वर्मा (C) सेठ गोविन्द दास (D) श्रीराम वर्मा

**49.** 'माँ ने कहा- लड़की होना पर लड़की सी दिखाई मत देना' प्रस्तुत काव्य पंक्ति किसकी है? (A) मंगलेश डबराल (B) ऋतुराज (C) निराला (D) नागार्जुन

*निर्देश (प्रश्न 50-51): निम्नलिखित पद्यांश को पढ़कर पूछे गए प्रश्नों के सर्वाधिक उचित उत्तर वाले विकल्प का चयन कीजिए -*
"कौन तुम? संसृति-जलनिधि तीर तरंगों से फेंकी मणि एक; कर रहे निर्जन का चुपचाप प्रभा की धारा से अभिषेक? मधुर विश्रान्त और एकान्त- जगत का सुलझा हुआ रहस्य; एक करूणामय सुन्दर मौन और चंचल, मन का आलस्य।"

**50.** उपर्युक्त काव्यांश किस रचना से उद्धृत है? (A) सिद्धार्थ (B) साकेत (C) कामायनी (D) उर्वशी

**51.** उपर्युक्त पंक्तियाँ किसे सम्बोधित हैं? (A) उर्वशी को (B) पुरुरवा को (C) मनु को (D) श्रद्धा को

**52.** 'कौन तुम संसृति-जलनिधि तीर, तरंगों से फेंकी मणि एक' का भावार्थ क्या है? (A) अकस्मात् मूल्यवान् वस्तु मिल जाना। (B) तेजस्वी महापुरूष का प्रादुर्भाव। (C) योग्य व्यक्ति को तदनुरूप स्थान न मिल पाना। (D) संयोगवश संकट से सुरक्षित बच निकलना।

**53.** 'करूणामय सुन्दर मौन' से क्या भाव व्यक्त होता है? (A) हृदय की विह्वलता (B) निस्तब्धता (C) अकर्मण्यता (D) भीरूता

**54.** 'संसृति-जलनिधि तीर' में कौन सा अलंकार है? (A) अनन्वय (B) रूपक (C) उत्प्रेक्षा (D) प्रतीप

*निर्देश (प्रश्न 55-59): निम्नलिखित गद्यांश को पढ़कर पूछे गए प्रश्नों के सर्वाधिक उचित उत्तर वाले विकल्प का चयन कीजिए-*
"शिक्षा आद्यन्त एक प्रवर्धमान प्रक्रिया है। वह कुछ चाहती है, कुछ माँगती है। उसे भी कभी भूख लगती है, कभी प्यास लगती है। वह कभी मनभावन चीजों को देखना चाहती है। कभी मनोरम दृश्यों में विचरना चाहती है। शिक्षा कोई निर्जीव वस्तु नहीं है। वह जीती-जागती, निरंतर नवीन होती, और प्रतिदिन अपने पालन-पोषण के लिए नये व्यंजनों की चाहत रखने वाली एक सुन्दर सी रचना है। यह हमारे बालकों का और तदनंतर हमारे समाज का भला तभी कर सकती है जब उसे नित नया पोषण मिले और बढ़ने का पूरा खुला अवकाश मिले। यह ऐसा नहीं होता तो शिक्षा मन मसोस कर रह जाती। वस्तुतः कोई भी राष्ट्र अपनी सुरक्षा को भी केवल पुलिस और सेना पर नहीं छोड़ सकता है। बहुत बड़ी सीमा तक राष्ट्रीय सुरक्षा का आधार है- नागरिकों की शिक्षा, उनका चरित्र और उनकी अनुशासन की भावना।"

**55.** 'शिक्षा एक प्रवर्धमान प्रक्रिया है', इस कथन का आशय क्या है? (A) शिक्षा जड़ नहीं जीवन्त प्रक्रिया है। (B) शिक्षा स्वतः फलने-फूलने की प्रवृत्ति है। (C) शिक्षा मानवीय अभिवृत्तियों की पोषक है। (D) शिक्षा संसाधनों की अभिवृद्धि की चेष्टा है।

**56.** 'शिक्षा की भूख और प्यास' का आशय क्या है? (A) शिक्षा के क्षेत्र में संसाधनों की अभिवृद्धि। (B) कुशल प्रबंधन एवं प्रतिपोषण की चाह। (C) जन आकांक्षाओं की पूर्ति। (D) कुशल शिक्षक एवं आकर्षक परिवेश की परिकल्पना।

**57.** शिक्षा को जड़ता से कैसे मुक्त किया जा सकता है? (A) नित-नूतन एवं अभिनव प्रयोगों से। (B) समुचित नियोजन एवं तदनुरूप प्रतिपोषण से। (C) राजनैतिक हस्तक्षेप से। (D) वित्तीय संसाधनों से।

**58.** राष्ट्रीय सुरक्षा के लिए सर्वोच्च भूमिका है- (A) सैन्य बल की (B) अर्ध सैनिक बलों की (C) राजनेताओं की (D) अनुशासित एवं सुशिक्षित नागरिकों की

**59.** 'आद्यन्त' शब्द में कौन सी सन्धि है? (A) यण् सन्धि (B) अयादि सन्धि (C) गुण सन्धि (D) पूर्व रूप सन्धि

**60.** काव्य-शिक्षण का मूल तत्व क्या है? (A) रस निरूपण (B) ध्वनि निरूपण (C) अलंकार निरूपण (D) उपर्युक्त सभी

---

# भाग 3: First Language - English — प्रश्न 31-60

**31.** Home language is _______ in a natural way. (A) taught (B) promoted (C) acquired (D) learnt

**32.** At primary level, the objective of teaching a language is- (A) Basic Interactive Communicative Skills (BICS) (B) Cognitive Advanced Language Proficiency (CALP) (C) Memorisation of text book (D) Ability to write question answer

**33.** The most important aspect of an effective language classroom is to provide learners with an opportunity to- (A) interact (B) interfere (C) assess (D) imitate

**34.** What is the 'task' in task-based language learning? (A) A piece of work which enables learners to do an activity. (B) A piece of work for the parents to do their children's homework. (C) A piece of activity for teachers to do in the classroom. (D) A piece of work which exposes learners to language.

*Direction (Q. No. 35 to 38): Read the passage given below and answer the questions that follow by selecting the most appropriate option.*
"Read not to contradict and confuse, nor to believe and take for granted, nor to find talk and discourse but to weigh and consider. Some books are to be tasted, others to be swallowed, and some few to be chewed and digested. That is some books are to be read only in parts; others to be read, but not curiously; and some few to be read wholly, and with diligence and attention. Some books may also be read by deputy, and extracts made of them by others but that would be only in the less important arguments and the meaner sort of books; else distilled books are like common distilled waters, flashy things. Reading maketh a full man, conference a ready man, and writing an exact man."

**35.** What should be the purpose of reading a book? (A) To understand the contents (B) To weigh and consider (C) To contradict (D) To take it for granted

**36.** Why are some books to be tasted? (A) To be read with great care (B) To be read with great attention (C) To be read only in parts (D) To be read for fun

**37.** How is man's character influenced by the art of writing? (A) It makes him an exact man (B) It makes him a great writer (C) It makes him a ready man (D) It makes him a full man

**38.** What is meant by 'Chewed and digested'? (A) Understood without any effort (B) Partly read and understood (C) Thoroughly read and understood (D) None of the above

*Direction (Q. No. 39): Out of the given alternatives, choose the one that is most similar in meaning to the underlined word in the sentence-*

**39.** He had to **curtail** his leave as a lot of work was pending in his office. (A) Cancel (B) Extend (C) Shorten (D) Postpone

*Direction (Q. No. 40): Out of the given alternatives, choose the one which is closest to the opposite in meaning of the underlined word.*

**40.** My uncle is very wealthy, but rather **parsimonious** in his habits. (A) Extravagant (B) Thrifty (C) Careless (D) Strict

*Direction (Q. No. 41): Improve the underlined part of the sentence by choosing the correct option. If there is no need of improvement, the answer will be option (d).*

**41.** Either Radha or Sita forgot to take **their** umbrella. (A) Her (B) His (C) One's (D) No improvement

*Direction (Q. No. 42): An idiomatic expression/a proverb has been given below, followed by four alternatives. Choose the one which best expresses the meaning of the given idiom/proverb.*

**42.** A bolt from the blue. (A) A delayed event (B) An inexplicable event (C) An unexpected event (D) An unpleasant event

**43.** Choose the correct adjective of the noun 'Advice' - (A) Advisable (B) Advise (C) Advisedly (D) Adviser

*Direction (Q. No. 44-46): Fill in the blanks by choosing the correct option.*

**44.** Being a philanthropist, he _______ this institution. (A) Founded (B) Was founded (C) Find (D) Found

**45.** The judge acquitted him _______ the murder. (A) off (B) of (C) for (D) from

**46.** The eggs are sold by _______ dozen. (A) a (B) an (C) the (D) None of these

**47.** Point out the active voice of the following sentence - "It is being done by us." (A) We are doing it. (B) It will be done by us. (C) We can do it. (D) We must do it.

**48.** Identify the correct form of the given sentence - Dad said to Pankaj, "I will not give you pocket money." (A) Dad ordered Pankaj not to give him pocket money. (B) Dad told Pankaj that he would not give him pocket money. (C) Dad told Pankaj that I will not give you pocket money. (D) Dad said to Pankaj that he would not give her pocket money.

**49.** Choose the correct figure of speech in the following sentence - 'The wind lies asleep in the arms of dawn.' (A) Metaphor (B) Hyperbole (C) Personification (D) Oxymoron

**50.** Choose the correctly spelt word - (A) Tarif (B) Tarrif (C) Tarriff (D) Tariff

*Direction (Q. No. 51-54): Read the poem given below and answer the questions that follow by selecting the most appropriate option -*
"I Build Walls / I build Walls / Walls that protect, / Walls that shield, / Walls that say I shall not yield / Or reveal / Who I am or how I feel / I build walls / Walls that hide, / Walls that cover what's inside, / Walls that stare or smile or look away, / Silent lies, / Walls that even block my eyes / From the tears I might have cried. / I build walls / Walls that never let me / Truly touch / Those I love so very much. / Walls that need to fall! / Walls meant to be fortresses / Are prisons after all."

**51.** What are the walls in this poem made of? (A) Blood and flesh (B) Hidden feelings and thoughts (C) Bricks or any physical material (D) Cement and tiles

**52.** The expression 'silent lies' in the poem implies that - (A) Walls make one hide one's true feelings. (B) Walls lie silently around all of us. (C) Walls are silent. (D) Walls are liars.

**53.** Why is it not a good idea to have these 'Walls'? (A) They are made of bricks (B) They hurt others (C) They act as a fortress (D) They act as a prison and keep loved ones away

**54.** Walls built to protect us ultimately turn into a prison. It is an example of a - (A) puzzle (B) riddle (C) satire (D) paradox

*Direction (Q. No. 55-57): Point out the error in the following sentences. If there is no mistake, the answer is 'No error'.*

**55.** I and Tina will go to the market in the evening. (A) I and Tina (B) will go to the market (C) in the evening (D) No error

**56.** I would never apologise if I were you. (A) I would (B) never apologise if (C) I were you (D) No error

**57.** So quickly did she ran upstairs that she overtook me. (A) So quickly (B) did she ran upstairs (C) that she overtook me (D) No error

**58.** In the following sentence, omit 'too' without changing its meaning and select the most appropriate option for it- "She is too poor to buy costly books." (A) She is so poor to buy costly books. (B) She is very poor to buy costly books. (C) She is so poor that she can't buy costly books. (D) She is so poor that she could not buy costly books.

**59.** The study of words and their meanings is known as- (A) Phonetics (B) Syntax (C) Linguistics (D) Semantics

**60.** Which one of the following is not a language component- (A) Grammar (B) Speech (C) Manuscript (D) Sound system

---

# भाग 4: भाषा द्वितीय - हिन्दी (Second Language - Hindi) — प्रश्न 61-90

*निर्देश (प्रश्न 61-65): निम्नलिखित गद्यांश को पढ़कर पूछे गए प्रश्नों के सर्वाधिक उचित उत्तर वाले विकल्प का चयन कीजिए -*
"साहित्य को मानव जीवन की कोमल-कांत आंतरिक भावनाओं का वाहक माना गया है, हालाँकि उनका आधार जीवन का ऊबड़-खाबड़ कठोर और यथार्थ धरातल ही हुआ करता है। मानव मन कोमल, भावुक और अन्य चमत्कारी भावनाओं से भरा होता है, जोकि साहित्य के अलौकिक या पारलौकिक विचारों, धारणाओं तथा चेतनाओं पर चिंतन करने योग्य है। साहित्य जीवन को कई प्रकार के आश्वासन, कई प्रकार के विश्वास तथा कई प्रकार के आश्रय प्रदान करता है। साहित्य शब्द एवं भावनाओं से रचा जाता है, शब्द अक्षरों से बना है और अक्षर को सनातन धर्म के अनुसार सत्य, ब्रह्म का रूप माना गया है। आध्यात्मिक या धार्मिक परम्परा में जैसे ब्रह्म कभी नहीं खत्म किया जा सकता, वैसे ही आधुनिक विज्ञान द्वारा यह सिद्ध किया गया है कि शब्द कभी मारा या विनाशित नहीं किया जा सकता। ठीक इसी प्रकार साहित्य का रूप भी अजर-अमर रहता है। वह युगानुयुग मानव पीढ़ी को अनुप्राणित करता रहता है। साहित्य युगों-युगों तक मनुष्यों की चेतना को संबल प्रदान करते रहते हैं। उदाहरण के रूप में हम भक्ति काल से रचे गए कबीर, जायसी, सूर, तुलसी द्वारा रचित साहित्य को भी ले सकते हैं। उपर्युक्त सभी प्रकार का साहित्य अभी तक भक्ति एवं धार्मिक मार्गदर्शन के लिए हमारे काम आता है।"

**61.** साहित्य को मानव-जीवन में क्या माना गया है? (A) कोमल-कांत आंतरिक भावनाओं का वाहक (B) जीवन का ऊबड़-खाबड़ धरातल (C) जीवन का कठोर और यथार्थ धरातल (D) मानव जीवन का चिंतन

**62.** मानव मन किससे भरा रहता है? (A) कोमल भावनाओं से भरा रहता है। (B) भावुक भावनाओं से भरा रहता है। (C) चमत्कारी भावनाओं से भरा रहता है। (D) इन सभी भावनाओं से भरा रहता है।

**63.** साहित्य जीवन को क्या प्रदान करता है? (A) आश्वासन (B) विश्वास और आश्रय (C) (A) तथा (B) दोनों (D) अन्य

**64.** भक्तिकाल के प्रसिद्ध कवि हैं - (A) कबीर, जायसी और चन्दबरदाई (B) सूर, तुलसी और बिहारी (C) कबीर, जायसी, सूर और तुलसी (D) इनमें से कोई नहीं

**65.** सनातन धर्म के अनुसार किसे सत्य, ब्रह्म का रूप माना गया है - (A) विज्ञान (B) अक्षर (C) मानव मन (D) भक्ति

**66.** रामधारी सिंह दिनकर को उनकी किस रचना के लिए साहित्य अकादमी पुरस्कार मिला? (A) लोकायतन (B) उर्वशी (C) संस्कृति के चार अध्याय (D) रश्मिरथी

**67.** त, थ, द, ध, न का उच्चारण होता है - (A) तालु से (B) नासिका से (C) दंत से (D) कंठ से

**68.** हिन्दी साहित्य का स्वर्ण युग माना गया है - (A) आदिकाल (B) भक्तिकाल (C) रीतिकाल (D) आधुनिक काल

**69.** व्याकरण शिक्षण की वह पद्धति अपेक्षाकृत उचित है, जिसमें - (A) बच्चे नियमों को कण्ठस्थ कर लेते हैं। (B) बच्चे उदाहरणों से नियमों की ओर जाते हैं। (C) बच्चे नियमों से उदाहरणों की ओर जाते हैं। (D) बच्चे सूत्रों का प्रयोग करते हैं।

**70.** "तुम्ह तौ कालु हाँक जनु लावा" पंक्ति में निहित अलंकार है - (A) उपमा (B) उत्प्रेक्षा (C) अनुप्रास (D) रूपक

**71.** 'रवीन्द्र' शब्द में कौन-सी संधि है? (A) दीर्घ संधि (B) गुण संधि (C) वृद्धि संधि (D) यण् संधि

**72.** 'व्यापारिक' शब्द में प्रत्यय है - (A) रिक (B) इक (C) ईक (D) पारिक

**73.** 'प्रगल्भ' का अर्थ होगा - (A) दयालु (B) वाचाल (C) विनम्र (D) कठोर

**74.** निम्नांकित में कौन सा शब्द 'लक्ष्मी' का पर्यायवाची नहीं है - (A) कमला (B) हरिप्रिया (C) भार्गवी (D) अम्बालिका

**75.** हिंदी साहित्य में 'कलम का जादूगर' किसे कहा जाता है? (A) यशपाल (B) महावीर प्रसाद द्विवेदी (C) रामवृक्ष बेनीपुरी (D) विद्यापति

**76.** भाषा शिक्षण के अंतर्गत वर्तनी संबंधी त्रुटियों का निवारण किया जा सकता है - (A) वर्तनी का शुद्ध उच्चारण एवं लेखन करवा कर। (B) त्रुटियों का प्रकार बता कर। (C) त्रुटियों की उपेक्षा कर। (D) वर्तनी के बारे में कुछ बातें बताकर।

**77.** प्रारम्भिक स्तर पर बच्चों के भाषा आकलन के लिए आप किसे महत्वपूर्ण मानते हैं? (A) किसी कहानी को नाटक में रूपान्तरित करना। (B) लिखित परीक्षाओं का आयोजन करना। (C) किसी विषय पर अपने विचार प्रकट करना। (D) उपरोक्त सभी

**78.** बहु सांस्कृतिक कक्षा-कक्ष में आप एक भाषा शिक्षक के रूप में किस बात को अधिक महत्व देंगे- (A) छात्रों को व्याकरण सिखाना। (B) स्वयं शुद्ध भाषा का प्रयोग करना। (C) पाठ्यपुस्तक के प्रत्येक पाठ को भली-भाँति समझाना। (D) बच्चों को भाषा प्रयोग के अधिक से अधिक अवसर प्रदान करना।

**79.** कहानी सुनाने से - (A) बच्चे अनुशासित होते हैं। (B) बच्चों की कल्पना शक्ति व चिंतन शक्ति का विकास होता है। (C) बच्चे प्रसन्न होते हैं। (D) बच्चे शांत होकर कक्षा में बैठे रहते हैं।

**80.** "भाषा अर्जन क्षमता" किससे संबंधित है? (A) जीन पियाजे (B) स्किनर (C) पावलव (D) नोम चॉमस्की

**81.** 'नवग्रह' में कौन सा समास है - (A) तत्पुरुष (B) द्वन्द्व (C) कर्मधारय (D) द्विगु

**82.** तुलसी ने विनयपत्रिका तथा कवितावली की रचना निम्नलिखित में से किस भाषा में की - (A) अवधी (B) ब्रजभाषा (C) बुंदेली (D) भोजपुरी

**83.** "मेरे तो गिरिधर गोपाल, दूसरो न कोई। जाके सिर मोर मुकुट, मेरो पति सोई।।" उपर्युक्त पंक्तियों में कौन सा रस है - (A) शांत रस (B) शृंगार रस (C) करूण रस (D) हास्य रस

**84.** "सुनु सिय सत्य असीस हमारी। पूजिहि मन कामना तुम्हारी।।" उपर्युक्त पंक्तियों में कौन सा छंद है - (A) सोरठा (B) दोहा (C) बरवै (D) चौपाई

**85.** हिन्दी के प्रसिद्ध पत्रकार और टेलीविजन धारावाहिक लेखक को "क्याप" कहानी संग्रह के लिए 2005 के साहित्य अकादमी पुरस्कार से सम्मानित किया गया, उनका नाम है - (A) मन्नू भण्डारी (B) सत्यजीत राय (C) कृष्णनाथ (D) मनोहर श्याम जोशी

*निर्देश (प्रश्न 86-90): निम्नलिखित गद्यांश को पढ़कर पूछे गए प्रश्नों के सर्वाधिक उचित उत्तर वाले विकल्प का चयन कीजिए -*
"जो लोग अपनी असफलताओं के लिए या जीवन में गतिरोध के हालातों को जिम्मेदार ठहराते हैं, वे लोग या तो गलत हैं या हालात से डरते हैं। वे या तो जीवन को समझ नहीं पाए या उलझनों में फँसे हुए हैं। वे या तो आलसी हैं या अकर्मण्य हैं। एक कारण और भी हो सकता है कि उनकी नीयत और नीति में मेल न हो। यह अति आवश्यक है कि नीयत और नीति दोनों एक सूत्र में पिरोई हुई हों अर्थात् मेल खाती हों। ऐसा कदापि संभव नहीं है और नीयत मानसिक इच्छा है, जो खोटी भी हो सकती है और खरी भी। खोटी नीयत वाला व्यक्ति कदापि इस संसार में नहीं टिक सकता और यदि टिकेगा, तो बहुत कम समय के लिए, केवल तब तक जब तक उसकी नीयत खुलकर सामने नहीं आती क्योंकि नीति की जननी नीयत है और जब जननी में ही कोई दोष है, तो संतान में कोई न कोई विकृति अवश्य आ जायेगी। ऐसे में वह मनुष्य गलत नीयत एवं नीति के कारण पतन का भागी होगा। हालातों को असफलता के लिए जिम्मेदार ठहराना ठीक नहीं लगता, क्योंकि हालात तो उनके साथ भी वही होते हैं, जो सफलता प्राप्त करते हैं। यदि कोई व्यक्ति अपनी असफलताओं की जिम्मेदारी खुद नहीं ले सकता, तो वह अपनी सफलता की जिम्मेदारी लेने के काबिल नहीं है। जीवन का असली आनंद तो तभी है, जब परिस्थितियाँ विषम हों।"

**86.** किस तरह के लोगों की नीयत और नीति में मेल नहीं रहता है? (A) हालात को जिम्मेदार ठहराने वाले लोग (B) जीवन को न समझने वाले लोग (C) अकर्मण्य व आलसी लोग (D) उपर्युक्त सभी

**87.** खोटी नीयत वाला व्यक्ति इस संसार में क्यों नहीं टिक पाता? (A) गलत नीयत या नीति के कारण (B) अवगुणों के कारण (C) उदारता के कारण (D) समय अभाव के कारण

**88.** जो लोग जीवन को समझ नहीं पाए वे कौन हैं? (A) साधु लोग (B) विद्वान लोग (C) अकर्मण्य व आलसी लोग (D) नादान लोग

**89.** लेखक ने नीति की जननी किसे कहा है? (A) नीयत को (B) सोच को (C) व्यवहार को (D) समय को

**90.** जीवन का असली आनंद कब मिलता है? (A) खुशियों में (B) उत्सवों में (C) विषम परिस्थितियों में (D) मित्रों के साथ

---

# भाग 5: Second Language - English — प्रश्न 61-90

*Direction (Q. No. 61): Identify the figure of speech used in the given sentence:*

**61.** The camel is the ship of the desert. (A) Pun (B) Personification (C) Apostrophe (D) Metaphor

*Direction (Q. No. 62): Choose the appropriate active voice to the given statement from the options provided.*

**62.** Priyanka has solved the issue. (A) The issue have been solved by Priyanka. (B) The issue is solved by Priyanka. (C) The issue has been solved by Priyanka. (D) The issue had been solved by Priyanka.

*Direction (Q. No. 63): Transform the following sentence into negative without changing its meaning and select the most suitable option:*

**63.** Hardly had Ram seen me when he called. (A) No sooner had Ram seen me than he called me. (B) No soon had Ram seen me he called. (C) No sooner Ram seen me he called. (D) No sooner had Ram seen me that he called.

*Direction (Q. No. 64): Choose the correct alternative:*

**64.** Rohan _______ the movie before he read the review: (A) watches (B) have watched (C) had watched (D) was watching

**65.** The alphabetic method, the phonic method, the board method and the sentence method are associated with: (A) Listening (B) Speaking (C) Reading (D) Writing

**66.** Learning a language means _______: (A) Learning all the skills of language (B) Learning and using language skills in appropriate situations (C) Learning to speak fluently in public (D) Writing good books in that language

**67.** Which among the following is an example of onomatopoeia? (A) Smog (B) UNESCO (C) Buzz (D) Edit

**68.** TBLT in second language teaching is: (A) Task Based Language Training (B) Task Book Language Teaching (C) Tool Based Language Teaching (D) Task Based Language Teaching

**69.** Story telling, as a strategy in language teaching, is aimed at _______: (A) Learning the morals (B) Learning to retell the story (C) Engaging learners with language (D) Testing the memory of learners

**70.** Which one of the following activities comes under CALP? (A) Making reservations (B) Answering calls (C) Making an appointment for a saloon (D) Writing book reviews

**71.** What is the status given to English by the Indian Constitution? (A) National language (B) Link language (C) Official language (D) Associate official language

*Direction (Q.No. 72-75): Read the poem given below and answer the questions that follow by selecting the most appropriate option:*
"Two roads diverged in a yellow wood, / And sorry I could not travel both / And be one traveller, long I stood / And looked down one as far as I could / To where it bent in the undergrowth; / Then took the other, as just as fair, / And having perhaps the better claim, / Because it was grassy and wanted wear; / Though as for that the passing there / Had worn them really about the same, / And both that morning equally lay / In leaves no step had trodden black. / Oh, I kept the first for another day! / Yet knowing how way leads on to way, / I doubted if I should ever come back. / I shall be telling this with a sigh / Somewhere ages and ages hence / Two roads diverged in a wood, and / I took the one less travelled by, / And that has made all the difference." *(The Road Not Taken — Robert Frost)*

**72.** Where was the poet? (A) In the city (B) In a desert (C) In the forest (D) On a highway

**73.** Why did the poet want to take the less travelled road? (A) To avoid a bumpy ride of another road (B) To get lost in the dense forest (C) In the hope of discovering something new (D) He likes puzzles

**74.** What does the poet's long stare at the path signify: (A) The time taken by people to decide and make a choice (B) Poet loves nature (C) Idling away of time (D) Relaxation hours

**75.** Mention the figure of speech used in "and having perhaps the better claim": (A) Alliteration (B) Personification (C) Simile (D) Metaphor

*Direction (Q. No. 76-77): Fill in the blanks using appropriate phrase preposition from the given option:*

**76.** _______ me, I will be happy to dedicate a few extra hours to the cause. (A) As for (B) As of (C) As from (D) As to

**77.** You will have to remember that, _______ John, no one wants to work on this problem. (A) apart to (B) apart from (C) apart (D) apart of

*Direction (Q. No.78): Transform the following superlative sentence into a positive sentence: "Alaska is one of the coldest places."*

**78.** (A) Few places are as cold as Alaska. (B) Few places are cold like Alaska. (C) Alaska is colder a place than any place. (D) No place is cold like Alaska.

*Direction (Q. No. 79 to 82): Read the passage given below and answer the questions that follow by selecting the most appropriate option:*
"Law is found in all modern societies and is usually regarded as the bedrock of civilized existence. But what distinguishes law from other social rules, and in what sense does law operate at an international or even global level? Is there such a thing as international law? In the case of domestic law, it is relatively easy to identify a series of distinguishing characteristics. First, law is made by the government and so applies throughout society. Not only does this mean that law reflects the will of the state and therefore takes precedence over all other norms and social rules, but it also gives domestic law universal jurisdiction within a particular political society. Second, law is compulsory; citizens are not allowed to choose which laws to obey and which to ignore, because law is backed up by a system of coercion and punishment. Law thus requires the existence of a legal system, a set of norms and institutions through which legal rules are created, interpreted and enforced. Third, law has a 'public' quality in that it consists of codified, published and recognised rules. This is, in part, achieved by enacting law through a formal and usually public, legislative process. Moreover, punishments handed down for law breaking are predictable and can be anticipated."

**79.** What is the basis of civilized existence? (A) State (B) Law (C) Money (D) Principles

**80.** How can law be distinguished from social rules? (A) Laws apply to every citizen whereas social rules vary from one society to another. (B) Laws are enforceable upon the society whereas social rules are not enforceable. (C) Laws are acceptable to the political society whereas social rules do not require any system. (D) Laws work according to the proper legal system whereas social rules do not require any system.

**81.** What is the outcome of breaking laws? (A) Award (B) Criticism (C) Praise (D) Punishment

**82.** Identify a word from the passage which means 'action of using force or threat to do something'. (A) Jurisdiction (B) Enforced (C) Coercion (D) Precedence

*Direction (Q. No. 83-84): Identify the segment in the given sentence which contains a grammatical error:*

**83.** I don't recognize none of (A) / the politicians who have been (B) / invited to be (C) / the speakers today (D). (A) I don't recognize none of (B) the politicians who have been (C) invited to be (D) the speakers today

**84.** If your jogging clothes (A) / were not made of permeable fabric (B) / you will drown (C) / in your sweat (D). (A) If your jogging clothes (B) were not made of permeable fabric (C) you will drown (D) in your sweat.

*Direction (Q. No. 85): Select the most appropriate pronoun and fill in the blank:*

**85.** After the interview, when I looked back, I was annoyed with ___ for not answering a question properly: (A) yourself (B) himself (C) myself (D) themselves

*Direction (Q. No. 86): Choose the word with the correct spelling.*

**86.** (A) Accesory (B) Accidentaly (C) Absense (D) Acquitted

*Direction (Q. No. 87-88): Select the correct alternative which can be substituted for the 'describing phrases' below:*

**87.** A person difficult to please: (A) Illiterate (B) Arbitrator (C) Fastidious (D) Egotist

**88.** A person who hates women: (A) Misogamist (B) Misogynist (C) Bigot (D) Impervious

*Direction (Q. No. 89): Choose the most suitable option that describes the meaning of the following idiom.*

**89.** Hit the sack (A) Hit the clothes pile (B) Go to sleep (C) Go to work (D) Go to gym

*Direction (Q. No. 90): In the following sentence choose the antonym to the underlined word:*

**90.** We should strive for the country's **development**. (A) Retrogression (B) Transgression (C) Impurity (D) Progress

---

# भाग 6: भाषा द्वितीय - संस्कृत (Second Language - Sanskrit) — प्रश्न 61-90

**61.** भाषायाः अधिग्रहण समये किं प्रथमम् आगच्छति? (A) वर्णमालायाः अक्षराणि (B) रूपम् (C) अर्थः (D) उभयं रूपम् अर्थश्च

**62.** छात्राणां त्रुटिसंशोधनाय शिक्षकः - (A) छात्रस्य दोषाणां संशोधनं कुर्यात् (B) दोषान् अधोरेखाङ्कितान् कुर्यात् (C) छात्रान् प्रोत्साहयितुं आशावादी प्रवृत्तिं धारयेत् (D) दोषस्य पुनरावृत्तिकारणात् छात्रं भर्त्सयेत्

**63.** पठनं नाम अस्ति- (A) भाषाधिगमः (B) सम्पूर्ण शब्दावल्याः अधिगमः (C) अक्षराणां शब्दानां च कूट ज्ञानम् (D) अर्थकरणम्

**64.** बालकस्य भाषा नियमानां रूपाणां च ज्ञानमस्ति, एतेन तस्य विकासः अस्ति- (A) बहुभाषिक सामर्थ्ये (B) द्विभाषिक सामर्थ्ये (C) सम्प्रेषण सामर्थ्ये (D) भाषिक सामर्थ्ये

**65.** भाषाधिगमनार्थं निवेशित पाठस्य कृते प्रामाणिक ग्रन्थस्य आवश्यकता किमर्थं भवति? (A) एतेन लेखकस्य परिचयो भवति। (B) एतेन अभिव्यक्तेः प्रामाणिकता प्रदर्श्यते। (C) एतेन स्वाभाविक भाषायाः प्रदर्शनं भवति। (D) एतेन नवीन कार्यस्य सर्जनं भवति।

**66.** निबन्ध लेखनार्थं शिक्षकः छात्रान् प्रेरयति, स मुख्यतया किं निर्दिशेत् - (A) वर्तनी विषये जागरूकाः भवन्तु। (B) स्वानुभवाधारेण लिखन्तु। (C) मार्गदर्शक पुस्तकम् उदाहरण रूपेण व्यवहरन्तु। (D) व्यवस्थिततया शुद्धतया च लिखन्तु।

*निर्देश (प्रश्न 67-71): अधोलिखितं गद्यांशं पठित्वा प्रश्नानां समुचितानि उत्तराणि चिनुत -*
"सूर्यः अचलः पृथिवी च चला, पृथिवीस्वकीयेऽक्षे घूर्णति इति सुस्थापितः सिद्धान्तो वर्तते। सिद्धान्तोऽयं महता गणितज्ञेन ज्योतिर्विदा आर्यभट्टेन प्रवर्तितः। तेनोदाहृतं यद् गतिशीलायां नौकायाम् उपविष्टो जनो नौकां स्थिरामनुभवति। अन्यान् च पदार्थान् गतिशीलानवगच्छति। एवमेव गतिशीलायां पृथिव्याम् अवस्थितो मानवः पृथिवीं स्थिरामनुभवति सूर्यादिग्रहान् च गतिशीलान् वेत्ति। आर्यभट्टेन 'पृथिवी स्थिरा वर्तते' इति प्रचलिता रूढिः परिवर्तिता। ऐतिहासिक स्रोतैर्ज्ञायते यत् पाटलिपुत्रं निकषा आर्यभट्टस्य वेधशाला आसीत्। अतः अनुमीयते यत्तस्य कर्मभूमिः पाटलिपुत्रमासीत्। आर्यभट्टस्य योगदानं गणित ज्योतिषा सम्बद्धं वर्तते। तेन गणित-पद्धत्या कृतमाकलनेन प्रतिपादितं यद् राहुकेतुनामकौ दानवौ सूर्य-चन्द्रग्रहणयोः कारणं न। तत्र सूर्य-चन्द्र, पृथिवी त्रीणि एव कारणानि सन्ति। यदा सूर्य-चन्द्रयोर्मध्ये पृथिवी आयाति, तदा पृथिव्याः छायापातेन चन्द्रग्रहणं भवति। तथैव पृथिवी-सूर्ययोर्मध्ये समागतस्य चन्द्रस्य छायापातेन सूर्यग्रहणं भवति।"

**67.** आर्यभट्टेन कः सिद्धान्तः प्रतिपादितः? (A) सूर्यः अचलः पृथिवी अपि अचला (B) पृथिवी चला सूर्यश्च अचलः (C) सूर्यः चलः पृथिवी च अचला (D) पृथिवी स्थिरा सूर्यः अचलः

**68.** आर्यभट्टेन प्रचलिता रूढ़िः परिवर्तिता - (A) गतिशीला नौका स्थिरावर्तते (B) पृथिवी स्थिरावर्तते (C) सूर्यादिग्रहाः गतिशीलाः वर्तन्ते (D) पृथिवी चला वर्तते

**69.** आर्यभट्टस्य वेधशाला आसीत् - (A) तिरूअनन्तपुरं निकषा (B) लक्ष्मणपुरं निकषा (C) चित्रकूटं निकषा (D) पाटलिपुत्रं निकषा

**70.** 'घूर्णति' इत्यस्य अर्थः अस्ति- (A) परिरक्षति (B) जिघ्रति (C) परिभ्रमति (D) प्रविशति

**71.** 'परितः' इत्यस्य योगे विभक्तिर्भवति- (A) प्रथमा (B) द्वितीया (C) तृतीया (D) पञ्चमी

*निर्देश (प्रश्न 72-76): अधोलिखितं गद्यांशं पठित्वा प्रश्नानां समुचितानि उत्तराणि चिनुत -*
"अस्ति कर्णपुरनाम्नि नगरे प्रच्छन्न भाग्य नामधेयः कश्चित् कुमारः। बाल्येवयसि विद्या पराङ्मुखः स केनचिद् दुष्टबुद्धि नाम्ना चौरेण सह चौर्य-कर्मणि निरतः सञ्जातः। एकदा सः दुष्ट-बुद्धिना साधार्ं कस्यचित् श्रेष्ठिनः गेहे धनहरणार्थं ग्रामान्तरं प्रस्थितः। तत्र व्रजन्तौ तौ गर्त सङ्कुलेमार्गे क्रीडतः कांश्चिद् बालकान् प्रेक्ष्य अवदताम् 'भो भो बालकाः! कथमत्र, नतोन्नते विषमे मार्गे क्रीडथ, यदि कश्चिद् गर्ते पतेत् तर्हि स विकलाङ्गो भूत्वा चिरं कलेशमनु भवेत्' तच्छ्रुत्वा तेषु कश्चिद् उद्दण्डो बालक उवाच- भो महानुभाव! यद्येवं तर्हि कथं भवन्तौ सुपथं परित्यज्य अनेन कुपथेन गन्तुं प्रवृत्तौ? अपि इदं श्रेयस्करम्? अनेन वचसा प्रच्छन्न भाग्यः अचिन्तयत् - किमिदं वचनं विशेषरूपेण मामेव लक्ष्यी करोति? अहो! कुमार्गगामिनी मम कीदृशी बुद्धिः, गुरूपदेशेन इव अनेन बाल वचसा ममचक्षुषी समुन्मीलिते। अद्य प्रभृति पापपथं त्यजामि इति विचिन्त्य मित्रं दुष्टबुद्धिम् अवदत् - 'सखे! यदि माम् मित्रस्थाने परिगणयसि तर्हि साधुजनगर्हितमिमं पन्थानं त्यजतु भवान्'।"

**72.** बाल्यकाले विद्यापराङ्मुखः कः आसीत्? (A) उद्दण्ड बालः (B) दुष्ट बुद्धिः (C) प्रच्छन्नभाग्यः (D) श्रेष्ठी

**73.** ग्रामान्तरं कथं प्रस्थितः? (A) अध्ययनार्थम् (B) धनहरणार्थम् (C) क्रीडनार्थम् (D) भ्रमणार्थम्

**74.** बालकाः कुत्र क्रीडन्ति स्म? (A) क्रीडाङ्गणे (B) प्राङ्गणे (C) विद्यालये (D) नतोन्नते मार्गे

**75.** कीदृशः बालकः उवाच? (A) प्रच्छन्नभाग्यः (B) मन्दभाग्यः (C) उद्दण्डः (D) दुष्ट बुद्धिः

**76.** उद्दण्ड बालकस्य वचनेन कः अचिन्तयत्? (A) उद्दण्ड (B) प्रच्छन्न भाग्यः (C) दुष्ट बुद्धिः (D) श्रेष्ठी

**77.** रघुवंशमहाकाव्ये कतिसर्गाः सन्ति? (A) पञ्चदश (B) अष्टादश (C) एकोनविंशति (D) विंशति

**78.** वैदिकं पदे कः प्रत्ययः? (A) तल् (B) शतृ (C) ठक् (D) वतुप्

**79.** राजन् इति पदस्य सप्तमी बहुवचने रूपम् अस्ति- (A) राज्ञसु (B) राजसु (C) राज्ञाम् (D) राजषु

**80.** करुण-रस-प्रधान नाटकम् अस्ति- (A) अभिज्ञान शाकुन्तलम् (B) मृच्छकटिकम् (C) स्वप्नवासवदत्तम् (D) उत्तररामचरितम्

**81.** 'योगः कर्मसु कौशलम्' उक्तिः अस्ति- (A) योगसूत्रे (B) वेदान्त सारे (C) गीतायाम् (D) ब्रह्मसूत्रे

**82.** 'वागर्थाविव' इत्यत्र सन्धिः अस्ति- (A) गुण (B) अयादि (C) दीर्घ (D) वृद्धि

**83.** 'उपर्युक्त' अत्र सन्धि विच्छेदः अस्ति- (A) उपरि + उक्त (B) उपर् + उक्त (C) उपर् + युक्त (D) ऊपर + उक्त

**84.** अन्तस्थः वर्णः अस्ति- (A) ख (B) झ (C) ल (D) श

**85.** 'हरौ' इति रूपमस्ति हरि शब्दस्य- (A) प्रथमा द्विवचनस्य (B) द्वितीया द्विवचनस्य (C) षष्ठी द्विवचनस्य (D) सप्तमी एकवचनस्य

**86.** 'अमोघः' अत्र कः समासः? (A) अव्ययीभावः (B) अलुक् (C) नञ् (D) उपपद समासः

**87.** 'अभूत्' रूपमस्ति- (A) लिट् लकारस्य (B) लङ् लकारस्य (C) लिङ् लकारस्य (D) लुङ् लकारस्य

**88.** आभ्यन्तर प्रयत्नाः कतिधा भवन्ति? (A) त्रीणि (B) पञ्च (C) षट् (D) अष्ट

**89.** अधस्तन युग्मानां समीचीनां तालिकां चिनुत- (a) हर्षः (1) मुद्राराक्षसः; (b) भवभूतिः (2) स्वप्नवासवदत्तम्; (c) विशाखदत्तः (3) उत्तररामचरितम्; (d) भासः (4) रत्नावली
कूटः : (a)(b)(c)(d) — (A) 3,2,4,1 (B) 4,3,1,2 (C) 2,1,3,4 (D) 1,4,2,3

**90.** कतिकारकाणि सन्ति? (A) पञ्च (B) षट् (C) सप्त (D) अष्ट्

---

# भाग 7: गणित (Mathematics) — प्रश्न 91-120

**91.** n के विषम पूर्णांक होने पर निम्नवत् संख्याओं में कौन एक सम पूर्णांक है? (A) 3n-8 (B) 5n²+4 (C) 3n²+5 (D) 4n²+5

*Which of the following numbers is an even integer when n is an odd integer? (A) 3n-8 (B) 5n²+4 (C) 3n²+5 (D) 4n²+5*

**92.** प्राथमिक स्तर पर 'गणित की पहेलियाँ' मदद करती हैं- (A) कक्षा के प्रतिभा सम्पन्न विद्यार्थियों को पहचानने में (B) समस्या सुलझाने के कौशलों को प्रोत्साहित करने में (C) छात्रों के ज्ञान को परखने में (D) विद्यार्थियों को मनोरंजन प्रदान करने में

*'Mathematics Puzzles' at primary level help in - (A) Identifying brilliant students of the class (B) Promoting problem solving skills (C) Testing the knowledge of students (D) Providing fun to students*

**93.** निम्नलिखित में से गणित में उपलब्धि कम होने का कारण क्या हो सकता है? (A) लिंग (B) सामाजिक-सांस्कृतिक पृष्ठभूमि (C) गणित की प्रकृति (D) इनमें से कोई नहीं

*Which of the following could be a contributing factor to underachievement in mathematics? (A) Gender (B) Socio-Cultural background (C) Nature of mathematics (D) None of these*

**94.** प्राथमिक अवस्था में गणित में रचनात्मक मूल्यांकन में अन्तर्निहित है- (A) अधिगम में असंगति को और शिक्षण में कमियों को पहचानना (B) सामान्य त्रुटियों को पहचानना (C) क्रिया-प्रणाली के ज्ञान और विश्लेषणात्मक प्रतिभाओं की परीक्षा (D) विद्यार्थियों के ग्रेड (श्रेणी) और रैंक (स्थिति)

*Formative assessment in mathematics at primary stage includes- (A) Identification of learning gaps and deficiencies in teaching (B) Identification of common errors (C) Testing of procedural knowledge and analytical abilities (D) Grading and ranking of students*

**95.** प्रथम 15 पूर्ण संख्याओं का औसत होगा - (A) 7.5 (B) 8 (C) 8.5 (D) 7

*The average of first 15 whole numbers will be - (A) 7.5 (B) 8 (C) 8.5 (D) 7*

**96.** किसी त्रिभुज के लिए निम्न में से कौन सा कथन सत्य है? (A) समस्त कोण सदैव न्यूनकोण होते है। (B) एक कोण सदैव समकोण होता है। (C) एक कोण सदैव अधिककोण होता है। (D) एक कोण सदैव न्यूनकोण होता है।

*Which of the following statements is true for a triangle? (A) All the angles are always acute angles. (B) One angle is always a right angle. (C) One angle is always an obtuse angle. (D) One angle is always an acute angle.*

**97.** यदि √2916 = 54 तो निम्न का मान क्या होगा- √29.16 + √0.2916 + √0.002916 + √0.00002916
(A) 3.9994 (B) 4.9994 (C) 5.9994 (D) 6.9994

*If √2916 = 54, then what will be the value of the following - √29.16 + √0.2916 + √0.002916 + √0.00002916*
(A) 3.9994 (B) 4.9994 (C) 5.9994 (D) 6.9994

**98.** एक आयत को क्षैतिज रूप से दो बराबर भागों में बाँटा जाता है। ऊपर वाले भाग को पुनः तीन बराबर भागों में बाँटा जाता है और निचले भाग को चार बराबर भागों में बाँटा जाता है। मूल आयत का कितना भाग छायांकित है? (आकृति अनुसार) (A) 2/7 (B) 4/7 (C) 7/12 (D) 3/5

*A rectangle is divided horizontally into two equal parts. The upper part is further divided into three equal parts and the lower part is divided into four equal parts. Which fraction of the original rectangle is the shaded part? (as per figure) (A) 2/7 (B) 4/7 (C) 7/12 (D) 3/5*

**99.** 4⁶¹ + 4⁶² + 4⁶³ + 4⁶⁴ किससे विभाज्य है - (A) 3 (B) 5 (C) 11 (D) 17

*4⁶¹ + 4⁶² + 4⁶³ + 4⁶⁴ is divisible by - (A) 3 (B) 5 (C) 11 (D) 17*

**100.** एक वर्ग की भुजा 4 सेमी है। इसे काटकर 4 बराबर वर्गों में विभाजित किया गया है। प्रत्येक छोटे वर्ग का क्षेत्रफल होगा: (A) 4 सेमी² (B) 1 सेमी² (C) 16 सेमी² (D) 8 सेमी²

*The side of a square is 4 cm. It is cut into 4 equal squares. The area of each small square will be- (A) 4 cm² (B) 1 cm² (C) 16 cm² (D) 8 cm²*

**101.** √(242 + √(52+144)) का मान है- (A) 16 (B) 17 (C) 18 (D) इनमें से कोई नहीं

*The value of √(242 + √(52+144)) is - (A) 16 (B) 17 (C) 18 (D) None of these*

**102.** 4½, 3, 10½ का ल.स. है - (A) 63 (B) 72 (C) 81 (D) 92

*L.C.M. of 4½, 3, 10½ is - (A) 63 (B) 72 (C) 81 (D) 92*

**103.** बालू एवं लोहे के 1 किलोग्राम मिश्रण में 20% लोहा है। लोहे की मात्रा को 10% करने के लिए मिश्रण में कितनी मात्रा में बालू मिलानी होगी? (A) 1 किग्रा. (B) 200 ग्राम (C) 800 ग्राम (D) 1.8 किग्रा.

*There is 20% iron in 1 kg mixture of sand and iron. How much sand must be added to the mixture to make the iron content 10%? (A) 1 kg. (B) 200 gm. (C) 800 gm. (D) 1.8 kg.*

**104.** 11 नतीजों का औसत 50 है। यदि पहले छः नतीजों का औसत 49 हो और अन्तिम छः नतीजों का औसत 52 हो तो छठा नतीजा होगा - (A) 56 (B) 54 (C) 52 (D) 48

*The average of 11 results is 50. If the average of the first six results is 49 and that of the last six results is 52, then the sixth result will be- (A) 56 (B) 54 (C) 52 (D) 48*

**105.** एक रेलगाड़ी देहरादून से 30 सितम्बर 2022 को 16:30 बजे प्रस्थान करती है और अपने गंतव्य पर 2 अक्टूबर 2022 को 08:45 बजे पहुँचती है। इस यात्रा का कुल समय है- (A) 36 घंटे 15 मिनट (B) 38 घंटे 45 मिनट (C) 39 घंटे 45 मिनट (D) 40 घंटे 15 मिनट

*A train leaves Dehradun on 30th September 2022 at 16:30 hours and reaches its destination on 2nd October 2022 at 08:45 hours. The total travel time of the journey is - (A) 36 hours 15 minutes (B) 38 hours 45 minutes (C) 39 hours 45 minutes (D) 40 hours 15 minutes*

**106.** 10 वस्तुओं का क्रय मूल्य 9 वस्तुओं के विक्रय मूल्य के बराबर है। प्रतिशत लाभ होगा - (A) 9 1/9 % (B) 10 1/9 % (C) 11 1/9 % (D) 12 1/9 %

*The cost price of 10 articles is equal to the selling price of 9 articles. The percentage profit will be - (A) 9 1/9 % (B) 10 1/9 % (C) 11 1/9 % (D) 12 1/9 %*

**107.** एक कोण का सम्पूरक कोण उसके कोटिपूरक कोण का 4 गुना है, तो वह कोण है - (A) 30° (B) 40° (C) 45° (D) 60°

*The supplementary angle of an angle is four times its complementary angle, then that angle is - (A) 30° (B) 40° (C) 45° (D) 60°*

**108.** एक रेलगाड़ी किसी खम्भे को 15 सेकेण्ड में पार कर लेती है तथा 100 मीटर लम्बे प्लेटफार्म को 25 सेकेण्ड में पार करती है। रेलगाड़ी की लम्बाई है- (A) 400 मीटर (B) 350 मीटर (C) 200 मीटर (D) 150 मीटर

*A train crosses a pole in 15 seconds and crosses a platform 100 meters long in 25 seconds. The length of the train is - (A) 400 meter (B) 350 meter (C) 200 meter (D) 150 meter*

**109.** 3759×9573 के गुणनफल में दहाई अंक और इकाई अंक का योगफल है - (A) 7 (B) 9 (C) 16 (D) 0

*In the product 3759×9573, the sum of ten's digit and unit's digit is - (A) 7 (B) 9 (C) 16 (D) 0*

**110.** यदि किसी आयत की लम्बाई में 20% की कमी कर दी जाए तो उसकी चौड़ाई में कितने प्रतिशत की वृद्धि करने से क्षेत्रफल यथावत रहेगा? (A) 25% (B) 50% (C) 75% (D) इनमें से कोई नहीं

*If the length of a rectangle is decreased by 20%, then by what percent increase in its width, the area will remain the same? (A) 25% (B) 50% (C) 75% (D) None of these*

**111.** गणित से भयभीत होने और उसमें असफल होने के लिए निम्नलिखित में से किसे एक कारण नहीं माना जा सकता है? (A) प्रतीकात्मक संकेत (B) गणित की संरचना (C) लैंगिक भेद (D) कक्षा-कक्ष के अनुभव

*Which of the following cannot be considered as a reason for fear and failure in mathematics? (A) Symbolic notations (B) Structure of mathematics (C) Gender differences (D) Classroom experiences*

**112.** गणित में ज्यामिति के शिक्षण हेतु सबसे उपयुक्त शिक्षण विधि कौन-सी है? (A) खेल विधि (B) विश्लेषण विधि (C) निगमन विधि (D) खोज विधि

*Which is the most suitable teaching method for teaching Geometry in mathematics? (A) Play-way method (B) Analysis method (C) Deductive method (D) Heuristic method*

**113.** 6-ई शिक्षण योजना में प्रयुक्त पदों का सही अनुक्रम है - (i) व्याख्या करना (ii) संलग्न करना (iii) विस्तारित करना (iv) मूल्यांकन करना
(A) (ii),(i),(iii),(iv) (B) (ii),(iii),(i),(iv) (C) (i),(ii),(iii),(iv) (D) (iii),(i),(ii),(iv)

*The correct sequence of terms used in 6-E teaching plan is - (i) Explain (ii) Engage (iii) Elaborate (iv) Evaluate*
(A) (ii),(i),(iii),(iv) (B) (ii),(iii),(i),(iv) (C) (i),(ii),(iii),(iv) (D) (iii),(i),(ii),(iv)

**114.** यदि दो संख्याओं का योग तथा गुणनफल क्रमशः 5 तथा 36 हो, तो उनके व्युत्क्रमों का योग होगा- (A) 5/9 (B) 31/36 (C) 5/36 (D) 31/9

*If the sum and product of two numbers are 5 and 36 respectively, then the sum of their reciprocals will be - (A) 5/9 (B) 31/36 (C) 5/36 (D) 31/9*

**115.** दिये गये चित्र में OP||RS, ∠OPQ = 100° तथा ∠QRS = 140° तो ∠PQR का मान है- (A) 80° (B) 60° (C) 70° (D) 90°

*In the given fig. OP||RS, ∠OPQ= 100° and ∠QRS= 140° then ∠PQR is equal to - (A) 80° (B) 60° (C) 70° (D) 90°*

**116.** 37.188 ÷ 3.6 का मान है - (A) 10.03 (B) 10.3 (C) 10.33 (D) इनमें से कोई नहीं

*The value of 37.188 ÷ 3.6 is - (A) 10.03 (B) 10.3 (C) 10.33 (D) None of these*

**117.** मैं कौन-सी संख्या हूँ? मैं दो अंकों की सम संख्या हूँ। मैं 3,4,6 का सार्वगुणज हूँ। मेरे कुल 9 गुणनखण्ड हैं। (A) 36 (B) 48 (C) 56 (D) 24

*What number am I? I am a 2-digit even number. I am a common multiple of 3,4,6. I have a total of 9 factors. (A) 36 (B) 48 (C) 56 (D) 24*

**118.** एक घन का पृष्ठीय क्षेत्रफल 1014 वर्ग सेमी हो तो इसका आयतन होगा- (A) 2197 घन सेमी (B) 2297 घन सेमी (C) 2179 घन सेमी (D) 2117 घन सेमी

*Surface area of a cube is 1014 Sq.cm, then its volume will be- (A) 2197 cu.cm. (B) 2297 cu.cm. (C) 2179 cu.cm. (D) 2117 cu.cm.*

**119.** 2, 3, 5, 9, 17, 33, ......... अनुक्रम की अगली संख्या होगी- (A) 65 (B) 60 (C) 50 (D) 49

*The next number in the sequence 2, 3, 5, 9, 17, 33, ......... will be - (A) 65 (B) 60 (C) 50 (D) 49*

**120.** (0.125)^(2/3) का मान है - (A) 2.5 (B) 0.25 (C) 0.025 (D) 0.0025

*The value of (0.125)^(2/3) is - (A) 2.5 (B) 0.25 (C) 0.025 (D) 0.0025*

---

# भाग 8: पर्यावरण अध्ययन (Environmental Studies) — प्रश्न 121-150

**121.** आपदा प्रबन्धन निम्न में से किस सूची के अन्तर्गत आता है? (A) केन्द्रीय सूची (B) राज्य सूची (C) समवर्ती सूची (D) इनमें से कोई नहीं

*Disaster management comes under which of the following list? (A) Central list (B) State List (C) Concurrent list (D) None of these*

**122.** प्राथमिक कक्षा के छात्रों से इस प्रश्न का उत्तर प्राप्त करना, 'आपको क्यों लगता है कि रेगिस्तानी इलाकों में कई पेड़ नहीं उग सकते हैं'? निश्चित रूप से किस अधिगम संकेतक की उपलब्धि को दर्शाता है? (A) पूछताछ (B) स्पष्टीकरण (C) वर्गीकरण (D) प्रयोग

*Getting the answer from primary class students for the question, 'Why do you think many trees cannot grow in desert areas'? surely represents the achievement of which learning indicator? (A) Questioning (B) Explanation (C) Classification (D) Experimentation*

**123.** राजेश कक्षा 5 के शिक्षक हैं। वे 'वृक्ष-संरक्षण' की अवधारणा पर शिक्षार्थियों को संवेदनशील बनाने के लिए योजना बनाते हैं। निम्नलिखित में से कौन-सी एक गतिविधि इस उद्देश्य के लिए सर्वाधिक उपयुक्त है? (A) प्रत्येक शिक्षार्थी को एक पौधे को अपनाने और उसका पोषण करने के लिए अभिप्रेरित करना (B) वाद-विवाद प्रतियोगिता का आयोजन करना (C) पोस्टर प्रतियोगिता में भाग लेने के लिए शिक्षार्थियों को प्रोत्साहित करना (D) समूह चर्चा के लिए शिक्षार्थियों का समूह बनाना

*Rajesh is a teacher of class 5. He plans to sensitize the learners on the concept of 'tree conservation'. Which one of the following activities is most suitable for this purpose? (A) Motivate each learner to adopt and nurture a plant (B) Organizing debate competition (C) To encourage learners to participate in poster competition (D) Grouping of learners for group discussion*

**124.** भारत में राष्ट्रीय आपदा प्रबन्धन संस्थान स्थित है- (A) पुणे में (B) मिदनापुर में (C) नई दिल्ली में (D) कोलकाता में

*National Institute of Disaster Management in India is located at- (A) Pune (B) Midnapur (C) New Delhi (D) Kolkata*

**125.** 'इकोमार्क' सम्बन्धित है - (A) निर्यात वस्तुओं से (B) आयात वस्तुओं से (C) सर्वोत्तम गुणवत्ता वाली वस्तुओं से (D) पर्यावरण के लिए सुरक्षित वस्तुओं से

*'Ecomark' is related to - (A) Export Commodities (B) Import Commodities (C) Commodities of best quality (D) Environmental Friendly commodities*

**126.** 'कार्बन क्रेडिट' की संकल्पना निम्नलिखित में से किससे उद्भूत हुई? (A) पृथ्वी सम्मेलन (रियो-डे-जेनेरो) (B) क्योटो प्रोटोकाल (C) मान्ट्रियाल प्रोटोकाल (D) जी-8 शिखरवार्ता

*The concept of 'Carbon credit' originated in which of the following? (A) Earth Summit (Rio-de-Janeiro) (B) Kyoto protocol (C) Montreal protocol (D) G-8 Summit*

**127.** निम्नलिखित में से कौन सा कृत्रिम पारिस्थितिकी तंत्र है- (A) धान का खेत (B) वन (C) घास का मैदान (D) झील

*Which of the following is an artificial Ecosystem - (A) Paddy Field (B) Forest (C) Grassland (D) Lake*

**128.** विश्व जल दिवस मनाया जाता है - (A) 22ⁿᵈ अक्टूबर को (B) 22ⁿᵈ जनवरी को (C) 22ⁿᵈ मार्च को (D) 22ⁿᵈ मई को

*World Water Day is celebrated on - (A) 22ⁿᵈ October (B) 22ⁿᵈ January (C) 22ⁿᵈ March (D) 22ⁿᵈ May*

**129.** आर्कटिक मरूस्थल का दूसरा नाम है- (A) टुण्ड्रा (B) सवाना (C) टैगा (D) स्टेपीज

*Arctic Desert is also known as - (A) Tundra (B) Savanna (C) Taiga (D) Steppes*

**130.** भारत में 1936 में स्थापित प्रथम राष्ट्रीय उद्यान का नाम रखा गया था - (A) कान्हा राष्ट्रीय उद्यान (B) भरतपुर राष्ट्रीय उद्यान (C) हेली राष्ट्रीय उद्यान (D) राजाजी राष्ट्रीय उद्यान

*The first National park in India, established in 1936 was named - (A) Kanha National Park (B) Bharatpur National Park (C) Hailley National Park (D) Rajaji National Park*

**131.** एक शिक्षक अपने विद्यार्थियों को विभिन्न पशुओं के चित्र देता है और उन सभी पशुओं पर रंग भरने को कहता है, जो हमारे घरों में नहीं रहते। इस क्रियाकलाप का उद्देश्य है - (i) सृजनात्मकता का विकास करना (ii) अवलोकन का विकास करना (iii) वर्गीकरण कौशल का विकास करना (iv) डाटा संग्रह का विकास करना। उपर्युक्त में से कौन से सही हैं?
(A) (i),(ii) और (iv) (B) (ii),(iii) और (iv) (C) (i),(iii) और (iv) (D) (i),(ii) और (iii)

*A teacher gives his students pictures of different animals and asks them to colour all those animals which do not live in our houses. The motive of this activity is - (i) Development of creative skill (ii) Development of observational skill (iii) Development of classification skill (iv) Development of Data Collection. Which of the aforementioned are correct?*
(A) (i),(ii) and (iv) (B) (ii),(iii) and (iv) (C) (i),(iii) and (iv) (D) (i),(ii) and (iii)

**132.** बच्चों को पर्यावरण अध्ययन को सीखने के लिए खोजने का पर्याप्त अवसर दिया जाता है। यह इंगित करता है कि - (A) पर्यावरण अध्ययन बाल-केन्द्रित है। (B) पर्यावरण अध्ययन शिक्षक केन्द्रित है। (C) पर्यावरण अध्ययन याद करके सीखा जाता है। (D) पर्यावरण अध्ययन सूचनाओं द्वारा सीखा जाता है।

*Children get a lot of space to learn EVS through exploration. This indicates that- (A) EVS is child centric. (B) EVS is teacher centric. (C) EVS is learned through craming. (D) EVS is learned through Informations.*

**133.** निम्नलिखित पद्धतियों में कौन-सी कृषि में जल संरक्षण में सहायता कर सकती है/हैं? 1. कृषि भूमि की कम या शून्य जुताई 2. खेत में सिंचाई के पूर्व जिप्सम का प्रयोग 3. फसल अवशेष को खेत में ही रहने देना
(A) केवल 1 और 2 (B) केवल 1 और 3 (C) केवल 3 (D) 1, 2 और 3

*Which of the following procedure/s is/are helpful in water conservation in Agriculture? 1. Low or zero tillage of agriculture land 2. Use of Gypsum before irrigation 3. Leaving the crop residues in the field*
(A) Only 1 and 2 (B) Only 1 and 3 (C) Only 3 (D) 1, 2 and 3

**134.** भारत के किस राज्य में 'पानी पंचायत' प्रारम्भ हुई? (A) केरल (B) राजस्थान (C) महाराष्ट्र (D) गुजरात

*In which state of India did 'Water Panchayat' start? (A) Kerala (B) Rajasthan (C) Maharashtra (D) Gujarat*

**135.** निम्न में से कौन-सा जीवाणु जल प्रदूषण के सूचक के रूप में काम आता है? (A) स्टेफाइलोकोकस (B) स्ट्रेप्टोकोकस (C) डिप्लोकोकस (D) कॉलीफॉर्म

*Which of the following bacteria is an indicator of water pollution? (A) Staphylococcous (B) Streptococcous (C) Diplococcous (D) Coliform*

**136.** निम्न में कौन सा पोषक चक्र सूर्य के प्रकाश से सीधे संचालित होता है? (A) कार्बन चक्र (B) नाइट्रोजन चक्र (C) सल्फर चक्र (D) फॉस्फोरस चक्र

*Which of the following nutrient cycle is directly propelled by sunlight? (A) Carbon cycle (B) Nitrogen cycle (C) Sulphur cycle (D) Phosphorus cycle*

**137.** जैव-ईंधन के संबंध में निम्न में से कौन सा कथन सत्य नहीं है? (A) जैव-ईंधन पारिस्थितिकी अनुकूल है। (B) जैव-ईंधन लागत प्रभावी होता है। (C) जैव-ईंधन ऊर्जा संकट के समाधान में योगदान दे सकता है। (D) जैव-ईंधन मक्का से भी बनता है।

*Which of the following statements regarding Biofuels is incorrect? (A) Biofuels are Eco Friendly. (B) Biofuels are cost-effective. (C) Biofuels can be instrumental in overcoming the energy crisis. (D) Biofuel can also be prepared from Maize.*

**138.** भारत में निम्नलिखित में से कौन नवीकरणीय ऊर्जा स्रोत सर्वाधिक संभाव्यता वाला है? (A) सौर शक्ति (B) लघु जल विद्युत शक्ति (C) जैव पुंज शक्ति (D) अपशिष्ट से अर्जित शक्ति

*Which among the following is the most prospective Renewable source of Energy in India? (A) Solar Energy (B) Small Hydro-electric energy (C) Biological energy (D) Energy derived from wastes*

**139.** निम्नलिखित में से किसे जैविक खाद के रूप में प्रयोग किया जाता है? (A) नीम (B) एजोला (C) यूरिया (D) पोटैशियम

*Which of the following is used as a biofertilizer? (A) Neem (B) Azolla (C) Urea (D) Potassium*

**140.** निम्नलिखित में से किसकी मात्रा अम्ल वर्षा में सबसे अधिक होती है? (A) HCl (B) HNO₃ (C) H₂SO₄ (D) H₂CO₃

*Which of the following is a major constituent of Acid rain? (A) HCl (B) HNO₃ (C) H₂SO₄ (D) H₂CO₃*

**141.** पर्यावरण अध्ययन में बच्चों को जोड़ने की सबसे प्रभावशाली युक्ति है- (A) पाठ्यपुस्तक का पठन (B) शिक्षक द्वारा व्याख्याएँ (C) कक्षा निदर्शन (D) किस्से कहानियाँ

*The most effective strategy to engage children in EVS is - (A) Reading of Text Books (B) Explanation by teachers (C) Classroom demonstration (D) Narratives*

**142.** एक शिक्षक प्रत्येक बच्चे को रद्दी सामग्री से कुछ उपयोगी वस्तु बनाने को कहता है। निम्न में से कौन से कथन में शिक्षक का शैक्षिक उद्देश्य नहीं है? (A) कक्षा के श्रेष्ठ विद्यार्थियों के बारे में निर्णय करना। (B) बच्चों में सृजनशीलता का विकास करना। (C) बच्चों को पुनश्चक्रण, पुनः प्रयोग और रूपान्तरण की संकल्पना समझाना। (D) कूड़े से बनी श्रेष्ठ वस्तुओं की प्रदर्शनी आयोजित करना।

*A teacher tells every student to make useful things from waste material. Which of the following statements is not the educational motive of the teacher? (A) Choosing the best students in the class. (B) Developing creativity among students. (C) To give students the concept of recycling, reuse and conversion. (D) Arranging an exhibition of things made from waste material.*

**143.** दूसरी कक्षा की शिक्षिका तनुजा को फूल से संबंधित विषय के बारे में पढ़ाना है। उसे क्या करना चाहिए? (A) बच्चों को स्कूल के बगीचे में ले जाये जहाँ बहुत सारे फूल हैं। (B) प्रोजेक्टर पर इनके चित्र दिखायें। (C) ब्लैकबोर्ड पर कई प्रकार के फूल बनायें। (D) ब्लैकबोर्ड पर फूलों के नाम लिखें और छात्रों को अपनी नोटबुक पर उन्हें लिखने को कहें।

*Tanuja, a teacher of 2nd class, has to teach a topic related to flower. What should she do? (A) Take children in the garden of the school where there are numerous flowers. (B) To show its picture on Projector. (C) To draw various types of flowers on Blackboard. (D) To write the name of flowers on the blackboard and ask the students to write it in their copy.*

**144.** एकीकृत पर्यावरण विज्ञान के रूप में ई.वी.एस. अध्ययन का क्या महत्व है? (A) प्राकृतिक और सामाजिक-सांस्कृतिक वातावरण से संबंध स्थापित करने में जागरूक और सक्षम होना। (B) सभी गतिविधियों में भाग लेने में सक्षम होना। (C) लिखित एवं प्रायोगिक में A+ प्राप्त करना। (D) विज्ञान की शिक्षा का भाषा की तुलना में अधिक आनंद लेना।

*What is the significance of EVS study, as an integrated environmental science? (A) To be aware of and able to correlate to natural and socio-cultural environment. (B) Being able to participate in all activities. (C) Scoring A+ in theory as well as in practicals. (D) To enjoy learning of science more than that of language.*

**145.** देश में पर्यावरण कानूनों की समीक्षा के लिए निम्नलिखित में से किस समिति का गठन किया गया था? (A) कस्तूरी रंगन समिति (B) सुब्रमनियन समिति (C) माधव नायर समिति (D) उल्लास कारंथ समिति

*Which one of the following committees was constituted to review Environmental Laws in the country? (A) Kasturi Rangan Committee (B) Subramanian Committee (C) Madhav Nair Committee (D) Ullas Karanth Committee*

**146.** भारत के संविधान में वन्य जीवन का संरक्षण निम्नलिखित में से किसके अन्तर्गत आता है? 1. मौलिक कर्तव्य 2. निर्देशक सिद्धान्त 3. सातवीं अनुसूची — नीचे दिए गए कूट में से सही विकल्प का चयन कीजिए-
(A) 1 और 2 (B) 2 और 3 (C) 1 और 3 (D) 1, 2 और 3

*Protection of wildlife comes under which of the following in the Constitution of India? 1. Fundamental duties 2. Directive principles 3. Seventh schedule — Select the correct option from the codes given below-*
(A) 1 and 2 (B) 2 and 3 (C) 1 and 3 (D) 1, 2 and 3

**147.** निम्नताप परिरक्षण (क्रायो-प्रिजरवेशन) तकनीक द्वारा संकटग्रस्त जातियों के बीजों एवं परागकणों को लम्बे समय तक परिरक्षित किया जाता है- (A) बर्फ में (B) कार्बन टेट्राक्लोराइड में (C) तरल नाइट्रोजन में (D) अमोनिया में

*Seed and pollen grains of endangered species are preserved for a long time by cryo-preservation technology in- (A) Ice (B) Carbon tetra chloride (C) liquid nitrogen (D) ammonia*

**148.** वे प्रजातियां जो एक विशेष क्षेत्र तक सीमित होती हैं, कहलाती हैं- (A) महामारी प्रजाति (B) दुर्लभ प्रजाति (C) भेद्य प्रजाति (D) स्थानिक प्रजाति

*The species which are confined to a particular area are called- (A) Pandemic species (B) Extinct species (C) Vulnerable species (D) Endemic species*

**149.** वायुमंडल की किस परत में वर्षण, आँधी, बादल-गर्जन, बिजली चमक आदि होती हैं? (A) आयनमंडल (B) समतापमंडल (C) क्षोभमंडल (D) ओजोनमंडल

*In which layer of the atmosphere do rainfall, storm, thundering and lightening occur? (A) Ionosphere (B) Stratosphere (C) Troposphere (D) Ozonosphere*

**150.** जैविक कचरे से भरपूर घरेलू सीवेज के प्रवाह वाली नदी का परिणाम हो सकता है- (A) जलीय खाद्य जल जीवों की बढ़ी हुई जनसंख्या (B) जैव निम्नीकरणीय पोषक तत्वों के कारण मछली का बढ़ा हुआ उत्पादन (C) आक्सीजन की कमी से मछलियों की मौत (D) शैवाल खिलने के कारण नदी का बहुत जल्दी सूख जाना

*A river with an inflow of domestic sewage rich in organic waste may result in- (A) increased population of aquatic food web organisms (B) an increased production of fish due to biodegradable nutrients (C) death of fishes due to lack of oxygen (D) drying of the river very soon due to algal bloom*

---
**दस्तावेज़ समाप्त / End of Document**
