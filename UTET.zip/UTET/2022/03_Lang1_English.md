# UTET 2022 — Paper I (First Language - English)
**Set – B | Booklet Series: XXII-1 | परीक्षा दिनांक/Exam Date: 30 September 2022 | पूर्णांक/Max Marks: 150 | समय/Time: 2 घंटे 30 मिनट**

**अनुभाग / Section:** First Language - English — प्रश्न 31-60

> **✅ उत्तर कुंजी स्रोत (Answer Key Source) — आधिकारिक / OFFICIAL:** यह उत्तर-कुंजी उत्तराखण्ड विद्यालयी शिक्षा परिषद् (UBSE), रामनगर (नैनीताल) द्वारा जारी **आधिकारिक UTET-I 2022 Answer Key (SET-B)** से ली गई है — स्रोत: [static.collegedekho.com/.../answer_key_utet_i.pdf](https://static.collegedekho.com/media/uploads/2022/10/07/answer_key_utet_i.pdf) (PDF के पेज 2 पर SET-B की तालिका है)। चूँकि यह सीधे Set-B हेतु आधिकारिक दस्तावेज़ है, अतः प्रश्न-क्रमांक सीधे हमारे Set-B दस्तावेज़ के प्रश्न-क्रमांकों से मेल खाते हैं — किसी प्रकार के content-matching या अनुमान की आवश्यकता नहीं रही। (पहले इस्तेमाल किया गया theexampillar.com-आधारित/स्वयं-हल किया हुआ उत्तर-कुंजी अब इस आधिकारिक स्रोत से पूर्णतः प्रतिस्थापित कर दिया गया है।)
>
> *(This answer key is taken directly from the **OFFICIAL UTET-I 2022 Answer Key (SET-B)** issued by the Uttarakhand Board of School Education (UBSE), Ramnagar, Nainital — sourced from a PDF hosted on static.collegedekho.com (page 2 = Set-B table). Since this is the official document specifically for Set-B, question numbers match our document's numbering directly — no content-matching or guesswork was required. This fully replaces the earlier theexampillar.com-based / self-solved answers used in an earlier draft.)*

---

# भाग 3: First Language - English — प्रश्न 31-60

**31.** Home language is _______ in a natural way. (A) taught (B) promoted (C) acquired (D) learnt

**✅ सही उत्तर / Correct Answer: (C)**

---
**32.** At primary level, the objective of teaching a language is- (A) Basic Interactive Communicative Skills (BICS) (B) Cognitive Advanced Language Proficiency (CALP) (C) Memorisation of text book (D) Ability to write question answer

**✅ सही उत्तर / Correct Answer: (A)**

---
**33.** The most important aspect of an effective language classroom is to provide learners with an opportunity to- (A) interact (B) interfere (C) assess (D) imitate

**✅ सही उत्तर / Correct Answer: (A)**

---
**34.** What is the 'task' in task-based language learning? (A) A piece of work which enables learners to do an activity. (B) A piece of work for the parents to do their children's homework. (C) A piece of activity for teachers to do in the classroom. (D) A piece of work which exposes learners to language.

*Direction (Q. No. 35 to 38): Read the passage given below and answer the questions that follow by selecting the most appropriate option.*
"Read not to contradict and confuse, nor to believe and take for granted, nor to find talk and discourse but to weigh and consider. Some books are to be tasted, others to be swallowed, and some few to be chewed and digested. That is some books are to be read only in parts; others to be read, but not curiously; and some few to be read wholly, and with diligence and attention. Some books may also be read by deputy, and extracts made of them by others but that would be only in the less important arguments and the meaner sort of books; else distilled books are like common distilled waters, flashy things. Reading maketh a full man, conference a ready man, and writing an exact man."

**✅ सही उत्तर / Correct Answer: (D)**

---
**35.** What should be the purpose of reading a book? (A) To understand the contents (B) To weigh and consider (C) To contradict (D) To take it for granted

**✅ सही उत्तर / Correct Answer: (B)**

---
**36.** Why are some books to be tasted? (A) To be read with great care (B) To be read with great attention (C) To be read only in parts (D) To be read for fun

**✅ सही उत्तर / Correct Answer: (C)**

---
**37.** How is man's character influenced by the art of writing? (A) It makes him an exact man (B) It makes him a great writer (C) It makes him a ready man (D) It makes him a full man

**✅ सही उत्तर / Correct Answer: (A)**

---
**38.** What is meant by 'Chewed and digested'? (A) Understood without any effort (B) Partly read and understood (C) Thoroughly read and understood (D) None of the above

*Direction (Q. No. 39): Out of the given alternatives, choose the one that is most similar in meaning to the underlined word in the sentence-*

**✅ सही उत्तर / Correct Answer: (C)**

---
**39.** He had to **curtail** his leave as a lot of work was pending in his office. (A) Cancel (B) Extend (C) Shorten (D) Postpone

*Direction (Q. No. 40): Out of the given alternatives, choose the one which is closest to the opposite in meaning of the underlined word.*

**✅ सही उत्तर / Correct Answer: (C)**

---
**40.** My uncle is very wealthy, but rather **parsimonious** in his habits. (A) Extravagant (B) Thrifty (C) Careless (D) Strict

*Direction (Q. No. 41): Improve the underlined part of the sentence by choosing the correct option. If there is no need of improvement, the answer will be option (d).*

**✅ सही उत्तर / Correct Answer: (A)**

---
**41.** Either Radha or Sita forgot to take **their** umbrella. (A) Her (B) His (C) One's (D) No improvement

*Direction (Q. No. 42): An idiomatic expression/a proverb has been given below, followed by four alternatives. Choose the one which best expresses the meaning of the given idiom/proverb.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**42.** A bolt from the blue. (A) A delayed event (B) An inexplicable event (C) An unexpected event (D) An unpleasant event

**✅ सही उत्तर / Correct Answer: (C)**

---
**43.** Choose the correct adjective of the noun 'Advice' - (A) Advisable (B) Advise (C) Advisedly (D) Adviser

*Direction (Q. No. 44-46): Fill in the blanks by choosing the correct option.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**44.** Being a philanthropist, he _______ this institution. (A) Founded (B) Was founded (C) Find (D) Found

**✅ सही उत्तर / Correct Answer: (A)**

---
**45.** The judge acquitted him _______ the murder. (A) off (B) of (C) for (D) from

**✅ सही उत्तर / Correct Answer: (B)**

---
**46.** The eggs are sold by _______ dozen. (A) a (B) an (C) the (D) None of these

**✅ सही उत्तर / Correct Answer: (C)**

---
**47.** Point out the active voice of the following sentence - "It is being done by us." (A) We are doing it. (B) It will be done by us. (C) We can do it. (D) We must do it.

**✅ सही उत्तर / Correct Answer: (A)**

---
**48.** Identify the correct form of the given sentence - Dad said to Pankaj, "I will not give you pocket money." (A) Dad ordered Pankaj not to give him pocket money. (B) Dad told Pankaj that he would not give him pocket money. (C) Dad told Pankaj that I will not give you pocket money. (D) Dad said to Pankaj that he would not give her pocket money.

**✅ सही उत्तर / Correct Answer: (B)**

---
**49.** Choose the correct figure of speech in the following sentence - 'The wind lies asleep in the arms of dawn.' (A) Metaphor (B) Hyperbole (C) Personification (D) Oxymoron

**✅ सही उत्तर / Correct Answer: (C)**

---
**50.** Choose the correctly spelt word - (A) Tarif (B) Tarrif (C) Tarriff (D) Tariff

*Direction (Q. No. 51-54): Read the poem given below and answer the questions that follow by selecting the most appropriate option -*
"I Build Walls / I build Walls / Walls that protect, / Walls that shield, / Walls that say I shall not yield / Or reveal / Who I am or how I feel / I build walls / Walls that hide, / Walls that cover what's inside, / Walls that stare or smile or look away, / Silent lies, / Walls that even block my eyes / From the tears I might have cried. / I build walls / Walls that never let me / Truly touch / Those I love so very much. / Walls that need to fall! / Walls meant to be fortresses / Are prisons after all."

**✅ सही उत्तर / Correct Answer: (D)**

---
**51.** What are the walls in this poem made of? (A) Blood and flesh (B) Hidden feelings and thoughts (C) Bricks or any physical material (D) Cement and tiles

**✅ सही उत्तर / Correct Answer: (B)**

---
**52.** The expression 'silent lies' in the poem implies that - (A) Walls make one hide one's true feelings. (B) Walls lie silently around all of us. (C) Walls are silent. (D) Walls are liars.

**✅ सही उत्तर / Correct Answer: (A)**

---
**53.** Why is it not a good idea to have these 'Walls'? (A) They are made of bricks (B) They hurt others (C) They act as a fortress (D) They act as a prison and keep loved ones away

**✅ सही उत्तर / Correct Answer: (D)**

---
**54.** Walls built to protect us ultimately turn into a prison. It is an example of a - (A) puzzle (B) riddle (C) satire (D) paradox

*Direction (Q. No. 55-57): Point out the error in the following sentences. If there is no mistake, the answer is 'No error'.*

**✅ सही उत्तर / Correct Answer: (D)**

---
**55.** I and Tina will go to the market in the evening. (A) I and Tina (B) will go to the market (C) in the evening (D) No error

**✅ सही उत्तर / Correct Answer: (A)**

---
**56.** I would never apologise if I were you. (A) I would (B) never apologise if (C) I were you (D) No error

**✅ सही उत्तर / Correct Answer: (D)**

---
**57.** So quickly did she ran upstairs that she overtook me. (A) So quickly (B) did she ran upstairs (C) that she overtook me (D) No error

**✅ सही उत्तर / Correct Answer: (B)**

---
**58.** In the following sentence, omit 'too' without changing its meaning and select the most appropriate option for it- "She is too poor to buy costly books." (A) She is so poor to buy costly books. (B) She is very poor to buy costly books. (C) She is so poor that she can't buy costly books. (D) She is so poor that she could not buy costly books.

**✅ सही उत्तर / Correct Answer: (C)**

---
**59.** The study of words and their meanings is known as- (A) Phonetics (B) Syntax (C) Linguistics (D) Semantics

**✅ सही उत्तर / Correct Answer: (D)**

---
**60.** Which one of the following is not a language component- (A) Grammar (B) Speech (C) Manuscript (D) Sound system

---

**✅ सही उत्तर / Correct Answer: (C)**

---


## 📋 उत्तर कुंजी सारांश (Official Answer Key Summary)

| प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर |
|---|---|---|---|---|---|
| 31 | C | 32 | A | 33 | A |
| 34 | D | 35 | B | 36 | C |
| 37 | A | 38 | C | 39 | C |
| 40 | A | 41 | A | 42 | C |
| 43 | A | 44 | A | 45 | B |
| 46 | C | 47 | A | 48 | B |
| 49 | C | 50 | D | 51 | B |
| 52 | A | 53 | D | 54 | D |
| 55 | A | 56 | D | 57 | B |
| 58 | C | 59 | D | 60 | C |
