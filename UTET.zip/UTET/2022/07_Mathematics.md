# UTET 2022 — Paper I (गणित (Mathematics))
**Set – B | Booklet Series: XXII-1 | परीक्षा दिनांक/Exam Date: 30 September 2022 | पूर्णांक/Max Marks: 150 | समय/Time: 2 घंटे 30 मिनट**

**अनुभाग / Section:** गणित (Mathematics) — प्रश्न 91-120

> **✅ उत्तर कुंजी स्रोत (Answer Key Source) — आधिकारिक / OFFICIAL:** यह उत्तर-कुंजी उत्तराखण्ड विद्यालयी शिक्षा परिषद् (UBSE), रामनगर (नैनीताल) द्वारा जारी **आधिकारिक UTET-I 2022 Answer Key (SET-B)** से ली गई है — स्रोत: [static.collegedekho.com/.../answer_key_utet_i.pdf](https://static.collegedekho.com/media/uploads/2022/10/07/answer_key_utet_i.pdf) (PDF के पेज 2 पर SET-B की तालिका है)। चूँकि यह सीधे Set-B हेतु आधिकारिक दस्तावेज़ है, अतः प्रश्न-क्रमांक सीधे हमारे Set-B दस्तावेज़ के प्रश्न-क्रमांकों से मेल खाते हैं — किसी प्रकार के content-matching या अनुमान की आवश्यकता नहीं रही। (पहले इस्तेमाल किया गया theexampillar.com-आधारित/स्वयं-हल किया हुआ उत्तर-कुंजी अब इस आधिकारिक स्रोत से पूर्णतः प्रतिस्थापित कर दिया गया है।)
>
> *(This answer key is taken directly from the **OFFICIAL UTET-I 2022 Answer Key (SET-B)** issued by the Uttarakhand Board of School Education (UBSE), Ramnagar, Nainital — sourced from a PDF hosted on static.collegedekho.com (page 2 = Set-B table). Since this is the official document specifically for Set-B, question numbers match our document's numbering directly — no content-matching or guesswork was required. This fully replaces the earlier theexampillar.com-based / self-solved answers used in an earlier draft.)*

---

# भाग 7: गणित (Mathematics) — प्रश्न 91-120

**91.** n के विषम पूर्णांक होने पर निम्नवत् संख्याओं में कौन एक सम पूर्णांक है? (A) 3n-8 (B) 5n²+4 (C) 3n²+5 (D) 4n²+5

*Which of the following numbers is an even integer when n is an odd integer? (A) 3n-8 (B) 5n²+4 (C) 3n²+5 (D) 4n²+5*

**✅ सही उत्तर / Correct Answer: (C)**

---
**92.** प्राथमिक स्तर पर 'गणित की पहेलियाँ' मदद करती हैं- (A) कक्षा के प्रतिभा सम्पन्न विद्यार्थियों को पहचानने में (B) समस्या सुलझाने के कौशलों को प्रोत्साहित करने में (C) छात्रों के ज्ञान को परखने में (D) विद्यार्थियों को मनोरंजन प्रदान करने में

*'Mathematics Puzzles' at primary level help in - (A) Identifying brilliant students of the class (B) Promoting problem solving skills (C) Testing the knowledge of students (D) Providing fun to students*

**✅ सही उत्तर / Correct Answer: (B)**

---
**93.** निम्नलिखित में से गणित में उपलब्धि कम होने का कारण क्या हो सकता है? (A) लिंग (B) सामाजिक-सांस्कृतिक पृष्ठभूमि (C) गणित की प्रकृति (D) इनमें से कोई नहीं

*Which of the following could be a contributing factor to underachievement in mathematics? (A) Gender (B) Socio-Cultural background (C) Nature of mathematics (D) None of these*

**✅ सही उत्तर / Correct Answer: (B)**

---
**94.** प्राथमिक अवस्था में गणित में रचनात्मक मूल्यांकन में अन्तर्निहित है- (A) अधिगम में असंगति को और शिक्षण में कमियों को पहचानना (B) सामान्य त्रुटियों को पहचानना (C) क्रिया-प्रणाली के ज्ञान और विश्लेषणात्मक प्रतिभाओं की परीक्षा (D) विद्यार्थियों के ग्रेड (श्रेणी) और रैंक (स्थिति)

*Formative assessment in mathematics at primary stage includes- (A) Identification of learning gaps and deficiencies in teaching (B) Identification of common errors (C) Testing of procedural knowledge and analytical abilities (D) Grading and ranking of students*

**✅ सही उत्तर / Correct Answer: (A)**

---
**95.** प्रथम 15 पूर्ण संख्याओं का औसत होगा - (A) 7.5 (B) 8 (C) 8.5 (D) 7

*The average of first 15 whole numbers will be - (A) 7.5 (B) 8 (C) 8.5 (D) 7*

**✅ सही उत्तर / Correct Answer: (B)**

---
**96.** किसी त्रिभुज के लिए निम्न में से कौन सा कथन सत्य है? (A) समस्त कोण सदैव न्यूनकोण होते है। (B) एक कोण सदैव समकोण होता है। (C) एक कोण सदैव अधिककोण होता है। (D) एक कोण सदैव न्यूनकोण होता है।

*Which of the following statements is true for a triangle? (A) All the angles are always acute angles. (B) One angle is always a right angle. (C) One angle is always an obtuse angle. (D) One angle is always an acute angle.*

**✅ सही उत्तर / Correct Answer: (D)**

---
**97.** यदि √2916 = 54 तो निम्न का मान क्या होगा- √29.16 + √0.2916 + √0.002916 + √0.00002916
(A) 3.9994 (B) 4.9994 (C) 5.9994 (D) 6.9994

*If √2916 = 54, then what will be the value of the following - √29.16 + √0.2916 + √0.002916 + √0.00002916*
(A) 3.9994 (B) 4.9994 (C) 5.9994 (D) 6.9994

**✅ सही उत्तर / Correct Answer: (C)**

---
**98.** एक आयत को क्षैतिज रूप से दो बराबर भागों में बाँटा जाता है। ऊपर वाले भाग को पुनः तीन बराबर भागों में बाँटा जाता है और निचले भाग को चार बराबर भागों में बाँटा जाता है। मूल आयत का कितना भाग छायांकित है? (आकृति अनुसार) (A) 2/7 (B) 4/7 (C) 7/12 (D) 3/5

*A rectangle is divided horizontally into two equal parts. The upper part is further divided into three equal parts and the lower part is divided into four equal parts. Which fraction of the original rectangle is the shaded part? (as per figure) (A) 2/7 (B) 4/7 (C) 7/12 (D) 3/5*

**✅ सही उत्तर / Correct Answer: (C)**

---
**99.** 4⁶¹ + 4⁶² + 4⁶³ + 4⁶⁴ किससे विभाज्य है - (A) 3 (B) 5 (C) 11 (D) 17

*4⁶¹ + 4⁶² + 4⁶³ + 4⁶⁴ is divisible by - (A) 3 (B) 5 (C) 11 (D) 17*

**✅ सही उत्तर / Correct Answer: (D)**

---
**100.** एक वर्ग की भुजा 4 सेमी है। इसे काटकर 4 बराबर वर्गों में विभाजित किया गया है। प्रत्येक छोटे वर्ग का क्षेत्रफल होगा: (A) 4 सेमी² (B) 1 सेमी² (C) 16 सेमी² (D) 8 सेमी²

*The side of a square is 4 cm. It is cut into 4 equal squares. The area of each small square will be- (A) 4 cm² (B) 1 cm² (C) 16 cm² (D) 8 cm²*

**✅ सही उत्तर / Correct Answer: (A)**

---
**101.** √(242 + √(52+144)) का मान है- (A) 16 (B) 17 (C) 18 (D) इनमें से कोई नहीं

*The value of √(242 + √(52+144)) is - (A) 16 (B) 17 (C) 18 (D) None of these*

**✅ सही उत्तर / Correct Answer: (A)**

---
**102.** 4½, 3, 10½ का ल.स. है - (A) 63 (B) 72 (C) 81 (D) 92

*L.C.M. of 4½, 3, 10½ is - (A) 63 (B) 72 (C) 81 (D) 92*

**✅ सही उत्तर / Correct Answer: (A)**

---
**103.** बालू एवं लोहे के 1 किलोग्राम मिश्रण में 20% लोहा है। लोहे की मात्रा को 10% करने के लिए मिश्रण में कितनी मात्रा में बालू मिलानी होगी? (A) 1 किग्रा. (B) 200 ग्राम (C) 800 ग्राम (D) 1.8 किग्रा.

*There is 20% iron in 1 kg mixture of sand and iron. How much sand must be added to the mixture to make the iron content 10%? (A) 1 kg. (B) 200 gm. (C) 800 gm. (D) 1.8 kg.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**104.** 11 नतीजों का औसत 50 है। यदि पहले छः नतीजों का औसत 49 हो और अन्तिम छः नतीजों का औसत 52 हो तो छठा नतीजा होगा - (A) 56 (B) 54 (C) 52 (D) 48

*The average of 11 results is 50. If the average of the first six results is 49 and that of the last six results is 52, then the sixth result will be- (A) 56 (B) 54 (C) 52 (D) 48*

**✅ सही उत्तर / Correct Answer: (A)**

---
**105.** एक रेलगाड़ी देहरादून से 30 सितम्बर 2022 को 16:30 बजे प्रस्थान करती है और अपने गंतव्य पर 2 अक्टूबर 2022 को 08:45 बजे पहुँचती है। इस यात्रा का कुल समय है- (A) 36 घंटे 15 मिनट (B) 38 घंटे 45 मिनट (C) 39 घंटे 45 मिनट (D) 40 घंटे 15 मिनट

*A train leaves Dehradun on 30th September 2022 at 16:30 hours and reaches its destination on 2nd October 2022 at 08:45 hours. The total travel time of the journey is - (A) 36 hours 15 minutes (B) 38 hours 45 minutes (C) 39 hours 45 minutes (D) 40 hours 15 minutes*

**✅ सही उत्तर / Correct Answer: (D)**

---
**106.** 10 वस्तुओं का क्रय मूल्य 9 वस्तुओं के विक्रय मूल्य के बराबर है। प्रतिशत लाभ होगा - (A) 9 1/9 % (B) 10 1/9 % (C) 11 1/9 % (D) 12 1/9 %

*The cost price of 10 articles is equal to the selling price of 9 articles. The percentage profit will be - (A) 9 1/9 % (B) 10 1/9 % (C) 11 1/9 % (D) 12 1/9 %*

**✅ सही उत्तर / Correct Answer: (C)**

---
**107.** एक कोण का सम्पूरक कोण उसके कोटिपूरक कोण का 4 गुना है, तो वह कोण है - (A) 30° (B) 40° (C) 45° (D) 60°

*The supplementary angle of an angle is four times its complementary angle, then that angle is - (A) 30° (B) 40° (C) 45° (D) 60°*

**✅ सही उत्तर / Correct Answer: (D)**

---
**108.** एक रेलगाड़ी किसी खम्भे को 15 सेकेण्ड में पार कर लेती है तथा 100 मीटर लम्बे प्लेटफार्म को 25 सेकेण्ड में पार करती है। रेलगाड़ी की लम्बाई है- (A) 400 मीटर (B) 350 मीटर (C) 200 मीटर (D) 150 मीटर

*A train crosses a pole in 15 seconds and crosses a platform 100 meters long in 25 seconds. The length of the train is - (A) 400 meter (B) 350 meter (C) 200 meter (D) 150 meter*

**✅ सही उत्तर / Correct Answer: (D)**

---
**109.** 3759×9573 के गुणनफल में दहाई अंक और इकाई अंक का योगफल है - (A) 7 (B) 9 (C) 16 (D) 0

*In the product 3759×9573, the sum of ten's digit and unit's digit is - (A) 7 (B) 9 (C) 16 (D) 0*

**✅ सही उत्तर / Correct Answer: (A)**

---
**110.** यदि किसी आयत की लम्बाई में 20% की कमी कर दी जाए तो उसकी चौड़ाई में कितने प्रतिशत की वृद्धि करने से क्षेत्रफल यथावत रहेगा? (A) 25% (B) 50% (C) 75% (D) इनमें से कोई नहीं

*If the length of a rectangle is decreased by 20%, then by what percent increase in its width, the area will remain the same? (A) 25% (B) 50% (C) 75% (D) None of these*

**✅ सही उत्तर / Correct Answer: (A)**

---
**111.** गणित से भयभीत होने और उसमें असफल होने के लिए निम्नलिखित में से किसे एक कारण नहीं माना जा सकता है? (A) प्रतीकात्मक संकेत (B) गणित की संरचना (C) लैंगिक भेद (D) कक्षा-कक्ष के अनुभव

*Which of the following cannot be considered as a reason for fear and failure in mathematics? (A) Symbolic notations (B) Structure of mathematics (C) Gender differences (D) Classroom experiences*

**✅ सही उत्तर / Correct Answer: (C)**

---
**112.** गणित में ज्यामिति के शिक्षण हेतु सबसे उपयुक्त शिक्षण विधि कौन-सी है? (A) खेल विधि (B) विश्लेषण विधि (C) निगमन विधि (D) खोज विधि

*Which is the most suitable teaching method for teaching Geometry in mathematics? (A) Play-way method (B) Analysis method (C) Deductive method (D) Heuristic method*

**✅ सही उत्तर / Correct Answer: (B)**

---
**113.** 6-ई शिक्षण योजना में प्रयुक्त पदों का सही अनुक्रम है - (i) व्याख्या करना (ii) संलग्न करना (iii) विस्तारित करना (iv) मूल्यांकन करना
(A) (ii),(i),(iii),(iv) (B) (ii),(iii),(i),(iv) (C) (i),(ii),(iii),(iv) (D) (iii),(i),(ii),(iv)

*The correct sequence of terms used in 6-E teaching plan is - (i) Explain (ii) Engage (iii) Elaborate (iv) Evaluate*
(A) (ii),(i),(iii),(iv) (B) (ii),(iii),(i),(iv) (C) (i),(ii),(iii),(iv) (D) (iii),(i),(ii),(iv)

**✅ सही उत्तर / Correct Answer: (A)**

---
**114.** यदि दो संख्याओं का योग तथा गुणनफल क्रमशः 5 तथा 36 हो, तो उनके व्युत्क्रमों का योग होगा- (A) 5/9 (B) 31/36 (C) 5/36 (D) 31/9

*If the sum and product of two numbers are 5 and 36 respectively, then the sum of their reciprocals will be - (A) 5/9 (B) 31/36 (C) 5/36 (D) 31/9*

**✅ सही उत्तर / Correct Answer: (C)**

---
**115.** दिये गये चित्र में OP||RS, ∠OPQ = 100° तथा ∠QRS = 140° तो ∠PQR का मान है- (A) 80° (B) 60° (C) 70° (D) 90°

*In the given fig. OP||RS, ∠OPQ= 100° and ∠QRS= 140° then ∠PQR is equal to - (A) 80° (B) 60° (C) 70° (D) 90°*

**✅ सही उत्तर / Correct Answer: (B)**

---
**116.** 37.188 ÷ 3.6 का मान है - (A) 10.03 (B) 10.3 (C) 10.33 (D) इनमें से कोई नहीं

*The value of 37.188 ÷ 3.6 is - (A) 10.03 (B) 10.3 (C) 10.33 (D) None of these*

**✅ सही उत्तर / Correct Answer: (C)**

---
**117.** मैं कौन-सी संख्या हूँ? मैं दो अंकों की सम संख्या हूँ। मैं 3,4,6 का सार्वगुणज हूँ। मेरे कुल 9 गुणनखण्ड हैं। (A) 36 (B) 48 (C) 56 (D) 24

*What number am I? I am a 2-digit even number. I am a common multiple of 3,4,6. I have a total of 9 factors. (A) 36 (B) 48 (C) 56 (D) 24*

**✅ सही उत्तर / Correct Answer: (A)**

---
**118.** एक घन का पृष्ठीय क्षेत्रफल 1014 वर्ग सेमी हो तो इसका आयतन होगा- (A) 2197 घन सेमी (B) 2297 घन सेमी (C) 2179 घन सेमी (D) 2117 घन सेमी

*Surface area of a cube is 1014 Sq.cm, then its volume will be- (A) 2197 cu.cm. (B) 2297 cu.cm. (C) 2179 cu.cm. (D) 2117 cu.cm.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**119.** 2, 3, 5, 9, 17, 33, ......... अनुक्रम की अगली संख्या होगी- (A) 65 (B) 60 (C) 50 (D) 49

*The next number in the sequence 2, 3, 5, 9, 17, 33, ......... will be - (A) 65 (B) 60 (C) 50 (D) 49*

**✅ सही उत्तर / Correct Answer: (A)**

---
**120.** (0.125)^(2/3) का मान है - (A) 2.5 (B) 0.25 (C) 0.025 (D) 0.0025

*The value of (0.125)^(2/3) is - (A) 2.5 (B) 0.25 (C) 0.025 (D) 0.0025*

---

**✅ सही उत्तर / Correct Answer: (B)**

---


## 📋 उत्तर कुंजी सारांश (Official Answer Key Summary)

| प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर |
|---|---|---|---|---|---|
| 91 | C | 92 | B | 93 | B |
| 94 | A | 95 | B | 96 | D |
| 97 | C | 98 | C | 99 | D |
| 100 | A | 101 | A | 102 | A |
| 103 | A | 104 | A | 105 | D |
| 106 | C | 107 | D | 108 | D |
| 109 | A | 110 | A | 111 | C |
| 112 | B | 113 | A | 114 | C |
| 115 | B | 116 | C | 117 | A |
| 118 | A | 119 | A | 120 | B |
