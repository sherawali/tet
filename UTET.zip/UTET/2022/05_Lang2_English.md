# UTET 2022 — Paper I (Second Language - English)
**Set – B | Booklet Series: XXII-1 | परीक्षा दिनांक/Exam Date: 30 September 2022 | पूर्णांक/Max Marks: 150 | समय/Time: 2 घंटे 30 मिनट**

**अनुभाग / Section:** Second Language - English — प्रश्न 61-90

> **✅ उत्तर कुंजी स्रोत (Answer Key Source) — आधिकारिक / OFFICIAL:** यह उत्तर-कुंजी उत्तराखण्ड विद्यालयी शिक्षा परिषद् (UBSE), रामनगर (नैनीताल) द्वारा जारी **आधिकारिक UTET-I 2022 Answer Key (SET-B)** से ली गई है — स्रोत: [static.collegedekho.com/.../answer_key_utet_i.pdf](https://static.collegedekho.com/media/uploads/2022/10/07/answer_key_utet_i.pdf) (PDF के पेज 2 पर SET-B की तालिका है)। चूँकि यह सीधे Set-B हेतु आधिकारिक दस्तावेज़ है, अतः प्रश्न-क्रमांक सीधे हमारे Set-B दस्तावेज़ के प्रश्न-क्रमांकों से मेल खाते हैं — किसी प्रकार के content-matching या अनुमान की आवश्यकता नहीं रही। (पहले इस्तेमाल किया गया theexampillar.com-आधारित/स्वयं-हल किया हुआ उत्तर-कुंजी अब इस आधिकारिक स्रोत से पूर्णतः प्रतिस्थापित कर दिया गया है।)
>
> *(This answer key is taken directly from the **OFFICIAL UTET-I 2022 Answer Key (SET-B)** issued by the Uttarakhand Board of School Education (UBSE), Ramnagar, Nainital — sourced from a PDF hosted on static.collegedekho.com (page 2 = Set-B table). Since this is the official document specifically for Set-B, question numbers match our document's numbering directly — no content-matching or guesswork was required. This fully replaces the earlier theexampillar.com-based / self-solved answers used in an earlier draft.)*

---

# भाग 5: Second Language - English — प्रश्न 61-90

**61.** The camel is the ship of the desert. (A) Pun (B) Personification (C) Apostrophe (D) Metaphor

*Direction (Q. No. 62): Choose the appropriate active voice to the given statement from the options provided.*

**✅ सही उत्तर / Correct Answer: (D)**

---
**62.** Priyanka has solved the issue. (A) The issue have been solved by Priyanka. (B) The issue is solved by Priyanka. (C) The issue has been solved by Priyanka. (D) The issue had been solved by Priyanka.

*Direction (Q. No. 63): Transform the following sentence into negative without changing its meaning and select the most suitable option:*

**✅ सही उत्तर / Correct Answer: (C)**

---
**63.** Hardly had Ram seen me when he called. (A) No sooner had Ram seen me than he called me. (B) No soon had Ram seen me he called. (C) No sooner Ram seen me he called. (D) No sooner had Ram seen me that he called.

*Direction (Q. No. 64): Choose the correct alternative:*

**✅ सही उत्तर / Correct Answer: (A)**

---
**64.** Rohan _______ the movie before he read the review: (A) watches (B) have watched (C) had watched (D) was watching

**✅ सही उत्तर / Correct Answer: (C)**

---
**65.** The alphabetic method, the phonic method, the board method and the sentence method are associated with: (A) Listening (B) Speaking (C) Reading (D) Writing

**✅ सही उत्तर / Correct Answer: (C)**

---
**66.** Learning a language means _______: (A) Learning all the skills of language (B) Learning and using language skills in appropriate situations (C) Learning to speak fluently in public (D) Writing good books in that language

**✅ सही उत्तर / Correct Answer: (B)**

---
**67.** Which among the following is an example of onomatopoeia? (A) Smog (B) UNESCO (C) Buzz (D) Edit

**✅ सही उत्तर / Correct Answer: (C)**

---
**68.** TBLT in second language teaching is: (A) Task Based Language Training (B) Task Book Language Teaching (C) Tool Based Language Teaching (D) Task Based Language Teaching

**✅ सही उत्तर / Correct Answer: (D)**

---
**69.** Story telling, as a strategy in language teaching, is aimed at _______: (A) Learning the morals (B) Learning to retell the story (C) Engaging learners with language (D) Testing the memory of learners

**✅ सही उत्तर / Correct Answer: (C)**

---
**70.** Which one of the following activities comes under CALP? (A) Making reservations (B) Answering calls (C) Making an appointment for a saloon (D) Writing book reviews

**✅ सही उत्तर / Correct Answer: (D)**

---
**71.** What is the status given to English by the Indian Constitution? (A) National language (B) Link language (C) Official language (D) Associate official language

*Direction (Q.No. 72-75): Read the poem given below and answer the questions that follow by selecting the most appropriate option:*
"Two roads diverged in a yellow wood, / And sorry I could not travel both / And be one traveller, long I stood / And looked down one as far as I could / To where it bent in the undergrowth; / Then took the other, as just as fair, / And having perhaps the better claim, / Because it was grassy and wanted wear; / Though as for that the passing there / Had worn them really about the same, / And both that morning equally lay / In leaves no step had trodden black. / Oh, I kept the first for another day! / Yet knowing how way leads on to way, / I doubted if I should ever come back. / I shall be telling this with a sigh / Somewhere ages and ages hence / Two roads diverged in a wood, and / I took the one less travelled by, / And that has made all the difference." *(The Road Not Taken — Robert Frost)*

**✅ सही उत्तर / Correct Answer: (D)**

---
**72.** Where was the poet? (A) In the city (B) In a desert (C) In the forest (D) On a highway

**✅ सही उत्तर / Correct Answer: (C)**

---
**73.** Why did the poet want to take the less travelled road? (A) To avoid a bumpy ride of another road (B) To get lost in the dense forest (C) In the hope of discovering something new (D) He likes puzzles

**✅ सही उत्तर / Correct Answer: (C)**

---
**74.** What does the poet's long stare at the path signify: (A) The time taken by people to decide and make a choice (B) Poet loves nature (C) Idling away of time (D) Relaxation hours

**✅ सही उत्तर / Correct Answer: (A)**

---
**75.** Mention the figure of speech used in "and having perhaps the better claim": (A) Alliteration (B) Personification (C) Simile (D) Metaphor

*Direction (Q. No. 76-77): Fill in the blanks using appropriate phrase preposition from the given option:*

**✅ सही उत्तर / Correct Answer: (B)**

---
**76.** _______ me, I will be happy to dedicate a few extra hours to the cause. (A) As for (B) As of (C) As from (D) As to

**✅ सही उत्तर / Correct Answer: (A)**

---
**77.** You will have to remember that, _______ John, no one wants to work on this problem. (A) apart to (B) apart from (C) apart (D) apart of

*Direction (Q. No.78): Transform the following superlative sentence into a positive sentence: "Alaska is one of the coldest places."*

**✅ सही उत्तर / Correct Answer: (B)**

---
**78.** (A) Few places are as cold as Alaska. (B) Few places are cold like Alaska. (C) Alaska is colder a place than any place. (D) No place is cold like Alaska.

*Direction (Q. No. 79 to 82): Read the passage given below and answer the questions that follow by selecting the most appropriate option:*
"Law is found in all modern societies and is usually regarded as the bedrock of civilized existence. But what distinguishes law from other social rules, and in what sense does law operate at an international or even global level? Is there such a thing as international law? In the case of domestic law, it is relatively easy to identify a series of distinguishing characteristics. First, law is made by the government and so applies throughout society. Not only does this mean that law reflects the will of the state and therefore takes precedence over all other norms and social rules, but it also gives domestic law universal jurisdiction within a particular political society. Second, law is compulsory; citizens are not allowed to choose which laws to obey and which to ignore, because law is backed up by a system of coercion and punishment. Law thus requires the existence of a legal system, a set of norms and institutions through which legal rules are created, interpreted and enforced. Third, law has a 'public' quality in that it consists of codified, published and recognised rules. This is, in part, achieved by enacting law through a formal and usually public, legislative process. Moreover, punishments handed down for law breaking are predictable and can be anticipated."

**✅ सही उत्तर / Correct Answer: (A)**

---
**79.** What is the basis of civilized existence? (A) State (B) Law (C) Money (D) Principles

**✅ सही उत्तर / Correct Answer: (B)**

---
**80.** How can law be distinguished from social rules? (A) Laws apply to every citizen whereas social rules vary from one society to another. (B) Laws are enforceable upon the society whereas social rules are not enforceable. (C) Laws are acceptable to the political society whereas social rules do not require any system. (D) Laws work according to the proper legal system whereas social rules do not require any system.

**✅ सही उत्तर / Correct Answer: (C)**

---
**81.** What is the outcome of breaking laws? (A) Award (B) Criticism (C) Praise (D) Punishment

**✅ सही उत्तर / Correct Answer: (D)**

---
**82.** Identify a word from the passage which means 'action of using force or threat to do something'. (A) Jurisdiction (B) Enforced (C) Coercion (D) Precedence

*Direction (Q. No. 83-84): Identify the segment in the given sentence which contains a grammatical error:*

**✅ सही उत्तर / Correct Answer: (C)**

---
**83.** I don't recognize none of (A) / the politicians who have been (B) / invited to be (C) / the speakers today (D). (A) I don't recognize none of (B) the politicians who have been (C) invited to be (D) the speakers today

**✅ सही उत्तर / Correct Answer: (A)**

---
**84.** If your jogging clothes (A) / were not made of permeable fabric (B) / you will drown (C) / in your sweat (D). (A) If your jogging clothes (B) were not made of permeable fabric (C) you will drown (D) in your sweat.

*Direction (Q. No. 85): Select the most appropriate pronoun and fill in the blank:*

**✅ सही उत्तर / Correct Answer: (C)**

---
**85.** After the interview, when I looked back, I was annoyed with ___ for not answering a question properly: (A) yourself (B) himself (C) myself (D) themselves

*Direction (Q. No. 86): Choose the word with the correct spelling.*

**✅ सही उत्तर / Correct Answer: (C)**

---
**86.** (A) Accesory (B) Accidentaly (C) Absense (D) Acquitted

*Direction (Q. No. 87-88): Select the correct alternative which can be substituted for the 'describing phrases' below:*

**✅ सही उत्तर / Correct Answer: (D)**

---
**87.** A person difficult to please: (A) Illiterate (B) Arbitrator (C) Fastidious (D) Egotist

**✅ सही उत्तर / Correct Answer: (C)**

---
**88.** A person who hates women: (A) Misogamist (B) Misogynist (C) Bigot (D) Impervious

*Direction (Q. No. 89): Choose the most suitable option that describes the meaning of the following idiom.*

**✅ सही उत्तर / Correct Answer: (B)**

---
**89.** Hit the sack (A) Hit the clothes pile (B) Go to sleep (C) Go to work (D) Go to gym

*Direction (Q. No. 90): In the following sentence choose the antonym to the underlined word:*

**✅ सही उत्तर / Correct Answer: (B)**

---
**90.** We should strive for the country's **development**. (A) Retrogression (B) Transgression (C) Impurity (D) Progress

---

**✅ सही उत्तर / Correct Answer: (A)**

---


## 📋 उत्तर कुंजी सारांश (Official Answer Key Summary)

| प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर |
|---|---|---|---|---|---|
| 61 | D | 62 | C | 63 | A |
| 64 | C | 65 | C | 66 | B |
| 67 | C | 68 | D | 69 | C |
| 70 | D | 71 | D | 72 | C |
| 73 | C | 74 | A | 75 | B |
| 76 | A | 77 | B | 78 | A |
| 79 | B | 80 | C | 81 | D |
| 82 | C | 83 | A | 84 | C |
| 85 | C | 86 | D | 87 | C |
| 88 | B | 89 | B | 90 | A |
