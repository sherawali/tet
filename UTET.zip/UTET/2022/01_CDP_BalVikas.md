# UTET 2022 — Paper I (बाल विकास एवं शिक्षण विज्ञान (Child Development and Pedagogy))
**Set – B | Booklet Series: XXII-1 | परीक्षा दिनांक/Exam Date: 30 September 2022 | पूर्णांक/Max Marks: 150 | समय/Time: 2 घंटे 30 मिनट**

**अनुभाग / Section:** बाल विकास एवं शिक्षण विज्ञान (Child Development and Pedagogy) — प्रश्न 1-30

> **✅ उत्तर कुंजी स्रोत (Answer Key Source) — आधिकारिक / OFFICIAL:** यह उत्तर-कुंजी उत्तराखण्ड विद्यालयी शिक्षा परिषद् (UBSE), रामनगर (नैनीताल) द्वारा जारी **आधिकारिक UTET-I 2022 Answer Key (SET-B)** से ली गई है — स्रोत: [static.collegedekho.com/.../answer_key_utet_i.pdf](https://static.collegedekho.com/media/uploads/2022/10/07/answer_key_utet_i.pdf) (PDF के पेज 2 पर SET-B की तालिका है)। चूँकि यह सीधे Set-B हेतु आधिकारिक दस्तावेज़ है, अतः प्रश्न-क्रमांक सीधे हमारे Set-B दस्तावेज़ के प्रश्न-क्रमांकों से मेल खाते हैं — किसी प्रकार के content-matching या अनुमान की आवश्यकता नहीं रही। (पहले इस्तेमाल किया गया theexampillar.com-आधारित/स्वयं-हल किया हुआ उत्तर-कुंजी अब इस आधिकारिक स्रोत से पूर्णतः प्रतिस्थापित कर दिया गया है।)
>
> *(This answer key is taken directly from the **OFFICIAL UTET-I 2022 Answer Key (SET-B)** issued by the Uttarakhand Board of School Education (UBSE), Ramnagar, Nainital — sourced from a PDF hosted on static.collegedekho.com (page 2 = Set-B table). Since this is the official document specifically for Set-B, question numbers match our document's numbering directly — no content-matching or guesswork was required. This fully replaces the earlier theexampillar.com-based / self-solved answers used in an earlier draft.)*

---

# भाग 1: बाल विकास एवं शिक्षण विज्ञान (Child Development and Pedagogy) — प्रश्न 1-30

**1.** किस विधि में व्यक्ति समस्या समाधान करने के लिए सभी विकल्पों को नहीं ढूँढता है अपितु केवल उन्हीं विकल्पों का चयन करता है और समस्या का समाधान करने की कोशिश करता है जो उसे संगत प्रतीत होते हैं।
(A) स्वतः शोध अन्वेषण (B) यादृच्छिक अन्वेषण विधि (C) साधन-साध्य विश्लेषण (D) पश्चगामी अन्वेषण

*In which method, a person does not find all the options for problem solving but he only selects those options and tries to solve the problem which he finds appropriate.*
(A) Heuristics (B) Random Search Method (C) Means-ends analysis (D) Backward search

**✅ सही उत्तर / Correct Answer: (A)**

---
**2.** कॉलम 'A' का मिलान कॉलम 'B' से कीजिए-
कॉलम 'A': (1) ग्रामर (2) सीमैंटिक विकास (3) बेबलिंग (4) फोनोलॉजिकल विकास
कॉलम 'B': (a) पहचानने योग्य भाषा बोलने की क्षमता (b) एक भाषा में निहित नियम (c) भाषा विकास की प्रारंभिक अवस्था (d) बोलने व लिखने की भाषा के अर्थ को समझना
(A) (1-a)(2-b)(3-c)(4-d)  (B) (1-b)(2-d)(3-c)(4-a)  (C) (1-a)(2-c)(3-d)(4-b)  (D) (1-c)(2-a)(3-d)(4-b)

*Match Column A with Column B — Column A: (1) Grammar (2) Semantic development (3) Babbling (4) Phonological development; Column B: (a) ability to produce recognizable speech (b) Rules within a given language (c) An early stage of speech development (d) Understanding of the meaning of spoken and written language*
(A) (1-a)(2-b)(3-c)(4-d)  (B) (1-b)(2-d)(3-c)(4-a)  (C) (1-a)(2-c)(3-d)(4-b)  (D) (1-c)(2-a)(3-d)(4-b)

**✅ सही उत्तर / Correct Answer: (B)**

---
**3.** शिक्षण अधिगम प्रक्रिया को प्रभावित करने वाले मनोवैज्ञानिक कारक हैं- (1) विद्यार्थियों में अभिप्रेरणा (2) सुंदर कक्षाकक्ष (3) रूचि एवं विद्यार्थियों में अभिक्षमता (4) विद्यालय की आधारभूत संरचना
(A) 1,2,3 (B) 1,2 (C) 1,3 (D) 3,4

*The psychological factors affecting the teaching learning process are - (1) Motivation of students (2) Beautiful classroom (3) Interest and aptitude of students (4) School infrastructure*
(A) 1,2,3 (B) 1,2 (C) 1,3 (D) 3,4

**✅ सही उत्तर / Correct Answer: (C)**

---
**4.** विशेष आवश्यकता वाले बच्चों के लिए शिक्षण अधिगम सामग्री होनी चाहिए- (A) रंग बिरंगी (B) बहुसंवेदी (C) आकार में बड़ी (D) आकर्षक

*Teaching learning material for children with special needs should be - (A) Colourful (B) Multisensory (C) Big in size (D) Attractive*

**✅ सही उत्तर / Correct Answer: (B)**

---
**5.** जब एक विद्यार्थी उस व्यवहार को निष्पादित करना सीखता है जो सकारात्मक परिणाम देता है और उस व्यवहार को करने से बचता है जिससे उसे नकारात्मक परिणाम मिले, यह उदाहरण है: (A) क्रिया प्रसूत अनुबंधन का (B) शास्त्रीय अनुबंधन का (C) समक्षणिक अनुबंधन का (D) संकेत कालिक अनुबंधन का

*When a student learns to perform behaviours that produce positive outcomes and to avoid behaviour that yields negative outcome, this is an example of: (A) Operant conditioning (B) Classical conditioning (C) Simultaneous conditioning (D) Trace conditioning*

**✅ सही उत्तर / Correct Answer: (A)**

---
**6.** आप किस परिस्थिति में विद्यार्थियों को सतत् पुनर्बलन देंगे: (A) पूर्व व्यवहार को स्थापित करने के लिए (B) नए व्यवहार को स्थापित करने के लिए (C) नए व्यवहार को बनाए रखने के लिए (D) (B) और (C) दोनों

*In which situation will you give continuous reinforcement to students: (A) For establishing a past behaviour (B) For establishing a new behaviour (C) In maintaining a new behaviour (D) Both (B) and (C)*

**✅ सही उत्तर / Correct Answer: (B)**

---
**7.** यदि आपने कभी किसी को अंधेरे कमरे में फ्लैशलाइट लहराते हुए देखा और उसके पीछे आपको रोशनी का पथ दिखाई दिया तो आप विज्ञ हैं ......... स्मृति के संचालन से। (A) लघुकालीन स्मृति (B) दीर्घकालीन स्मृति (C) प्रक्रियात्मक स्मृति (D) संवेदी स्मृति

*If you've ever watched someone wave a flashlight in a darkroom and perceived trails of light behind it, you are familiar with the operation of --------- memory. (A) Short term memory (B) Long term memory (C) Procedural memory (D) Sensory memory*

**✅ सही उत्तर / Correct Answer: (D)**

---
**8.** निम्नलिखित में से अधिगम अक्षम बच्चे की कौन सी विशेषताएँ हैं: (1) अच्छी ध्यान अवधि (2) लिखते समय अक्षरों को छोड़ना (3) गणितीय चिन्हों को समझने में कठिनाई
(A) 1,2,3 (B) 1,3 (C) 2,3 (D) 1,2

*Which of the following are the characteristics of a learning disabled child: (1) Good attention span (2) Omit words while writing (3) Difficulty in understanding mathematical symbols*
(A) 1,2,3 (B) 1,3 (C) 2,3 (D) 1,2

**✅ सही उत्तर / Correct Answer: (C)**

---
**9.** निम्नलिखित में से कौन सा विद्यालय में समावेशी वातावरण के विकास में सहायक होगा? (A) सभी गतिविधियों में पूर्ण प्रतिभागिता सुनिश्चित करना (B) बाधारहित वातावरण का सृजन (C) पाठ्यचर्या अनुकूलन एवं कक्षा-कक्ष प्रबंधन (D) उपरोक्त सभी

*Which of the following will help in the development of inclusive environment in school: (A) Ensure full participation in all activities (B) Creation of barrier free environment (C) Curriculum adaptation and classroom management (D) All of the above*

**✅ सही उत्तर / Correct Answer: (D)**

---
**10.** निम्नलिखित में से कौन सा कथन समावेशित शिक्षा की अवधारणा को अभिव्यक्त करता है? (1) सभी बच्चे साथ सीखते हैं। (2) क्षमताओं के स्थान पर अक्षमताओं पर अधिक ध्यान। (3) व्यक्तिगत सीखने के तरीके पर ध्यान। (4) समतापूर्वक सभी विद्यार्थियों की आवश्यकताओं का सम्मान
(A) 1,2,3 (B) 1,2,3,4 (C) 1,3,4 (D) 2,3,4

*Which of the following statements express the concept of Inclusive education? (1) All children learn together (2) Focus on disabilities rather than abilities (3) Focus on individual learning style (4) Honour the needs of all students equitably*
(A) 1,2,3 (B) 1,2,3,4 (C) 1,3,4 (D) 2,3,4

**✅ सही उत्तर / Correct Answer: (C)**

---
**11.** एन.ई.पी. 2020 केन्द्रित करती है: (A) रचनात्मक आकलन पर आधारित प्रगति कार्ड पर (B) योगात्मक आकलन पर आधारित प्रगति कार्ड पर (C) व्यापक आकलन पर आधारित प्रगति कार्ड पर (D) 360° समग्र प्रगति कार्ड पर

*NEP 2020 focuses on: (A) Formative assessment based progress card (B) Summative assessment based progress card (C) Comprehensive assessment based progress card (D) 360° holistic progress card*

**✅ सही उत्तर / Correct Answer: (D)**

---
**12.** निम्नलिखित में से आकलन का कौन सा तरीका शिक्षक को न केवल प्रत्येक बच्चे के सीखने में अंतर को समझने अपितु स्वयं के शिक्षण अधिगम को बच्चों की आवश्यकताओं एवं सीखने के तरीके के अनुसार समीक्षा करने, संशोधित व चिंतन करने में सहायता करता है: (A) अधिगम का आकलन (B) अधिगम के रूप में आकलन (C) अधिगम के लिए आकलन (D) प्रोन्नति के लिए आकलन

*Which of the following way of assessment helps teachers not only to understand the learning gaps of each child but also to reflect, review and modify their teaching learning as per the need and learning styles of students: (A) Assessment of learning (B) Assessment as learning (C) Assessment for learning (D) Assessment for promoting*

**✅ सही उत्तर / Correct Answer: (C)**

---
**13.** रक्षा अपने सभी काम निर्धारित समय में पूरे करती है। वह नियमित रूप से पढ़ाई करती है क्योंकि वह डॉक्टर बनना चाहती है। वह: (A) आंतरिक रूप से अभिप्रेरित है। (B) बाह्य रूप से अभिप्रेरित है। (C) प्रशंसा पाने के लिए अभिप्रेरित है। (D) कठिन परिश्रमी है किन्तु महत्वाकांक्षी है।

*Raksha completes all her work in due time. She studies regularly because she wants to be a Doctor. She is: (A) Intrinsically motivated. (B) Extrinsically motivated. (C) Motivated to be praised. (D) Hardworking but ambitious.*

**✅ सही उत्तर / Correct Answer: (A)**

---
**14.** कोई विद्यार्थी विद्यालय में कितना अभिप्रेरित है यह जानने के लिए आप किस तकनीक का सरलता से प्रयोग कर सकते हैं: (A) अवलोकन विधि (B) प्रक्षेपीय विधि (C) प्रश्नावली विधि (D) व्यक्तिवृत विधि

*Which technique can you use easily to know how much a child is motivated in school: (A) Observation technique (B) Projective technique (C) Questionnaire technique (D) Case study technique*

**✅ सही उत्तर / Correct Answer: (A)**

---
**15.** मैसलो के अनुसार, एक स्थिति जिसमें व्यक्ति अपनी पूर्ण क्षमता तक पहुँच जाता है, को कहते हैं: (A) स्व-जागरूकता (B) आत्मसिद्धि (C) आत्म-सम्मान (D) आत्म-प्रभावकारिता

*According to Maslow, a state in which people reach their fullest potential is called as: (A) self-awareness (B) self-actualization (C) self-esteem (D) self-efficacy*

**✅ सही उत्तर / Correct Answer: (B)**

---
**16.** यदि किसी बच्चे में प्रशिक्षण के बाद किसी ज्ञान या कौशल को प्राप्त करने की क्षमता है तो यह दर्शाता है उसकी: (A) बुद्धि को (B) अभिक्षमता को (C) रूचि को (D) अभिवृत्ति को

*If a child has a capacity to acquire some specific knowledge or skill after training then this indicates his: (A) Intelligence (B) Aptitude (C) Interest (D) Attitude*

**✅ सही उत्तर / Correct Answer: (B)**

---
**17.** कथन-1: संवेग के विकास को परिपक्वता तथा अधिगम दोनों ही प्रभावित करते हैं। कथन-2: ये दोनों प्रक्रियाएँ एक दूसरे पर निर्भर करती हैं तथा परस्पर संबंधी हैं।
(A) कथन-1 सत्य है किन्तु कथन-2 असत्य है। (B) केवल कथन-2 सत्य है। (C) दोनों कथन सत्य हैं। (D) दोनों कथन असत्य हैं।

*Statement-1: Maturation and learning both affect the development of emotions. Statement-2: Both these processes depend on each other and are mutually related.*
(A) Statement-1 is true but statement-2 is false. (B) Only statement-2 is true. (C) Both the statements are true. (D) Both the statements are false.

**✅ सही उत्तर / Correct Answer: (C)**

---
**18.** निम्नलिखित में से कौन सा प्रश्न बच्चों की अवधारणात्मक समझ के परीक्षण हेतु सबसे उपयुक्त है? (A) भारत की राजधानी क्या है? (B) नौ ग्रहों के नाम बताइए। (C) रेगिस्तान में पौधों के काँटे क्यों होते हैं? (D) किसे राष्ट्रपिता कहा जाता है?

*Which of the following question will be most appropriate for testing the conceptual understanding of students? (A) What is the capital of India? (B) Name the nine planets. (C) Why plants in desert have thorns? (D) Who is called the father of the Nation?*

**✅ सही उत्तर / Correct Answer: (C)**

---
**19.** निम्नलिखित में से आप किस बच्चे को सृजनात्मक कहेंगे? (A) जो नए विचार प्रस्तुत करता है। (B) जो नई वस्तुएँ बनाता है। (C) जो अपने कार्य में नवीनता और मौलिकता का प्रदर्शन करता है। (D) उपरोक्त सभी

*Out of the following, which child will you say is creative? (A) Who presents new thoughts. (B) Who creates new things. (C) Who shows novelty and originality in his work. (D) All of the above*

**✅ सही उत्तर / Correct Answer: (D)**

---
**20.** 6 से 8 वय वर्ग के बच्चों के विकासात्मक कार्य हैं: (1) दो शब्द बोलना सीखना। (2) सरल खेलों के लिए शारीरिक कौशल सीखना। (3) पढ़ने, गणना करने एवं लिखने के मूलभूत कौशलों का विकास।
(A) केवल 1 (B) 1 एवं 2 (C) 2 एवं 3 (D) केवल 3

*Developmental tasks of children aged 6 to 8 years are: (1) learn to speak two words. (2) learn physical skills for simple games. (3) develops basic skills in reading, calculating and writing.*
(A) only 1 (B) 1 & 2 (C) 2 & 3 (D) only 3

**✅ सही उत्तर / Correct Answer: (C)**

---
**21.** रीना एक प्रतिभावान छात्रा है। बुद्धि परीक्षण के आधार पर उसे मेधावी कहा जा सकता है। किन्तु वह सदैव महसूस करती है कि उसकी कक्षा नीरस है। एक शिक्षक के रूप में आप रीना की कैसे सहायता कर सकते हैं? (A) उसे सामान्य शिक्षण विधि द्वारा पढ़ाकर (B) उच्च स्तरीय कौशल विकास हेतु रोचक शिक्षण विधि का प्रयोग करके (C) उसको कक्षा का मॉनिटर बनाकर (D) उसको अधिक गृहकार्य देकर

*Reena is a talented girl. On the basis of intelligence testing, she can be said brilliant but she always feels that her class is boring. How can you help Reena as a teacher? (A) Teaching her by simple method (B) Use interesting teaching methods for developing higher order skills (C) Make her class monitor (D) Give her more home assignments*

**✅ सही उत्तर / Correct Answer: (B)**

---
**22.** विद्यार्थियों में टीम भावना के विकास में निम्नलिखित में से किस प्रकार का वातावरण सहायक होगा? (A) प्रतिस्पर्धात्मक (B) सहयोगात्मक (C) व्यक्तिपरक (D) अनुशासित

*Which of the following environment will help in the development of team spirit among students? (A) Competitive (B) Cooperative (C) Individualistic (D) Disciplined*

**✅ सही उत्तर / Correct Answer: (B)**

---
**23.** कक्षा शिक्षण के दौरान निम्नलिखित में से कौन सी चीज सुनिश्चित की जानी चाहिए: (A) डिजिटल टी.एल.एम. का प्रयोग (B) आई.सी.टी. का अधिकतम उपयोग (C) वैयक्तिक भिन्नता के अनुरूप शिक्षण (D) व्याख्यान विधि का प्रयोग

*During classroom teaching which of the following should be ensured: (A) Use of digital TLM (B) Maximum use of ICT (C) Teaching according to individual differences (D) Use of lecture method*

**✅ सही उत्तर / Correct Answer: (C)**

---
**24.** निम्नलिखित में से कौन संवेगात्मक बुद्धि की विशेषताएँ हैं: (1) उच्च आई.क्यू. किन्तु अस्थिर (2) दूसरों को अभिप्रेरित करने में सक्षम (3) स्वयं के संवेगों का प्रबंधन
(A) 1 और 2 (B) 1,2,3 (C) 1 और 3 (D) 2 और 3

*Which of the following are the traits of emotional intelligence: (1) High I.Q. but instable (2) Being able to motivate others (3) Managing one's own emotions*
(A) 1 & 2 (B) 1,2,3 (C) 1 & 3 (D) 2 & 3

**✅ सही उत्तर / Correct Answer: (D)**

---
**25.** पियाजे के अनुसार, बच्चे विश्व के विषय में बढ़ते ज्ञान का निर्माण निम्न दो प्रक्रियाओं द्वारा करते हैं: (A) आत्मसात्यकरण एवं अनुकूलन (B) आत्मसात्यकरण एवं स्केफोल्डिंग (C) स्कीमा एवं आत्मसात्यकरण (D) स्कीमा एवं अनुकूलन

*According to Piaget, children build increasing knowledge of the world through the following two processes: (A) Assimilation and accommodation (B) Assimilation and scaffolding (C) Schema and assimilation (D) Schema and accommodation*

**✅ सही उत्तर / Correct Answer: (A)**

---
**26.** छोटे बच्चों में स्वयं के दृष्टिकोण को दूसरों से भिन्न करने में असमर्थता को क्या कहा जाता है? (A) संरक्षण (B) अहंभाव (C) अंतःस्थितीय चिंतन (D) वस्तु-स्थायित्व

*The inability of young children to distinguish their own perspective from that of others is called as: (A) Conservation (B) Egocentrism (C) Interpropositional thinking (D) Object permanence*

**✅ सही उत्तर / Correct Answer: (B)**

---
**27.** कोलबर्ग के सिद्धांत के पारंपरिक स्तर पर नैतिकता को जाँचा जाता है: (A) समाज के नियम कानून के आधार पर (B) इसके परिणामों के आधार पर (C) अमूर्त सिद्धान्तों और मूल्यों के आधार पर (D) इनमें से कोई नहीं

*At the conventional level of Kohlberg's theory morality is judged in terms of: (A) laws and rules of society (B) its consequences (C) abstract principles and values (D) none of these*

**✅ सही उत्तर / Correct Answer: (A)**

---
**28.** बहुत प्रकार की बुद्धियाँ होती हैं जैसे शाब्दिक, गणितीय, शारीरिक-गत्यात्मक आदि। इस अवधारणा को किसके द्वारा दिया गया: (A) बीने (B) गार्डनर (C) स्टर्नबर्ग (D) बेचलर

*There are several kinds of intelligence such as verbal, mathematical, bodily-kinesthetic etc. This concept was given by: (A) Binet (B) Gardner (C) Sternberg (D) Wechsler*

**✅ सही उत्तर / Correct Answer: (B)**

---
**29.** कथन: ऐसे शीलगुण जो अत्यधिक अनुवांशिक होते हैं, उन्हें पर्यावरणीय कारकों से दृढ़तापूर्वक प्रभावित किया जा सकता है। व्याख्या: लम्बाई अत्यधिक अनुवांशिक होती है, किन्तु पोषण एवं अन्य कारकों के परिणामस्वरूप बहुत से देशों में औसत लम्बाई बढ़ी है।
(A) कथन सत्य है व उसकी व्याख्या भी सत्य है। (B) कथन सत्य है किन्तु उसकी व्याख्या असत्य है। (C) कथन व व्याख्या दोनों ही असत्य हैं। (D) कथन असत्य है किन्तु व्याख्या सत्य है।

*Statement: Traits that are highly heritable can be strongly influenced by environmental factors. Explanation: Height is highly heritable yet average height has increased in many countries as a result of improved nutrition and other factors.*
(A) Statement is correct and its explanation is also correct. (B) Statement is true but its explanation is false. (C) Both statement and explanation are false. (D) Statement is false but explanation is true.

**✅ सही उत्तर / Correct Answer: (A)**

---
**30.** कथन-1: जितना अधिक सूचना के प्रसंस्करण के विस्तार हेतु प्रयास किए जाएँगे उतनी ही सरलता से बाद में सूचना को याद किया जा सकेगा। कथन-2: जब हमें नई सूचना प्राप्त होती है उस समय प्रसंस्करण का स्तर जितना गहरा होता है तो सूचना के दीर्घकालिक स्मृति में प्रवेश करने की संभावना उतनी अधिक होती है।
(A) केवल कथन-1 सही है। (B) केवल कथन-2 सही है। (C) न कथन-1, न ही कथन-2 सही है। (D) दोनों कथन 1 व 2 सही हैं।

*Statement-1: The greater the effort expended in processing information, the more readily the information will be recalled later. Statement-2: Deeper the level of processing that takes place when we encounter new information, the more likely the information is to enter long term memory.*
(A) Only statement-1 is correct. (B) Only statement-2 is correct. (C) Neither statement-1 nor statement-2 is correct. (D) Both the statements 1 & 2 are correct.

---

**✅ सही उत्तर / Correct Answer: (D)**

---


## 📋 उत्तर कुंजी सारांश (Official Answer Key Summary)

| प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर | प्रश्न सं. | उत्तर |
|---|---|---|---|---|---|
| 1 | A | 2 | B | 3 | C |
| 4 | B | 5 | A | 6 | B |
| 7 | D | 8 | C | 9 | D |
| 10 | C | 11 | D | 12 | C |
| 13 | A | 14 | A | 15 | B |
| 16 | B | 17 | C | 18 | C |
| 19 | D | 20 | C | 21 | B |
| 22 | B | 23 | C | 24 | D |
| 25 | A | 26 | B | 27 | A |
| 28 | B | 29 | A | 30 | D |
