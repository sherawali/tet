# UTET 2026 — Paper I (Class I–V) — Booklet XXVI-1, SET-D

## Section 3 : Second Language — English
**Questions 61 – 90** | 1 mark each

> ⚠️ Official answer key not released yet. Answers below are reasoned.

---

**61.** Listening and reading are classified as which type of skills?

- (A) Productive skills
- (B) Creative skills
- (C) Receptive skills ✅
- (D) Expressive skills

**Answer : (C)**

---

**62.** The Communicative Language Teaching (CLT) approach focuses mainly on :

- (A) Memorizing complex grammar rules
- (B) Translating texts word-for-word
- (C) Developing meaningful, real life communication ✅
- (D) Perfecting handwriting and spelling

**Answer : (C)**

---

### Direction (Q. No. 63 to 66) :
Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> The celebration of "workaholism" has long been a foundational pillar of corporate culture. Employees who routinely sacrifice their sleep, personal relationships and leisure time are consistently rewarded with promotions and public praise. This glorification of constant busyness treats human labour as a machine that can run indefinitely without maintenance.
>
> However, this hyper-productive ethos masks a deeper structural crisis: severe mental burnout and a collapse of employee well-being. When a workspace transforms into a pressure cooker of endless deadlines, creativity is ironically the very first casualty. True innovation requires cognitive breathing room — periods of stillness where the brain can connect unrelated ideas. By chaining individuals to a relentless cycle of immediate reactive tasks, organizations trade long-term creative breakthroughs for short-term, superficial productivity metrics. This toxic environment does not just harm the individual worker. It eventually erodes the collective intellectual capital of the enterprise itself, proving that the cult of endless hustle is ultimately a self-defeating strategy.

---

**63.** According to the passage, corporate culture values employees who :

- (A) Balance their work and personal life effectively
- (B) Prioritize physical health and sleep over targets
- (C) Sacrifice leisure time and sleep for constant busyness ✅
- (D) Focus inclusively on long term creative projects

**Answer : (C)**

---

**64.** Why does the author use the word "ironically" when discussing creativity?

- (A) Because modern companies are famous for being highly creative places
- (B) Because a culture meant to increase output actually destroys the ability to innovate ✅
- (C) Because employees enjoy the stress of working under pressure
- (D) Because machines are better at being creative than humans are

**Answer : (B)**

---

**65.** Which word best describes the tone of the author in the second paragraph?

- (A) Celebratory and enthusiastic
- (B) Critical and cautionary ✅
- (C) Indifferent and neutral
- (D) Humorous and playful

**Answer : (B)**

---

**66.** In the sentence "creativity is ironically the very first casualty", what does the word "casualty" mean?

- (A) A casual or relaxed approach
- (B) A sudden financial reward
- (C) Something that is lost or destroyed as a result of an event ✅
- (D) A new corporate rule or policy

**Answer : (C)**

---

### Direction (Q. No. 67) :
Choose the most suitable option that describes the meaning of the underlined idiom/phrase.

**67.** The manager told the team that it was time to **call it a day** after working for ten straight hours.

- (A) To start a brand new project
- (B) To schedule an early morning meeting
- (C) To stop working on something for the rest of the day ✅
- (D) To complain about the heavy workload

**Answer : (C)**

---

### Direction (Q. No. 68) :
Choose the correct antonym for the underlined word.

**68.** The young defence attorney was praised for her **candid** assessment of the case.

- (A) Frank
- (B) Sincere
- (C) Devout
- (D) Deceitful ✅

**Answer : (D)**

---

**69.** Which of the following is considered the first stage of a child's language development before actual words are spoken?

- (A) Telegraphic speech
- (B) Two-word stage
- (C) Babbling (Pre-linguistic stage) ✅
- (D) Holophrastic stage

**Answer : (C)**

---

### Direction (Q. No. 70) :
Choose the part which contains an error.

**70.** The captain along with / his crew members / were praised for / their bravery during the storm.

- (A) The captain along with
- (B) his crew members
- (C) were praised for ✅
- (D) their bravery during the storm

**Answer : (C)**  *("along with" does not change the subject — it should be "was praised for")*

---

### Direction (Q. No. 71 & 72) :
Choose the single word that best substitutes the given descriptive phrase.

**71.** A remedy for all diseases :

- (A) Antibiotic
- (B) Vaccine
- (C) Antidote
- (D) Panacea ✅

**Answer : (D)**

---

**72.** Incapable of being corrected, reformed or improved :

- (A) Infallible
- (B) Illegible
- (C) Incorrigible ✅
- (D) Invincible

**Answer : (C)**

---

### Direction (Q. No. 73 to 76) :
Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> **Patience is better than wisdom**
>
> An ounce of patience is worth a pound of brains. All men praise patience, but few can practise it. It is medicine which is good for all diseases, but it is not every garden that grows the herbs to make it with. Many people are born crying, live complaining and die disappointed. They think every other person's burden to be light and their own feathers to be heavy as lead, and yet if the truth were known, it is their fancy rather than their fate that makes things go so hard with them. Many would be well off if they could but think so.

---

**73.** The writer's remark, "It is their fancy rather than their fate" means :

- (A) They are unhappy because they think that way and not because it is their destiny. ✅
- (B) They are fatalists rather than imaginative.
- (C) They have a wrong approach in life.
- (D) They are very much absorbed in their own problems.

**Answer : (A)**

---

**74.** Which one is the most likely explanation of the author's metaphorical statement that 'it is not every garden that grows the herbs to make it with'?

- (A) Patience is a must for solving all our problems in life.
- (B) Patience is a rare herb that cures all diseases.
- (C) Patience is quite difficult to practise.
- (D) It is only a small number of people that are found observing patience in life. ✅

**Answer : (D)**

---

**75.** What is patience compared to in the passage?

- (A) A medicine ✅
- (B) A weapon
- (C) A treasure
- (D) A book

**Answer : (A)**

---

**76.** Which word is closest in meaning to 'patience'?

- (A) Anger
- (B) Endurance ✅
- (C) Hurry
- (D) Fear

**Answer : (B)**

---

### Direction (Q. No. 77) :
Choose the correct conjunction and fill in the blank.

**77.** He took a map with him ________ he should lose his way in the dense forest.

- (A) otherwise
- (B) lest ✅
- (C) unless
- (D) in case of

**Answer : (B)**  *("lest … should" is the fixed pattern)*

---

### Direction (Q. No. 78) :
Choose the correct synonym for the underlined word.

**78.** The architectural firm designed a **colossal** stadium.

- (A) Immense ✅
- (B) Tiny
- (C) Modern
- (D) Ancient

**Answer : (A)**

---

### Direction (Q. No. 79 & 80) :
Choose the correct indirect form for each direct sentence.

**79.** The manager said to the team, "We must complete this assignment by tomorrow."

- (A) The manager told the team that they must complete that assignment by tomorrow.
- (B) The manager told the team that they had to complete that assignment the next day. ✅
- (C) The manager said to the team that we had to complete this assignment the next day.
- (D) The manager told the team that they must have completed that assignment the next day.

**Answer : (B)**

---

**80.** "Where did you park the car?" Rohan asked his sister.

- (A) Rohan asked his sister where did she park the car.
- (B) Rohan asked his sister where she has parked the car.
- (C) Rohan asked his sister if she had parked the car.
- (D) Rohan asked his sister where she had parked the car. ✅

**Answer : (D)**

---

**81.** Complete the sentence using appropriate phrasal verb :
*We ________ an old friend while shopping yesterday.*

- (A) ran into ✅
- (B) looked up
- (C) came up
- (D) turn up

**Answer : (A)**

---

**82.** Which skill is most critical for building fundamental sound awareness and correct pronunciation?

- (A) Reading
- (B) Writing
- (C) Listening ✅
- (D) Memorization

**Answer : (C)**

---

### Direction (Q. No. 83 & 84) :
Choose the correct past continuous tense and fill in the blanks.

**83.** While I ________ my homework, the power went out.

- (A) am doing
- (B) was doing ✅
- (C) did
- (D) were doing

**Answer : (B)**

---

**84.** At the stroke of midnight on New Year's Eve, my family and I ________ to our favourite songs when the doorbell rang.

- (A) listened
- (B) had listened
- (C) listen
- (D) were listening ✅

**Answer : (D)**

---

**85.** Phoneme refers to the smallest unit of :

- (A) Meaning
- (B) Grammar
- (C) Writing
- (D) Sound ✅

**Answer : (D)**

---

**86.** What is the primary purpose of a diagnostic test in language pedagogy?

- (A) To grade students at the end of a course
- (B) To identify specific learning difficulties, strengths and weaknesses of a student ✅
- (C) To determine a student's proficiency level for college admission
- (D) To compare a student's performance with a normative group of peers

**Answer : (B)**

---

### Direction (Q. No. 87) :
Identify the part of speech of the underlined word.

**87.** The project failed because the team did not **cooperate** effectively.

- (A) Noun
- (B) Adjective
- (C) Adverb
- (D) Verb ✅

**Answer : (D)**

---

**88.** Which method bans the use of the learner's native language?

- (A) Direct Method ✅
- (B) Grammar Translation Method
- (C) Bilingual Method
- (D) Structural approach

**Answer : (A)**

---

### Direction (Q. No. 89) :
Choose the option with the most suitable pronouns.

**89.** The professor ________ we all respect highly has published a new book, ________ she hopes will revolutionize the field of linguistics.

- (A) who, that
- (B) whom, who
- (C) whom, which ✅
- (D) that, which

**Answer : (C)**  *(object pronoun "whom" for the person; "which" for the book)*

---

### Direction (Q. No. 90) :
Identify the part of speech of the underlined word.

**90.** She speaks **softly** to the children.

- (A) Noun
- (B) Verb
- (C) Adverb ✅
- (D) Adjective

**Answer : (C)**

---

*End of Section 3 (Second Language – English)*
