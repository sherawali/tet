# First Language — English
**UTET 2024 — Paper I, SET-D (XXIV-I) | Questions 31 to 60**

---

**31.** What is the main purpose of poetry recitation in a language classroom?
(A) To appreciate and enjoy the poem (B) To give their opinions about the poem (C) To become aware of the poet and his work (D) To encourage children to become poets

**32.** Mohan Chandra Joshi, an English teacher, presents material in the form of dialogue and uses vocabulary in context with hand motions, signal cards etc. Which method does he use to teach English?
(A) Active Learning method (B) Bilingual method (C) Audio Lingual method (D) None of these

**33.** Which approach emphasizes interaction as the means and the goal of learning a language?
(A) Oral-aural (B) Communicative (C) Silent way (D) Immersion

**34.** Total number of consonant sounds in English is —
(A) 12 (B) 18 (C) 20 (D) 24

---

## Passage (Q. No. 35–39)

**Direction:** Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> Mount Vesuvius, a volcano located between the ancient Italian cities of Pompeii and Herculaneum, has received much attention because of its frequent and destructive eruptions. The most famous of these eruptions occurred in A.D. 79. The volcano had been inactive for centuries. There was little warning of the coming eruptions although one account unearthed by archaeologists says that a hard rain and a strong wind had disturbed the celestial calm during the preceding night. Early next morning, the volcano poured a huge river of molten rock down upon Herculaneum, completely burying the city and filling the harbour with coagulated lava. Meanwhile, on the other side of the mountain, cinders, stone and ash rained down on Pompeii. Sparks from the burning ash ignited the combustible rooftops quickly. Large portions of the city were destroyed in the conflagration. Fire, however, was not the only cause of destruction. Poisonous sulphuric gases saturated the air. These heavy gases were not buoyant in the atmosphere and therefore sank towards the earth and suffocated people.

**35.** What caused the rooftops to get ignited?
(A) Forest fire (B) Volcanic eruption (C) Air pollution (D) Wildfires

**36.** Which natural phenomena were witnessed on the night preceding the disaster?
(A) earthquakes (B) hail and storm (C) hard rain and strong wind (D) tsunami

**37.** What is the synonym of 'Conflagration'?
(A) Air (B) Destruction (C) Event (D) Fire

**38.** What is the antonym of 'Celestial'?
(A) Blessed (B) Earthly (C) Supernal (D) Heavenly

**39.** Which gas erupted from the volcano?
(A) Carbon Monoxide (B) Hydrogen Cyanide (C) Ozone (D) Sulphuric Gas

---

## Poem (Q. No. 40–44)

**Direction:** Read the poem given below and answer the questions that follow by selecting the most appropriate option.

> When I consider how my light is spent,
> Ere half my days, in this dark world and wide,
> And that one talent, which is death to hide,
> Lodged with me useless, though my Soul more bent
> To serve therewith my Maker, and present
> My true account, lest He, returning chide;
> "Doth God exact day-labour, light denied?"
> I fondly ask. But Patience, to prevent
> That murmur, soon replies, "God doth not need
> Either man's work, or his own gifts, who best
> Bear His mild yoke, they serve Him best; His state
> Is kingly: thousands, at His bidding speed
> And post o'er land and ocean without rest;
> They also serve who only stand and wait."

**40.** What is the poet complaining about in the first six lines?
(A) For taking away his talent (B) For taking away his life (C) For rebuking him (D) For making him blind in his youth

**41.** What does the poet realize after sometime?
(A) God needs nobody's service (B) God grants patience (C) God gives talents (D) God requires gifts

**42.** Which word is personified in the poem?
(A) Lodged (B) Light (C) Patience (D) Kingly

**43.** What is the antonym of 'chide'?
(A) Admonish (B) Praise (C) Reprimand (D) Criticize

**44.** In the poem, 'light' is perhaps a metaphor for —
(A) life (B) beauty (C) money (D) vision

---

**45.** For evaluating a poster designed as a part of a competition, which of the following criteria would be the most appropriate for the judges?
(A) Relevant content, style and word limit (B) Use of quotations, style and visual appeal (C) Creativity, relevant content and visual appeal (D) Creativity, fonts and visual approach

---

**Direction (Q. No. 46 & 47):** Substitute the following phrases with the most appropriate word from the given options.

**46.** He is a hater of knowledge and learning.
(A) Bibliophile (B) Misologist (C) Misogynist (D) Philanderer

**47.** She was listening to a sad song.
(A) Ditty (B) Knell (C) Dirge (D) Lay

**Direction (Q. No. 48):** Choose the correct form of verb to complete the sentence.

**48.** She ________ living here for two years.
(A) has (B) has been (C) have been (D) are

**Direction (Q. No. 49):** Choose the correct form of tense for the given sentence.

**49.** Can I have a drink before I ________ to bed?
(A) go (B) will have gone (C) will go (D) None of the above

**Direction (Q. No. 50):** Identify the part of speech of the underlined word.

**50.** **Wow**, you have got a great score.
(A) Conjunction (B) Pronoun (C) Adverb (D) Interjection

**Direction (Q. No. 51):** For the given statement, choose the most appropriate option in Active Voice.

**51.** He was made captain by his teammates.
(A) The teammates made the man captain.
(B) Captain was the captain for his teammates.
(C) His teammates made him their captain.
(D) He was the captain to his teammates.

**Direction (Q. No. 52):** Choose the option with the most suitable pronouns for the given sentence.

**52.** ________ bike doesn't work. Can ________ help ________ to repair ________ ?
(A) Their, they, we, them (B) Our, they, me, her (C) My, you, me, it (D) His, you, her, it

**Direction (Q. No. 53):** Select the correct conversion of the following direct sentence into indirect.

**53.** Kiran asked me, "Did you see the cricket match on television last night?"
(A) Kiran asked me whether I saw the cricket match on television the last night.
(B) Kiran asked me whether I had seen the cricket match on television the previous night.
(C) Kiran asked me did I see the cricket match on television the last night.
(D) Kiran asked me whether I have seen the cricket match on television the last night.

**Direction (Q. No. 54):** Identify the figure of speech in the following sentence.

**54.** Camel is considered the ship of the desert.
(A) Personification (B) Metaphor (C) Simile (D) Pun

**Direction (Q. No. 55):** Choose the correct option for the given sentence.

**55.** The weather is ________ .
(A) sunny (B) sunnier (C) sunnily (D) sunniest

> *टिप्पणी: Q55 ka blank wala poora sentence OCR me adhura aaya — original booklet se verify kar lena.*

**Direction (Q. No. 56 & 57):** Choose the most suitable option that describes the meaning of the underlined idiom and phrase.

**56.** When the family in the next house packed off at midnight, I began to **smell a rat**.
(A) to suspect a trick (B) to misunderstand (C) to smell a bad smell (D) to see hidden meaning

**57.** Seema is a little **hard of hearing**.
(A) inaudible (B) deaf (C) disinterested (D) insensitive

**58.** Select the incorrectly spelt word from the following —
(A) Colleague (B) Commission (C) Occurrance (D) Convenience

**Direction (Q. No. 59):** Choose the correct past continuous tense and fill in the blank.

**59.** Most of the time we ________ in the park.
(A) were sat (B) sat (C) were sitting (D) had been sitting

**60.** Scribbling means —
(A) reading carelessly (B) listening carefully (C) stammering (D) writing quickly & carelessly
