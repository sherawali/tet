# बाल विकास एवं शिक्षण विज्ञान / Child Development and Pedagogy
**UTET 2024 — Paper I, SET-D (XXIV-I) | प्रश्न 1 से 30**

---

**1.** बच्चों में भाषा का विकास एक निश्चित क्रम में होता है, वह है —
(A) बोलना, पढ़ना, सुनना, लिखना (B) सुनना, बोलना, पढ़ना, लिखना (C) सुनना, बोलना, लिखना, पढ़ना (D) बोलना, सुनना, पढ़ना, लिखना

**1.** Development of language in children occurs in a certain order, that is —
(A) Speaking, Reading, Listening, Writing (B) Listening, Speaking, Reading, Writing (C) Listening, Speaking, Writing, Reading (D) Speaking, Listening, Reading, Writing

---

**2.** "शिक्षा मनोविज्ञान शैक्षणिक विकास का क्रमिक अध्ययन है।" किसने कहा?
(A) स्टीफन (B) स्किनर (C) क्रो एवं क्रो (D) मन

**2.** "Educational Psychology is a systematic study of educational growth." Who said?
(A) Stephen (B) Skinner (C) Crow & Crow (D) Munn

---

**3.** मानसिक आयु का प्रत्यय किसने दिया था?
(A) स्टर्न (B) टर्मन (C) बिने-साइमन (D) बर्ट

**3.** Who gave the concept of Mental Age?
(A) Stern (B) Terman (C) Binet-Simon (D) Burt

---

**4.** सी.डब्ल्यू.एस.एन. (C.W.S.N.) का सम्बन्ध है —
(A) मजबूत आवश्यकता वाले बच्चों से (B) विशिष्ट आवश्यकता वाले बच्चों से (C) विशिष्ट कक्षा वाले बच्चों से (D) इनमें से कोई नहीं

**4.** C.W.S.N. is related to —
(A) Children with strong needs (B) Children with special needs (C) Children with special class (D) None of these

---

**5.** क्रोध एवं भय प्रकार हैं —
(A) अभिप्रेरणा के (B) संवेग के (C) परिकल्पना के (D) मूल प्रवृत्ति के

**5.** Anger and Fear are types of —
(A) Motivation (B) Emotion (C) Hypothesis (D) Instinct

---

**6.** व्यक्तित्व विकास में 'लिबिडो' शब्द का प्रयोग किस मनोवैज्ञानिक ने किया?
(A) फ्रायड (B) पावलव (C) मन (D) युंग

**6.** Which psychologist used the term Libido in personality development?
(A) Freud (B) Pavlov (C) Munn (D) Jung

---

**7.** "निःशुल्क एवं अनिवार्य बाल शिक्षा का अधिकार अधिनियम" संसद में कब पारित किया गया?
(A) 4 अगस्त 2010 (B) 1 अप्रैल 2010 (C) 4 अगस्त 2009 (D) 1 अप्रैल 2009

**7.** When was the 'Right of Children to Free and Compulsory Education Act' passed in the Parliament?
(A) 4th August 2010 (B) 1st April 2010 (C) 4th August 2009 (D) 1st April 2009

---

**8.** एन.ई.पी. 2020 का पूरा नाम है —
(A) न्यू एजुकेशन पॉलिसी 2020 (B) नेशनल एजुकेशन पॉलिसी 2020 (C) न्यू एजुकेशन प्रोग्राम 2020 (D) नेशनल एजुकेशन प्रोग्राम 2020

**8.** Full form of N.E.P. 2020 is —
(A) New Education Policy 2020 (B) National Education Policy 2020 (C) New Education Programme 2020 (D) National Education Programme 2020

---

**9.** आप अपनी कक्षा में परिश्रम से पढ़ाते हैं, तथा बालक भी ध्यानपूर्वक पढ़ते हैं, परन्तु कुछ बालक शीघ्रता से सीखते हैं तथा कुछ बालक धीरे। इस समस्या का कारण हो सकता है —
(A) अधिगम व्यक्तिगत होता है। (B) कुछ बालकों का स्वास्थ्य ठीक नहीं है। (C) कुछ बालकों का मन पढ़ाई में नहीं लगता है। (D) उपरोक्त सभी

**9.** You teach hard in your class and the children also study carefully, but some children learn quickly and some children slowly. This problem may be caused by —
(A) Learning is individual. (B) Health of some children is not good. (C) Some children are not interested in studies. (D) All of the above

---

**10.** सीखने का सबसे उपयुक्त अर्थ है —
(A) कौशल अर्जन (B) व्यवहार में परिवर्तन (C) वैयक्तिक समायोजन (D) ज्ञानार्जन

**10.** The most appropriate meaning of learning is —
(A) Skill acquisition (B) Change in behaviour (C) Individual adjustment (D) Acquisition of knowledge

---

**11.** 'शिक्षा एक द्विध्रुवी प्रक्रिया है।' किसने कहा?
(A) एडम्स (B) किलपैट्रिक (C) डीवी (D) गाँधी

**11.** 'Education is a bipolar process.' Who said?
(A) Adams (B) Kilpatrick (C) Dewey (D) Gandhi

---

**12.** शिक्षक द्वारा छात्रों के सही उत्तर को श्यामपट्ट पर लिखना किस प्रकार का पुनर्बलन है?
(A) धनात्मक अशाब्दिक पुनर्बलन (B) अतिरिक्त शाब्दिक पुनर्बलन (C) उपरोक्त दोनों (D) इनमें से कोई नहीं

**12.** What type of reinforcement is the teacher writing the student's correct answers on the Black-Board?
(A) Positive Nonverbal Reinforcement (B) Extra Verbal Reinforcement (C) Both of the above (D) None of these

---

**13.** विद्यार्थियों की प्रशंसा की जानी चाहिये —
(A) व्यक्तिगत (B) लोगों के बीच (C) उपरोक्त दोनों (D) इनमें से कोई नहीं

**13.** Students should be praised —
(A) Individually (B) Among people (C) Both of the above (D) None of these

---

**14.** सी.सी.ई. (C.C.E.) का पूरा नाम है —
(A) कम्प्रिहेन्सिव एण्ड कन्टिन्यूअस इवैल्यूएशन (B) कन्टिन्यूअस एण्ड कम्प्रिहेन्सिव इवैल्यूएशन (C) कन्टिन्यूअस एण्ड करीक्यूलर इवैल्यूएशन (D) कन्टिन्यूअस एण्ड कम्प्रिहेन्सिव एग्जाम

**14.** Full name of C.C.E. is —
(A) Comprehensive and Continuous Evaluation (B) Continuous and Comprehensive Evaluation (C) Continuous and Curricular Evaluation (D) Continuous and Comprehensive Exam

---

**15.** पाठ-योजना निर्माण की पंचपदीय प्रणाली किसने दी?
(A) मॉरिसन (B) हरबर्ट (C) किलपैट्रिक (D) डीवी

**15.** Who gave the five-step system of lesson plan?
(A) Morrison (B) Herbart (C) Kilpatrick (D) Dewey

---

**16.** निम्न में से कौन-सी विधि को सुकराती विधि कहा जाता है?
(A) अन्वेषण (B) समीक्षा (C) योजना (D) प्रश्नोत्तर

**16.** Which of the following methods is called the Socratic method?
(A) Investigation (B) Review (C) Planning (D) Question-Answer

---

**17.** थॉर्नडाइक द्वारा दिये गये सीखने के तीन मुख्य नियमों का सही क्रम क्या है?
(A) तत्परता, प्रभाव, अभ्यास (B) प्रभाव, अभ्यास, तत्परता (C) तत्परता, अभ्यास, प्रभाव (D) अभ्यास, प्रभाव, तत्परता

**17.** What is the right order of the three main laws of learning given by Thorndike?
(A) Readiness, Effect, Exercise (B) Effect, Exercise, Readiness (C) Readiness, Exercise, Effect (D) Exercise, Effect, Readiness

---

**18.** निम्नलिखित में से कौन वंचित बालक है?
(A) सामाजिक रूप से वंचित (B) सांस्कृतिक रूप से वंचित (C) उपरोक्त दोनों (D) इनमें से कोई नहीं

**18.** Which of the following is a deprived child?
(A) Socially deprived (B) Culturally deprived (C) Both of the above (D) None of these

---

**19.** किस बाल मनोविज्ञान विशेषज्ञ ने शैशवावस्था को सीखने का आदर्श काल कहा है?
(A) वाट्सन (B) वेलेनटाइन (C) स्किनर (D) इनमें से कोई नहीं

**19.** Which Child Psychologist has called the infancy stage the ideal period of learning?
(A) Watson (B) Valentine (C) Skinner (D) None of these

---

**20.** मैसलो के अनुसार अभिप्रेरणा से सम्बन्धित निम्न स्तर की आवश्यकता कौन-सी है?
(A) दैहिक आवश्यकता (B) संज्ञानात्मक (C) सौन्दर्य बोध (D) आत्मसिद्धि

**20.** According to Maslow, which is the lowest order of need related to motivation?
(A) Physiological Needs (B) Cognitive (C) Aesthetic (D) Self-Actualization

---

**21.** ऑपरेशन ब्लैक-बोर्ड योजना सम्बन्धित है —
(A) राष्ट्रीय शिक्षा नीति, 1952 से (B) राष्ट्रीय शिक्षा नीति, 1968 से (C) राष्ट्रीय शिक्षा नीति, 1986 से (D) राष्ट्रीय शिक्षा नीति, 2020 से

**21.** Operation Black-Board is related to —
(A) National Education Policy, 1952 (B) National Education Policy, 1968 (C) National Education Policy, 1986 (D) National Education Policy, 2020

---

**22.** मनोवैज्ञानिक ब्रिजेज के अनुसार जन्म के समय कौन-सा संवेग होता है?
(A) उत्तेजना (B) आनन्द (C) भय (D) कष्ट

**22.** Which emotion occurs at the time of birth according to Psychologist Bridges?
(A) Excitement (B) Delight (C) Fear (D) Distress

---

**23.** वैयक्तिक भिन्नता का कारण है —
(A) आनुवंशिकता का प्रभाव (B) वातावरण का प्रभाव (C) मानसिक विचारों का प्रभाव (D) उपरोक्त सभी

**23.** The cause of individual differences is —
(A) Effect of genetics (B) Effect of environment (C) Effect of mental thoughts (D) All of the above

---

**24.** मानकीकृत परीक्षण के गुण है/हैं —
(A) विश्वसनीयता (B) मानक (C) वैधता (D) ये सभी

**24.** Characteristics of a Standardized test is/are —
(A) Reliability (B) Norms (C) Validity (D) All of these

---

**25.** "व्यक्ति वंशानुक्रम एवं वातावरण की उपज है।" यह कथन किसका है?
(A) क्रो एवं क्रो (B) वुडवर्थ (C) डगलस (D) गाल्टन

**25.** "The individual is a product of heredity and environment." Whose statement is this?
(A) Crow & Crow (B) Woodworth (C) Douglas (D) Galton

---

**26.** किसने प्रयत्न एवं भूल का सिद्धान्त दिया?
(A) थॉर्नडाइक (B) रॉस (C) पावलव (D) इनमें से कोई नहीं

**26.** Who gave the theory of Trial and Error?
(A) Thorndike (B) Ross (C) Pavlov (D) None of these

---

**27.** बुद्धि लब्धि की गणना का सूत्र क्या है?
(A) मानसिक आयु / शारीरिक आयु
(B) शारीरिक आयु / मानसिक आयु
(C) (मानसिक आयु / शारीरिक आयु) × 100
(D) (शारीरिक आयु / मानसिक आयु) × 100

**27.** What is the formula of I.Q. (Intelligence Quotient)?
(A) Mental Age / Chronological Age
(B) Chronological Age / Mental Age
(C) (Mental Age / Chronological Age) × 100
(D) (Chronological Age / Mental Age) × 100

---

**28.** एफ.एल.एन. (F.L.N.) का पूरा नाम क्या है?
(A) फाउंडेशन लिटरेसी एण्ड नम्बर (B) फाउंडेशन लिटरली एण्ड न्यूमरेसी (C) फंडामेंटल लिटरेसी एण्ड नम्बर (D) फाउंडेशनल लिटरेसी एण्ड न्यूमरेसी

**28.** What is the full form of F.L.N.?
(A) Foundation Literacy and Number (B) Foundation Literally and Numeracy (C) Fundamental Literacy and Number (D) Foundational Literacy and Numeracy

---

**29.** निम्न में सही क्रम क्या है?
(A) विशेष शिक्षा, समावेशी शिक्षा, एकीकृत शिक्षा
(B) एकीकृत शिक्षा, विशेष शिक्षा, समावेशी शिक्षा
(C) विशेष शिक्षा, एकीकृत शिक्षा, समावेशी शिक्षा
(D) समावेशी शिक्षा, विशेष शिक्षा, एकीकृत शिक्षा

**29.** What is the right order in the following?
(A) Special Education, Inclusive Education, Integrated Education
(B) Integrated Education, Special Education, Inclusive Education
(C) Special Education, Integrated Education, Inclusive Education
(D) Inclusive Education, Special Education, Integrated Education

---

**30.** सामान्य बुद्धि के बालक की बुद्धि लब्धि क्या होगी?
(A) 120 – 140 (B) 110 – 120 (C) 80 – 90 (D) 90 – 110

**30.** What is the intelligence quotient of a normal child?
(A) 120 – 140 (B) 110 – 120 (C) 80 – 90 (D) 90 – 110
