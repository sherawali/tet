# गणित / Mathematics
**UTET 2024 — Paper I, SET-D (XXIV-I) | प्रश्न 91 से 120**

---

**91.** एनसीएफ 2005 की सिफारिशों के अनुसार प्राथमिक विद्यालय का गणित पाठ्यक्रम होना चाहिए —
(A) बच्चों को उच्च गणित के लिए तैयार करके (B) बच्चों के रोजमर्रा के अनुभवों से संबंधित कराकर (C) प्रक्रियात्मक ज्ञान पर ध्यान केन्द्रित करके (D) गणितीय अवधारणाओं में कठोरता प्रदान करके

**91.** As per the recommendations of NCF 2005, primary school mathematics curriculum should —
(A) prepare children for advance mathematics (B) relate to children's everyday experiences (C) focus on procedural knowledge (D) provide rigour in Mathematical concepts

---

**92.** यदि x = (−23) + 22 + (−23) + 22 …… (40 पद) और y = 11 + (−10) + 11 + (−10) …… (20 पद), तब y − x है —
(A) 40 (B) 10 (C) 20 (D) 30

**92.** If x = (−23) + 22 + (−23) + 22 …… (40 terms) and y = 11 + (−10) + 11 + (−10) …… (20 terms), then y − x is —
(A) 40 (B) 10 (C) 20 (D) 30

---

**93.** गणित में निम्नलिखित में से कौन-सा शिक्षण-अधिगम संसाधन दृष्टिबाधित छात्रों के लिए उपयोग नहीं किया जा सकता है?
(A) टाइल्स (B) जियोबोर्ड (C) जियोजेब्रा (D) टेलर का अबेकस

**93.** Which of the following teaching-learning resources in mathematics cannot be used for visually challenged students?
(A) Tiles (B) Geo Board (C) Geo Gebra (D) Taylor's Abacus

---

**94.** उस बालक को जो संख्याओं को गलत पढ़ता है, निम्नलिखित में से कौन-सी अधिगम अयोग्यता होगी?
(A) डिस्क्रेजिया (B) डिस्लेक्सिया (C) डिस्पेप्सिया (D) डिस्कैल्कुलिया

**94.** The child who reads numbers wrongly has which of the following learning disabilities?
(A) Dyscrasia (B) Dyslexia (C) Dyspepsia (D) Dyscalculia

---

**95.** 10.25 बजे घड़ी की सुइयों के बीच प्रतिवर्ती कोण (बृहत् कोण) होगा —
(A) 197½° (B) 180° (C) 210° (D) 192½°

**95.** The reflex angle between the hands of a clock at 10.25 will be —
(A) 197½° (B) 180° (C) 210° (D) 192½°

---

**96.** यदि किसी त्रिभुज का एक कोण 130° हो, तो अन्य दो कोणों के अर्धकों के बीच का कोण कितना है?
(A) 155° (B) 65° (C) 115° (D) 130°

**96.** If one angle of a triangle is 130°, then the angle between the bisectors of the other two angles is —
(A) 155° (B) 65° (C) 115° (D) 130°

---

**97.** यदि  37/13 = 2 + 1/(a + 1/(b + 1/c)),  जहाँ a, b, c प्राकृतिक संख्यायें हैं, तब a, b और c का मान क्रमशः है —
(A) 1, 5, 3 (B) 1, 3, 5 (C) 1, 5, 2 (D) 1, 2, 5

**97.** If 37/13 = 2 + 1/(a + 1/(b + 1/c)), where a, b, c are natural numbers, then the values of a, b and c respectively are —
(A) 1, 5, 3 (B) 1, 3, 5 (C) 1, 5, 2 (D) 1, 2, 5

---

**98.** 216 मी³ आयतन वाले एक घनाभ में 6 सेमी भुजा वाले कितने घन फिट किए जा सकते हैं?
(A) 10⁶ (B) 10⁴ (C) 10³ (D) 10⁵

**98.** How many cubes of side 6 cm can be fitted into a cuboid of volume 216 m³?
(A) 10⁶ (B) 10⁴ (C) 10³ (D) 10⁵

---

**99.** निम्नलिखित में से कौन-सा गणित में अर्थपूर्ण सीखने का सिद्धांत नहीं है?
(A) उपयोगिता का सिद्धांत (B) रटकर सीखने का सिद्धांत (C) अभ्यास का सिद्धांत (D) मानसिक शक्तियों के उचित उपयोग का सिद्धांत

**99.** Which of the following is not the principle of meaningful learning in Mathematics?
(A) Principle of Utility (B) Principle of Rote learning (C) Principle of Exercise (D) Principle of proper use of mental powers

---

**100.** जुड़वाँ अभाज्य संख्याएँ हैं —
(A) 15, 17 (B) 41, 43 (C) 31, 33 (D) 31, 41

**100.** Twin prime numbers are —
(A) 15, 17 (B) 41, 43 (C) 31, 33 (D) 31, 41

---

**101.** नई स्थिति में पिछली सीखी गई सामग्री का उपयोग करना क्या कहलाता है?
(A) समझ (B) अनुप्रयोग (C) ज्ञान (D) विश्लेषण

**101.** To use previously learned material in a new situation is called —
(A) Comprehension (B) Application (C) Knowledge (D) Analysis

---

**102.** निम्न में से कौन 5⁷¹ + 5⁷² + 5⁷³ को पूर्णतः विभाजित कर देगा?
(A) 150 (B) 155 (C) 160 (D) 30

**102.** Which one of the following will completely divide 5⁷¹ + 5⁷² + 5⁷³ ?
(A) 150 (B) 155 (C) 160 (D) 30

---

**103.** यदि x = (−1)¹ + (−1)² + …… + (−1)²⁰⁰⁹ एवं y = (−1)¹ − (−1)² + (−1)³ − (−1)⁴ + …… + (−1)²⁰⁰⁹, तब x − y का मान ज्ञात कीजिए —
(A) 2009 (B) 2008 (C) 0 (D) 1004

**103.** If x = (−1)¹ + (−1)² + …… + (−1)²⁰⁰⁹ and y = (−1)¹ − (−1)² + (−1)³ − (−1)⁴ + …… + (−1)²⁰⁰⁹, then find x − y —
(A) 2009 (B) 2008 (C) 0 (D) 1004

---

**104.** एक तार को कुछ छोटे टुकड़ों में काटा गया है। प्रत्येक छोटे टुकड़े को 3 सेमी भुजा वाले वर्ग के रूप में मोड़ा गया। यदि सभी छोटे वर्गों का कुल क्षेत्रफल 108 वर्ग सेमी हो, तब तार की वास्तविक लम्बाई ज्ञात कीजिए —
(A) 108 सेमी (B) 144 सेमी (C) 136 सेमी (D) 138 सेमी

**104.** A wire is cut into several small pieces. Each of the small pieces is bent into a square of side 3 cm. If the total area of the small squares is 108 cm², then find the original length of the wire —
(A) 108 cm (B) 144 cm (C) 136 cm (D) 138 cm

---

**105.** माउण्ट एवरेस्ट 8850 मीटर की ऊँचाई पर है। इसका आधार 5400 मीटर की ऊँचाई पर है। यहाँ तापमान 1 डिग्री प्रति 100 मीटर की दर से गिरता है। यदि आधार का तापमान −5°C है, तो शीर्ष का तापमान क्या है?
(A) −5°C (B) 34.5°C (C) −34.5°C (D) −39.5°C

**105.** Mt. Everest is at a height of 8850 metres. Its base is at an elevation of 5400 metres. The temperature here drops at the rate of 1 degree per 100 metres. If the temperature at the base is −5°C, what is the temperature at the top?
(A) −5°C (B) 34.5°C (C) −34.5°C (D) −39.5°C

---

**106.** 20 लोगों की एक पार्टी एक रेस्तरां में गई और उन्होंने प्रत्येक के लिए ₹36.60 का भोजन ऑर्डर किया, लेकिन उनमें से 5 लोग पैसे लाना भूल गए थे। बिल चुकाने के लिए बाकी 15 लोगों को और कितना अधिक भुगतान करना पड़ा?
(A) ₹12.20 (B) ₹15.20 (C) ₹24.40 (D) ₹20.40

**106.** A party of 20 people went to a restaurant. They ordered a meal of ₹36.60 each, but 5 of them had forgotten to bring money. In order to settle the bill, how much more did the other 15 people have to pay?
(A) ₹12.20 (B) ₹15.20 (C) ₹24.40 (D) ₹20.40

---

**107.** 1948 को रोमन अंकों में लिखिए —
(A) MCMXVIII (B) MCMXLVIII (C) MCMXXLVIII (D) MXLVIII

**107.** Write 1948 in Roman Numerals —
(A) MCMXVIII (B) MCMXLVIII (C) MCMXXLVIII (D) MXLVIII

---

**108.** गणित के शिक्षण में मूल्यांकन किया जाना चाहिए —
(A) सीखने के अनुभव प्रदान करने के समय (B) उद्देश्यों के स्पष्टीकरण के समय (C) उद्देश्यों के स्पष्टीकरण एवं सीखने के अनुभव प्रदान करने के पश्चात् (D) इनमें से कोई नहीं

**108.** Evaluation should be done in teaching of Mathematics —
(A) at the time of providing experiences of learning (B) at the time of clarification of objectives (C) after the clarification of objectives and providing the experiences of learning (D) None of these

---

**109.** एक समअष्टभुज में समरूपता (सममिति) की कितनी रेखाएँ हैं?
(A) 0 (B) 1 (C) 2 (D) 8

**109.** How many line(s) of symmetry does a regular octagon have?
(A) 0 (B) 1 (C) 2 (D) 8

---

**110.** 1⅓ ÷ 1½ ÷ 1⅑ में वह छोटी से छोटी भिन्न क्या जोड़ें, जिससे परिणाम पूर्णांक बन जाए?
(A) 4/5 (B) 3/5 (C) 2/5 (D) 1/5

**110.** What is the least fraction that must be added to 1⅓ ÷ 1½ ÷ 1⅑ to make the result an integer?
(A) 4/5 (B) 3/5 (C) 2/5 (D) 1/5

---

**111.** दो वर्गों की भुजाएँ क्रमशः x सेमी तथा (2x + 1) सेमी हैं। उनके परिमापों का योगफल 100 सेमी है। उनमें से बड़े वर्ग का क्षेत्रफल (वर्ग सेमी में) है —
(A) 64 (B) 81 (C) 225 (D) 289

**111.** Two squares have sides x cm and (2x + 1) cm respectively. The sum of their perimeters is 100 cm. Area (in cm²) of the bigger square is —
(A) 64 (B) 81 (C) 225 (D) 289

---

**112.** दी गई श्रृंखला में बॉक्स में क्या आएगा?
79, 87, [ ], 89, 83, 91
(A) 82 (B) 81 (C) 48 (D) 62

**112.** What will come in the box in the given series?
79, 87, [ ], 89, 83, 91
(A) 82 (B) 81 (C) 48 (D) 62

---

**113.** यदि a³ = 1 + 7, 3³ = 1 + 7 + b, 4³ = 1 + 7 + c, तब a + b + c का मान है —
(A) 58 (B) 75 (C) 77 (D) 110

**113.** If a³ = 1 + 7, 3³ = 1 + 7 + b, 4³ = 1 + 7 + c, then the value of a + b + c is —
(A) 58 (B) 75 (C) 77 (D) 110

---

**114.** निदान का कार्य है —
(A) वर्गीकरण (B) सीखने की कमजोरी पहचानना (C) व्युत्पत्ति फलन (D) उपरोक्त सभी

**114.** The function of diagnosis is —
(A) Classification (B) Identify learning weakness (C) Etymology function (D) All of the above

---

**115.** गणित में गणना कौशल को बढ़ाया जा सकता है —
(A) केवल वैचारिक ज्ञान देकर (B) केवल एल्गोरिथ्म का वर्णन करके (C) कक्षा में हाथों की गतिविधियों को करके (D) बहुत सारे अभ्यासों के बाद संप्रत्ययों और प्रक्रियाओं को स्पष्ट करके

**115.** Computational skills in Mathematics can be enhanced by —
(A) giving conceptual knowledge alone (B) describing algorithm only (C) conducting hands-on activities in class (D) clarifying concepts and procedures followed by lots of practice

---

**116.** 10 संख्याओं का माध्य 0 है। यदि इन संख्याओं में 12 और −12 को शामिल कर लिया जाए, तो नया माध्य क्या होगा?
(A) 6 (B) 60 (C) 0 (D) 5

**116.** The mean of 10 numbers is 0. If 12 and −12 are included in these numbers, the new mean will be —
(A) 6 (B) 60 (C) 0 (D) 5

---

**117.** प्राथमिक स्तर पर 'संख्याएँ' पढ़ाने के संबंध में निम्नलिखित में से कौन-से कथन सत्य हैं?
(i) संख्याओं की सहज समझ को प्रोत्साहित किया जाना चाहिए।
(ii) संख्याओं को क्रम से लिखना सिखाया जाना चाहिए।
(iii) संख्याओं को अंक के रूप में लिखना गिनती से पहले होना चाहिए।
(iv) संख्याओं की क्रम अप्रासंगिकता को प्रोत्साहित किया जाना चाहिए।
(A) (i) और (iv) (B) (iii) और (iv) (C) (i) और (ii) (D) (ii) और (iii)

**117.** Which of the following statements are true regarding teaching 'Numbers' at primary level?
(i) Intuitive understanding of numbers should be encouraged.
(ii) Writing numbers should be taught in sequence.
(iii) Writing of numbers as numerals should be before counting.
(iv) Order irrelevance of numbers should be encouraged.
(A) (i) and (iv) (B) (iii) and (iv) (C) (i) and (ii) (D) (ii) and (iii)

---

## पाई-चार्ट (प्रश्न 118–120)

**निर्देश:** नीचे दिए गए पाई-चार्ट में किसी कृषि फार्म में चावल, गेहूँ, दाल व सब्जी के कुल उत्पादन का तुलनात्मक अध्ययन किया गया है।

**Direction:** In the pie-chart given below, the comparative study of the total production of rice, wheat, pulses and vegetables in an agricultural farm is given.

| मद / Item | प्रतिशत / Percentage |
|---|---|
| चावल / Rice | 40% |
| गेहूँ / Wheat | 30% |
| सब्जी / Vegetables | 20% |
| दाल / Pulses | 10% |

**118.** गेहूँ के उत्पादन के लिए केन्द्रीय कोण है —
(A) 30° (B) 60° (C) 108° (D) 120°

**118.** The central angle for wheat production is —
(A) 30° (B) 60° (C) 108° (D) 120°

---

**119.** उपर्युक्त पाई-चार्ट के अनुसार सब्जी और दाल के उत्पादन का अनुपात है —
(A) 7 : 3 (B) 3 : 4 (C) 1 : 2 (D) 2 : 1

**119.** According to the above pie-chart, the ratio of the production of vegetables and pulses is —
(A) 7 : 3 (B) 3 : 4 (C) 1 : 2 (D) 2 : 1

---

**120.** यदि कृषि फार्म में चावल, गेहूँ, दाल व सब्जी का कुल उत्पादन 50,000 किग्रा है, तो चावल का उत्पादन है —
(A) 40,000 किग्रा (B) 2,000 किग्रा (C) 15,000 किग्रा (D) 20,000 किग्रा

**120.** If the total production of rice, wheat, pulses and vegetables in the agricultural farm is 50,000 kg, then production of rice is —
(A) 40,000 kg (B) 2,000 kg (C) 15,000 kg (D) 20,000 kg
