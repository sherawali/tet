# UTET 2024 — Paper I (प्रथम / FIRST)

| विवरण | Detail |
|---|---|
| परीक्षा | UTET (Uttarakhand Teacher Eligibility Test) |
| वर्ष / Year | 2024 |
| प्रश्नपत्र | प्रथम / Paper I (कक्षा 1–5) |
| Booklet Code | XXIV-I |
| SET | D |
| समय / Time | 2 घण्टे 30 मिनट / 2 hours 30 mins |
| पूर्णांक / Max. Marks | 150 |
| कुल प्रश्न | 150 (प्रत्येक 1 अंक) |
| स्रोत / Source | ukutet.com — आधिकारिक प्रश्न-पुस्तिका PDF |

## प्रश्नपत्र की संरचना / Structure

| प्रश्न संख्या | विषय | Subject |
|---|---|---|
| 1 – 30 | बाल विकास एवं शिक्षण विज्ञान | Child Development and Pedagogy |
| 31 – 60 | भाषा प्रथम — हिन्दी **अथवा** अंग्रेजी | First Language — Hindi OR English |
| 61 – 90 | भाषा द्वितीय — हिन्दी / अंग्रेजी / संस्कृत / उर्दू | Second Language |
| 91 – 120 | गणित | Mathematics |
| 121 – 150 | पर्यावरण अध्ययन | Environmental Studies |

## फाइलें

- `01-child-development-pedagogy.md` — Q 1–30
- `02-language-1-hindi.md` — Q 31–60
- `03-language-1-english.md` — Q 31–60
- `04-language-2-hindi.md` — Q 61–90
- `05-language-2-english.md` — Q 61–90
- `06-language-2-sanskrit.md` — Q 61–90
- `07-mathematics.md` — Q 91–120
- `08-environmental-studies.md` — Q 121–150

*उर्दू खण्ड शामिल नहीं किया गया है।*
