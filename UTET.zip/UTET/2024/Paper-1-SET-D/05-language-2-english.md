# Second Language — English
**UTET 2024 — Paper I, SET-D (XXIV-I) | Questions 61 to 90**

---

**Direction (Q. No. 61 & 62):** Choose the correct preposition.

**61.** She was punished ________ stealing a saree.
(A) for (B) by (C) with (D) from

**62.** In the month of December the temperature falls ________ 4°C.
(A) from (B) below (C) at (D) into

---

**63.** Bulletin boards and flannel boards are means of —
(A) Video aids (B) Audio aids (C) Audio-Video aids (D) None of these

**64.** Which of the following is the most important pre-requisite for language learning, whether first or second?
(A) A structural-situational approach (B) Skills-based instruction (C) A multi-lingual approach (D) An input-rich communicational environment

---

**Direction (Q. No. 65 & 66):** Choose the best alternative to complete the sentences given below.

**65.** Please tell me ________
(A) where is the bus stop. (B) where the bus stop be. (C) where stops the bus. (D) where the bus stop is.

**66.** I think ________
(A) today it is Wednesday. (B) that is today Wednesday. (C) today is Wednesday. (D) today be Wednesday.

**Direction (Q. No. 67 & 68):** Fill in the blanks with suitable verbs.

**67.** Either the mother or the daughter ________ made this pudding.
(A) have (B) has (C) was (D) were

**68.** One third of the work ________ left incomplete.
(A) would (B) was (C) were (D) None of these

**Direction (Q. No. 69 & 70):** Choose the right word which best expresses the meaning of the given idiom/phrase.

**69.** Merry as a cricket
(A) To enjoy a game of cricket (B) To be carefree (C) To dance and sing (D) To be good at sport

**70.** Which word is not the synonym of 'Distress'?
(A) Contentment (B) Affliction (C) Grief (D) Misery

---

## Passage (Q. No. 71–75)

**Direction:** Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> To avoid the various foolish opinions to which mankind is prone, no superhuman brain is required. A few simple rules keep you free, not from all errors, but from silly errors. If the matter is one that can be settled by observation, make the observation yourself. Aristotle could have avoided the mistake of thinking that women have fewer teeth than men, by the simple device of asking Mrs. Aristotle to keep her mouth open while he counted. He did not do so because he thought he knew. Thinking that you know, when in fact you do not, is a fatal mistake to which we are all prone. I believe myself that hedgehogs eat black beetles, because I have been told that they do; but if I was writing a book on the habits of hedgehogs, I should not commit myself until I had seen one enjoying this diet. Aristotle, however, was less cautious. Ancient and medieval writers knew all about unicorns and salamanders; not one of them thought it necessary to avoid dogmatic statements about them because he had never seen one of them.

**71.** The author portrays mankind as —
(A) very intelligent (B) having superhuman qualities (C) nervous and weak (D) by and large ignorant

**72.** The author is in favour of drawing conclusions on the basis of —
(A) reasoning (B) study of eminent thinkers (C) empirical evidence (D) discussion and consultation

**73.** According to the author, unicorns and salamanders —
(A) existed in the past but now have become extinct (B) are invisible (C) never really existed (D) have caused strange stories to be written about them

**74.** The author implies that —
(A) hedgehogs eat black beetles (B) hedgehogs do not really eat black beetles (C) he is writing a book about hedgehogs (D) he has never seen a hedgehog eating beetles

**75.** The attitude of the author is —
(A) Philosophical (B) Cultural (C) Scientific (D) Commercial

---

**Direction (Q. No. 76):** Choose the correct conjunction.

**76.** A student will fail ________ he does not work hard.
(A) because (B) if (C) unless (D) until

**77.** Fill in the blank by correct adjective: This man is ________ enough to play the fool.
(A) the wise (B) wise (C) wiser (D) wisest

**78.** A test of listening comprehension is a test of —
(A) receptive skill (B) productive skill (C) hearing ability (D) phonology

**79.** Teaching of prose includes —
(A) Story (B) Biography (C) Essay (D) All of the above

**80.** One of the following is not a kind of reading —
(A) Loud reading (B) Silent reading (C) Descriptive reading (D) Supplementary reading

**81.** Lexical meaning of a word is —
(A) as one governed by intonation (B) as one governed by culture (C) as one given in a dictionary (D) as one made out from context

**Direction (Q. No. 82 & 83):** Fill in the blanks with the correct answer.

**82.** When I reached the station I found Radha ________ .
(A) waits (B) to wait (C) waited (D) waiting

**83.** You had better ________ nothing.
(A) to say (B) saying (C) say (D) said

**Direction (Q. No. 84 & 85):** Change the following sentences into passive voice.

**84.** Post this letter.
(A) This letter should be posted. (B) This letter must be posted. (C) Let this letter be posted. (D) None of the above

**85.** This bottle contains milk.
(A) Milk is contained in this bottle. (B) Milk is contained by the bottle. (C) Both (A) and (B) (D) None of these

---

## Passage (Q. No. 86–90)

**Direction:** Read the following passage and answer the questions that follow by selecting the most appropriate option.

> On the morning of August 31, 1573, 3000 horsemen of the imperial Mughal army paused at the bank of the Sabarmati. The rebels, they were after, lay just beyond the swollen river but the soldiers were exhausted: they had travelled 960 kilometers of difficult terrain in nine days, riding almost continuously. Suddenly a warrior on a chestnut charger plunged into the raging torrent. As man and horse struggled on to the opposite bank, a thrill ran through the army. It was the emperor, Jalaluddin Akbar! With a roar, the soldiers followed him across and within two days, they had put down the rebellion so thoroughly that Gujarat remained in Mughal hands for the next 185 years.

**86.** The rebels were camped —
(A) Across the Sabarmati river (B) At a fort near Sabarmati (C) In Gujarat (D) In imperial Mughal Courts

**87.** The expression "swollen river" means —
(A) a river in flood (B) a calm and serene river (C) a deep river (D) a shallow river

**88.** The Mughal soldiers didn't cross the river because —
(A) They were cowards (B) They had joined hands with the rebels (C) They were waiting for the king to arrive (D) They were tired after a difficult journey

**89.** The sudden arrival of king Akbar —
(A) Surprised the soldiers (B) Angered the soldiers (C) Dismayed the soldiers (D) Enthused the soldiers

**90.** The attack on the rebels turned out to be —
(A) a dismal failure (B) a grand success (C) of no particular significance (D) an ordinary affair
