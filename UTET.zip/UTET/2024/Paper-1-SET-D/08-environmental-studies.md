# पर्यावरण अध्ययन / Environmental Studies
**UTET 2024 — Paper I, SET-D (XXIV-I) | प्रश्न 121 से 150**

---

**121.** 'ब्लू बेबी सिंड्रोम' जल में किस लवण की उपस्थिति के कारण होता है?
(A) कार्बोनेट (B) नाइट्रेट (C) क्लोराइड (D) सल्फेट

**121.** 'Blue baby syndrome' is caused by the presence of which salt in water?
(A) Carbonate (B) Nitrate (C) Chloride (D) Sulphate

---

**122.** एग्रोस्टोलॉजी अध्ययन है —
(A) पौधे का (B) कृषि का (C) शैवाल का (D) घास का

**122.** Agrostology is the study of —
(A) Plants (B) Agriculture (C) Algae (D) Grasses

---

**123.** "हरियाली देवी" पवित्र उपवन उत्तराखण्ड के निम्नलिखित में से किस जनपद में स्थित है?
(A) रुद्रप्रयाग (B) चमोली (C) पौड़ी गढ़वाल (D) टिहरी गढ़वाल

**123.** 'Hariyali Devi' Sacred Grove is located in which of the following districts of Uttarakhand?
(A) Rudraprayag (B) Chamoli (C) Pauri Garhwal (D) Tehri Garhwal

---

**124.** भारत के किस राज्य में मानसून का आगमन सबसे पहले होता है?
(A) पश्चिम बंगाल (B) असम (C) केरल (D) महाराष्ट्र

**124.** In which state of India does the monsoon arrive first?
(A) West Bengal (B) Assam (C) Kerala (D) Maharashtra

---

**125.** 2002 में सतत विकास पर विश्व शिखर सम्मेलन कहाँ आयोजित किया गया था?
(A) जोहान्सबर्ग (B) जेनेवा (C) शंघाई (D) न्यूयॉर्क

**125.** Where was the World Summit on Sustainable Development held in 2002?
(A) Johannesburg (B) Geneva (C) Shanghai (D) New York

---

**126.** टी.एल.एम./शिक्षण अधिगम सामग्रियाँ पर्यावरण अध्ययन के शिक्षण को सुदृढ़ करती हैं —
(A) बोले गये शब्दों का पूरक बनकर (B) गृहकार्य आसान बनाकर (C) शिक्षक की गतिविधि को कम करके (D) उपर्युक्त में से कोई नहीं

**126.** TLM/Teaching learning materials reinforce the teaching of environmental studies —
(A) by complementing the spoken words (B) by making homework easier (C) by reducing the activity of the teacher (D) None of the above

---

**127.** ओजोन के विघटन में कौन-सा तत्व उत्प्रेरक के रूप में कार्य करता है?
(A) ऑक्सीजन (B) क्लोरीन (C) फ्लोरीन (D) पोटैशियम

**127.** Which element acts as a catalyst in the decomposition of ozone?
(A) Oxygen (B) Chlorine (C) Fluorine (D) Potassium

---

**128.** प्रयोग करना, खोज करना, जाँच करना और प्रश्न पूछना ई.वी.एस. के सक्रिय शिक्षण के आवश्यक तत्त्व हैं। एक शिक्षक "हमें क्या खाना चाहिए" की अवधारणा से सम्बन्धित निम्नलिखित में से कौन-सी गतिविधि आयोजित करता है?
(A) ऐसे सभी खाद्य पदार्थों के चित्र ब्लैकबोर्ड पर बनाये।
(B) विभिन्न खाद्य पदार्थों के उदाहरण दे तथा प्रत्येक खाद्य पदार्थ के आवश्यक घटकों का उल्लेख करे।
(C) विद्यार्थियों से सभी संभावित स्रोतों से सम्बन्धित जानकारी एकत्र करने को कहे।
(D) इस विषय पर एक वीडियो दिखाये।

**128.** Experimenting, exploring, investigating and questioning constitute essential elements of active learning of EVS. A teacher arranges which one of the following activities related to the concept of 'food we should eat'?
(A) Draw diagrams of all such foods on the blackboard.
(B) Give examples of different foods with essential components of each food.
(C) Ask students to collect related information from all possible sources.
(D) Show a video on this topic.

---

**129.** विश्व में सबसे तेजी से घटने वाला प्राकृतिक संसाधन है —
(A) पानी (B) वन (C) हवा (D) सूरज की रोशनी

**129.** The fastest depleting natural resource in the world is —
(A) Water (B) Forest (C) Air (D) Sunlight

---

**130.** जैव-विविधता हॉट-स्पॉट अवधारणा निम्नलिखित में से किस वर्ष प्रस्तुत की गई थी?
(A) 1980 (B) 1984 (C) 1988 (D) 1994

**130.** The Hot-spot concept of Biodiversity was introduced in which of the following years?
(A) 1980 (B) 1984 (C) 1988 (D) 1994

---

**131.** विश्व प्रसिद्ध रिपोर्ट "विकास की सीमाएँ" (Limits to Growth), जिसमें अनियंत्रित विकास के कारण विनाश की घोषणा की गई, किसके द्वारा लिखी गई?
(A) मैयर्स और सहयोगी (B) मीडोस और सहयोगी (C) ब्रुंटलैंड (D) विल्सन और सहयोगी

**131.** The world famous report 'Limits to Growth', which declared devastation due to uncontrolled growth, was written by whom?
(A) Myers and associates (B) Meadows and associates (C) Brundtland (D) Wilson and associates

---

**132.** किस राज्य ने संयुक्त वन प्रबंधन के लिए पहला प्रस्ताव पारित किया?
(A) मध्य प्रदेश (B) कर्नाटक (C) हिमाचल प्रदेश (D) उड़ीसा

**132.** Which state passed the first resolution for joint forest management?
(A) Madhya Pradesh (B) Karnataka (C) Himachal Pradesh (D) Odisha

---

**133.** चन्दन वन किस तरह के वन के उदाहरण हैं?
(A) डेल्टाई वन (B) कांटेदार वन (C) सदाबहार वन / मैंग्रोव वन (D) पर्णपाती वन

**133.** Sandalwood forests are examples of which type of forest?
(A) Deltaic forest (B) Thorny forest (C) Mangrove forest (D) Deciduous forest

---

**134.** तेल-रिसाव के बारे में निम्नलिखित में से कौन-सा कथन सत्य है?
(1) तेल रिसाव से जैविक ऑक्सीजन की माँग बढ़ जाती है।
(2) तेल रिसाव से समुद्री जल में ऑक्सीजन की मात्रा कम हो जाती है।
(A) केवल (1) (B) केवल (2) (C) (1) और (2) दोनों (D) उपरोक्त में से कोई नहीं

**134.** Which of the following is true about oil spills?
(1) Oil spills increase the biological oxygen demand.
(2) Oil spills reduce the oxygen in the sea water.
(A) Only (1) (B) Only (2) (C) Both (1) and (2) (D) None of the above

---

**135.** निम्नलिखित सामाजिक-पारिस्थितिक आंदोलनों को सही कालानुक्रमिक क्रम में व्यवस्थित करें —
(i) आरे आंदोलन, मुम्बई (ii) चिपको आंदोलन (iii) नर्मदा बचाओ आंदोलन (iv) जंगल बचाओ आंदोलन
(A) i, ii, iii, iv (B) ii, iv, iii, i (C) ii, iii, iv, i (D) iii, iv, ii, i

**135.** Arrange the following social-ecological movements in correct chronological order —
(i) Aarey Movement, Mumbai (ii) Chipko Movement (iii) Narmada Bachao Movement (iv) Jungle Bachao Movement
(A) i, ii, iii, iv (B) ii, iv, iii, i (C) ii, iii, iv, i (D) iii, iv, ii, i

---

**136.** गोबर के अतिरिक्त वह अपतृण (खरपतवार) जो बायो-गैस उत्पादन में प्रयुक्त हो सकती है —
(A) हाइड्रिला (B) मकोय (सोलेनम नाइग्रम) (C) जलकुम्भी (D) गाजर घास

**136.** Apart from cow dung, the weed that can be used in biogas production is —
(A) Hydrilla (B) Makoi (Solanum nigrum) (C) Eichhornia (D) Parthenium

---

**137.** 'ग्रेट हिमालयन नेशनल पार्क' किस राज्य में स्थित है?
(A) उत्तराखण्ड (B) जम्मू और कश्मीर (C) सिक्किम (D) हिमाचल प्रदेश

**137.** 'Great Himalayan National Park' is located in which of the following states?
(A) Uttarakhand (B) Jammu and Kashmir (C) Sikkim (D) Himachal Pradesh

---

**138.** गंगा ऐक्शन प्लान किस प्रधानमंत्री के कार्यकाल में शुरू किया गया था?
(A) मोरारजी देसाई (B) राजीव गांधी (C) अटल बिहारी वाजपेयी (D) पी.वी. नरसिम्हा राव

**138.** Ganga Action Plan was started during the tenure of which Prime Minister?
(A) Morarji Desai (B) Rajiv Gandhi (C) Atal Bihari Vajpayee (D) P. V. Narasimha Rao

---

**139.** कवितायें एवं कहानियाँ पर्यावरण अध्ययन के विषय को प्रभावी ढंग से प्रस्तुत करती हैं। ऐसा इसलिए है, क्योंकि कवितायें और कहानियाँ —
(i) प्रासंगिक शिक्षण वातावरण प्रदान कर सकती हैं।
(ii) रचनात्मकता और सौन्दर्यबोध को पोषित कर सकती हैं।
(iii) बच्चे के परिवेश का समृद्ध चित्रण कर सकती हैं।
(iv) विभिन्न अवधारणाओं को समझा सकती हैं।
(A) केवल (i), (ii) एवं (iii) (B) केवल (iv) (C) केवल (iii) एवं (iv) (D) केवल (i)

**139.** Poems and stories are effective in transacting the theme of EVS. This is because poems and stories —
(i) can provide the contextual learning environment.
(ii) can nurture creativity and aesthetic sense.
(iii) can be rich depictions of the child's environment.
(iv) can explain various concepts.
(A) Only (i), (ii) and (iii) (B) Only (iv) (C) Only (iii) and (iv) (D) Only (i)

---

**140.** सिंचाई प्रणाली में उर्वरकों, मृदा सुधारकों और अन्य जल में घुलनशील उत्पादों को डालने के लिए शब्द प्रयोग किया जाता है —
(A) उर्वरक (B) फर्टिगेशन (C) ड्रिप सिंचाई (D) पर्णीपोषण (पत्तियों पर खाद डालना)

**140.** The term used for the application of fertilizers, soil improvers and other water-soluble products into an irrigation system is —
(A) Fertilizer (B) Fertigation (C) Drip irrigation (D) Foliar feeding

---

**141.** निम्नलिखित में से कौन-सा सजीव और निर्जीव घटक के बीच परस्पर क्रिया का उदाहरण है?
(A) खाद्य श्रृंखला (B) खाद्य जाल (C) शिकार करना (D) जल चक्र

**141.** Which of the following is an example of interaction between living and nonliving components?
(A) Food chain (B) Food web (C) Hunting (D) Water cycle

---

**142.** काई (शैवाल) की अत्यधिक वृद्धि व पोषक तत्वों से समृद्ध झील को कहते हैं —
(A) यूट्रोफिक (B) ओलिगोट्रोफिक (C) डायस्ट्रोफिक (D) मिरोमिक्टिक

**142.** The lake having excessive growth of algae and richness in nutrients is called —
(A) Eutrophic (B) Oligotrophic (C) Dystrophic (D) Meromictic

---

**143.** भारत सरकार ने जल (प्रदूषण निवारण एवं नियंत्रण) अधिनियम पारित किया —
(A) 1999 में (B) 1974 में (C) 1996 में (D) 1975 में

**143.** The Government of India passed the Water (Prevention and Control of Pollution) Act in —
(A) 1999 (B) 1974 (C) 1996 (D) 1975

---

**144.** समुदाय के बारे में निम्नलिखित में से कौन-से कथन सही हैं?
(1) समुदाय स्थिर या कठोर होता है।
(2) समुदाय बड़े या छोटे हो सकते हैं।
(3) अधिकांश मामलों में समुदायों का नाम प्रमुख पौधों की प्रजातियों के नाम पर रखा जाता है।
(A) केवल (1) और (2) (B) केवल (2) और (3) (C) केवल (1) और (3) (D) (1), (2) और (3)

**144.** Which of the following statements are correct regarding community?
(1) A community is fixed or rigid.
(2) Communities may be large or small.
(3) Communities in most instances are named after the dominant plant species.
(A) Only (1) and (2) (B) Only (2) and (3) (C) Only (1) and (3) (D) (1), (2) and (3)

---

**145.** वायु (प्रदूषण निवारण एवं नियंत्रण) अधिनियम, 1981 के किस अनुच्छेद (धारा) के तहत राज्य बोर्ड किसी भी क्षेत्र को 'वायु प्रदूषण नियन्त्रण क्षेत्र' घोषित कर सकता है?
(A) धारा 19 (B) धारा 20 (C) धारा 21 (D) धारा 22

**145.** Under which Section of the Air (Prevention and Control of Pollution) Act, 1981, can the state board declare any area as an 'Air Pollution Control Area'?
(A) Section 19 (B) Section 20 (C) Section 21 (D) Section 22

---

**146.** यदि हम पक्षियों का अवलोकन करें तो पायेंगे कि अधिकांश पक्षी अक्सर अपनी गर्दन हिलाते रहते हैं। ऐसा इसलिए होता है, क्योंकि —
(A) अधिकांश पक्षियों की आँखें स्थिर होती हैं और हिल नहीं सकतीं।
(B) उनके कान ढके होते हैं और वे उड़ सकते हैं।
(C) पक्षियों की दो आँखें होती हैं।
(D) उनकी आँखें एक समय में दो अलग-अलग वस्तुओं पर ध्यान केन्द्रित कर सकती हैं।

**146.** If we observe birds, we find that most of the birds often move their neck. This happens because —
(A) in most of the birds, the eyes are fixed and cannot move.
(B) their ears are covered and they can fly.
(C) the birds have two eyes.
(D) their eyes can focus on two different objects at a time.

---

**147.** तरुण भारत संघ के राजेन्द्र सिंह को किस कार्य के लिए मैग्सेसे पुरस्कार दिया गया?
(A) जल संरक्षण (B) सामुदायिक वानिकी (C) साफ व स्वच्छ तकनीकी (D) सौर ऊर्जा

**147.** For which work was Rajendra Singh of Tarun Bharat Sangh given the Magsaysay Award?
(A) Water conservation (B) Community forestry (C) Clean and neat technology (D) Solar energy

---

**148.** एन.सी.ई.आर.टी. की ई.वी.एस. की पाठ्यपुस्तकों में निम्नलिखित में से किसको उच्च प्राथमिकता और स्थान दिया गया है?
(A) विषय में रुचि विकसित करना।
(B) दिनचर्या और नीरस विषय-वस्तु में बदलाव लाना।
(C) शिक्षार्थियों को मनोरंजन और आनन्द प्रदान करना।
(D) शिक्षार्थियों में कल्पनाशील और सृजनात्मक क्षमता को बढ़ावा देना।

**148.** Which of the following has been given high priority and space in NCERT's EVS textbooks?
(A) To develop interest in the subject.
(B) To have a change in routine and monotonous content.
(C) To provide fun and enjoyment for learners.
(D) To promote imaginative and creative ability in learners.

---

**149.** एन.सी.एफ. 2005 के अनुसार निम्नलिखित में से कौन-सा ई.वी.एस. (पर्यावरण अध्ययन) का विषय (theme) है?
(A) भोजन (B) मौसम (C) ऊर्जा (D) सौर परिवार

**149.** As per NCF 2005, which of the following is the theme of EVS?
(A) Food (B) Weather (C) Energy (D) Solar System

---

**150.** भारतीय संविधान का कौन-सा अनुच्छेद पर्यावरण संरक्षण को प्रत्येक नागरिक के मौलिक कर्तव्य के रूप में पहचान कराता है?
(A) अनुच्छेद 42 (B) अनुच्छेद 48A (C) अनुच्छेद 51A(g) (D) अनुच्छेद 52

**150.** Which article of the Indian Constitution identifies environmental protection as a fundamental duty of every citizen?
(A) Article 42 (B) Article 48A (C) Article 51A(g) (D) Article 52
