# UTET 2020 — Paper I (Class I–V) — SET A

## Section 3 : Second Language — English
**Questions 61 – 90** | 1 mark each

---

**61.** In the following sentence, transform the given affirmative sentence into a negative sentence –
*Every human has failings.*

- (A) Every human has no failings.
- (B) There is no human without failings. ✅
- (C) There are humans with no failings.
- (D) Humans have no failings.

**Answer : (B)**

---

**62.** Choose the appropriate active voice for the following sentence without changing its meaning –
*It is said that there may be another World War.*

- (A) People say that there may be another World War. ✅
- (B) People said that there will be another World War.
- (C) Another World War may happen.
- (D) There may be another World War as people have said.

**Answer : (A)**

---

**63.** Choose the option with the most appropriate usage of article :

- (A) I saw the U.S. plane yesterday.
- (B) I saw a U.S. plane yesterday. ✅
- (C) I saw an U.S. plane yesterday.
- (D) I saw plane yesterday.

**Answer : (B)**

---

**64.** In the given sentence, omit 'too' without changing its meaning and select the most appropriate option for it –
*The fact is too evident to require proof.*

- (A) The fact is evident to require any proof.
- (B) The fact is so true to require any proof.
- (C) The fact is so evident that it does not require any proof. ✅
- (D) The fact does not require any proof.

**Answer : (C)**

---

**65.** Fill in the blank with the most suitable conjunction :
*No nation can be perfectly well governed ________ it is competent to govern itself.*

- (A) before
- (B) since
- (C) till ✅
- (D) after

**Answer : (C)**

---

**66.** Pick out the most suitable preposition to fill in the blank :
*You haven't complied ________ the regulations.*

- (A) of
- (B) with ✅
- (C) to
- (D) by

**Answer : (B)**

---

### Direction (Q. No. 67-71) :
Read the given passage carefully and answer the questions that follow by selecting the most appropriate option.

> Alice was a little girl with an imaginative and fertile mind. Once while sitting by her sister on the bank of the river she fell asleep. She dreamt that she was running across the field after a white, beautiful rabbit. She fell down a large rabbit hole and entered a strange land where she came across many odd characters and had many strange adventures. When she woke up she found herself lying on the bank with her head on her sister's lap. She told her sister about her curious and strange dream and her extraordinary adventure in that wonderland. The sister found no sense in her dream. It is futile to expect any sense or logic in the dreams of a little girl.

---

**67.** Give the exact synonym for the word **fertile** :

- (A) Futile
- (B) Fecund ✅
- (C) Flabber
- (D) Floppy

**Answer : (B)**

---

**68.** What type of a girl is Alice?

- (A) Visionary ✅
- (B) Realistic
- (C) Pedestrian
- (D) Attentive

**Answer : (A)**

---

**69.** What did Alice see in her dream?

- (A) Fairies are flying in the sky.
- (B) She is running with a furry fawn.
- (C) She is running with a white rabbit. ✅
- (D) She is running with her sister.

**Answer : (C)**

---

**70.** What is the most appropriate title to the passage?

- (A) Alice's realism
- (B) Alice on the banks
- (C) Alice and her sister
- (D) Alice in wonderland ✅

**Answer : (D)**

---

**71.** What does the phrase 'rabbit hole' mean in the given passage?

- (A) In a surreal situation ✅
- (B) In a realistic situation
- (C) In a complex situation
- (D) In an agonizing situation

**Answer : (A)**

---

**72.** Metalinguistic awareness is :

- (A) The ability to think and talk about language ✅
- (B) The ability to connect the distinctive sounds in words to letters
- (C) Understanding of the mapping principles between sounds and meaning.
- (D) The ability to recognize writing from other visual marks.

**Answer : (A)**

---

**73.** Which skills are receptive?

- (A) listening and speaking
- (B) listening and reading ✅
- (C) reading and writing
- (D) writing and speaking

**Answer : (B)**

---

**74.** While translating a subject and using the translation in the mainstream curriculum, the benefit is :

- (A) promoting national identity
- (B) enriching linguistic capability and appreciation ✅
- (C) enabling teachers who are not competent in the mainstream language to take class.
- (D) standardizing cultural identity

**Answer : (B)**

---

**75.** For students to gain language skills from textbooks, the textbook learning should :

- (A) correlate with assessment and achievement. ✅
- (B) lead to using the textbook sparingly.
- (C) expose them to more literary reading.
- (D) become more cost-effective compared to technologically supported course.

**Answer : (A)**  *(आधिकारिक UBSE कुंजी)*

---

**76.** The teaching of reading by associating characters or groups of characters with sound is the ________ method.

- (A) morphemic
- (B) phonic ✅
- (C) direct
- (D) whole-language

**Answer : (B)**

---

**77.** Teachers can remediate for the students with language learning difficulty by :

- (A) focusing on individual progress with individual instruction. ✅
- (B) providing notes that are simplified
- (C) initially giving information as reading only, no writing.
- (D) conducting extra class for the students.

**Answer : (A)**

---

**78.** One who hates knowledge and reasoning is called :

- (A) Mercenary
- (B) Misanthrope
- (C) Misologist ✅
- (D) Misogamist

**Answer : (C)**

---

**79.** The idiomatic expression 'A storm in a cup' means :

- (A) lose patience
- (B) A perfect situation
- (C) Small fuss on a big thing
- (D) Big fuss on a small thing ✅

**Answer : (D)**

---

**80.** Read the following sentence carefully and pick out the correct figure of speech –
*Blue baby bonnets bobbed through the bayou.*

- (A) Assonance
- (B) Alliteration ✅
- (C) Hyperbole
- (D) Anaphora

**Answer : (B)**

---

**81.** Which of the following options best describes the figure of speech 'Synecdoche'?

- (A) Two contradictory terms used together
- (B) Gives human qualities to non-living things
- (C) Comparison between two unlike things
- (D) When a part is presented by a whole or, conversely, the whole is presented by the part. ✅

**Answer : (D)**

---

**82.** From the following options, pick out the one with the correct spelling –

- (A) Lieutnant
- (B) Lieutenant ✅
- (C) Lieutnane
- (D) Lieutnante

**Answer : (B)**

---

**83.** From the given options select the correct synonym (similar meaning) of 'Valour' –

- (A) Faithful
- (B) Bravery ✅
- (C) Brilliant
- (D) Ravenous

**Answer : (B)**

---

### Directions (Q. No. 84-88) :
Read the given passage carefully and answer the questions that follow by selecting the most appropriate option.

> At about the time when the autobiography first appeared I remember reading its opening chapters in the ill-printed pages of some Indian newspaper. They made a good impression on me, which Gandhi himself, at that time, did not. The things that one associated with him — 'homespun cloth', 'soul force' and vegetarianism — were unappealing, and his medievalist programme was obviously not viable in a backward, starving, over-populated country. It was also apparent that the British were making use of him, or thought they were making use of him. Strictly speaking, as a nationalist, he was an enemy, but since in every crisis he would exert himself to prevent violence — which, from the British point of view, meant preventing any effective action whatever — he could be regarded as 'our man'.

---

**84.** What is the name of Gandhi's autobiography?

- (A) My Experiments with Truth ✅
- (B) My Experiments with Life
- (C) My Experiments with Indians
- (D) My Experiment with Britishers

**Answer : (A)**

---

**85.** How did Gandhi achieve freedom?

- (A) Through sloganeering
- (B) Through violence and agitation
- (C) Through homespun cloth and soul force ✅
- (D) None of the above

**Answer : (C)**

---

**86.** What was Gandhi's medievalist programme?

- (A) To keep the nation starved
- (B) To bring freedom through peace ✅
- (C) Agitation for Britishers
- (D) To wait and watch

**Answer : (B)**

---

**87.** Why was Gandhi considered as 'our man'?

- (A) He was a spokesperson of Indians.
- (B) He was a spokesperson of Britishers.
- (C) He was a spokesperson of Indians and Britishers. ✅
- (D) He was a spokesperson of none.

**Answer : (C)**  *(आधिकारिक UBSE कुंजी)*

---

**88.** What does the expression 'not viable' in the passage mean?

- (A) Dominant
- (B) Foremost
- (C) Principal
- (D) Inconsequential ✅

**Answer : (D)**

---

**89.** Fill in the blank with the most suitable gerund :
*Waiting for a bus is a ________ experience.*

- (A) Kill
- (B) Killing ✅
- (C) Kills
- (D) Is killing

**Answer : (B)**

---

**90.** From the following options, choose the one with the correct word order :

- (A) Why she did leave so early?
- (B) Why did she leave so early? ✅
- (C) Why did so early she leave?
- (D) Why so early did she leave?

**Answer : (B)**

---

*End of Section 3 (Second Language – English)*
