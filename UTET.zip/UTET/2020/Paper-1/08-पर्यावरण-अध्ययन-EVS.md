# UTET 2020 — Paper I (Class I–V) — SET A

## खण्ड 5 : पर्यावरण अध्ययन / Environmental Studies
**प्रश्न 121 – 150** | प्रत्येक प्रश्न 1 अंक

---

**121.** 'मीनामाता रोग' ऐसी मछली खाने से होता है, जिसमें अधिक मात्रा में पाया जाता है –
*'Minamata Disease' was caused by eating fish which have high levels of –*

- (A) कैडमियम / Cadmium
- (B) आर्सेनिक / Arsenic
- (C) पारा / Mercury ✅
- (D) उपरोक्त सभी / All of the above

**उत्तर : (C)**

---

**122.** प्रोजेक्ट 'रेड पान्डा' शुरू हुआ –
*Project 'Red Panda' was started in –*

- (A) 1984
- (B) 1986
- (C) 1994
- (D) 1996 ✅

**उत्तर : (D)**

---

**123.** ओजोन परत का अधिकतम ह्रास निम्न में से किस पर हुआ है?
*Maximum ozone depletion has been observed in which of the following?*

- (A) भूमध्यरेखा / The Equator
- (B) उत्तरी ध्रुव / The North Pole
- (C) दक्षिणी ध्रुव / The South Pole ✅
- (D) उपरोक्त में से कोई नहीं / None of the above

**उत्तर : (C)**

---

**124.** निम्नलिखित में से कौन सा गंभीर जल असंतुलन का कारण **नहीं** होगा?
*Which of the following will NOT lead to a severe water imbalance?*

- (A) भूमिगत जल स्तर रिचार्ज करने में विफलता / Failure to recharge aquifers
- (B) अनियंत्रित शहरीकरण / Uncontrolled urbanization
- (C) दोषरहित जल संरचना / Flawless water infrastructure ✅
- (D) पानी का अत्यधिक दोहन / Over-exploitation of water

**उत्तर : (C)**

---

**125.** वाइल्डलाइफ इंस्टीट्यूट ऑफ इंडिया (WII) कहाँ स्थित है?
*Where is Wildlife Institute of India (WII) located?*

- (A) अहमदाबाद / Ahmedabad
- (B) नई दिल्ली / New Delhi
- (C) कोयम्बटूर / Coimbatore
- (D) देहरादून / Dehradun ✅

**उत्तर : (D)**

---

**126.** पंकज अपने छात्रों को यह सुझाव देना चाहता है कि कैसे एक व्यक्ति पर्यावरण संरक्षण में सर्वोत्तम तरीके से योगदान दे सकता है। उसका सबसे अच्छा सुझाव होगा –
*Pankaj wants to suggest to his students how an individual can contribute in the best possible way towards environmental protection. His best suggestion would be –*

- (A) यात्रा के लिए सार्वजनिक परिवहन प्रणाली का उपयोग करें। / Use public transport for travelling. ✅
- (B) निजी वाहन जैसे कार, स्कूटर आदि न रखना। / Do not keep a personal vehicle.
- (C) बार-बार घर से बाहर जाने से बचें। / Avoid frequent travel outside the home.
- (D) निजी वाहन के इंजन की नियमित रूप से जाँच करें। / Get the engine of personal vehicle checked regularly.

**उत्तर : (A)**

---

**127.** मानवीय गतिविधियाँ, जो पृथ्वी पर जलवायु परिवर्तन के लिए जिम्मेदार हैं, वे हैं –
*Human activities that cause climate change on the earth include –*

- (A) एयरोसोल कैन का उपयोग / Use of aerosol cans
- (B) कृषि क्रियाकलाप / Agricultural activities
- (C) वनों को जलाना / Burning of forests
- (D) उपर्युक्त सभी / All of the above ✅

**उत्तर : (D)**

---

**128.** केंचुआ किसान का मित्र माना जाता है। निम्न में से उसके लिए सही कारण चुनें –
*Earthworms are considered friends of the farmers. Select the correct reason –*

1. केंचुए मृत पत्तियों और पौधों को खाते हैं और उनकी बीट मिट्टी को उर्वरा बनाती है।
2. केंचुए खरपतवार खाते हैं और मुख्य फसल को बचाते हैं।
3. केंचुए नीचे की खुदाई कर मिट्टी को नरम करते हैं।
4. केंचुए की खुदाई हवा और पानी मिट्टी में आसानी से पहुँचाती है।

- (A) 1, 2, 3
- (B) 1, 3, 4 ✅
- (C) केवल 1 और 3
- (D) 2, 3, 4

**उत्तर : (B)**

---

**129.** निम्नलिखित में से कौन बायोडीजल उत्पन्न करने के लिए जाना जाता है?
*Which of the following is known for producing biodiesel?*

- (A) कॉपर लीफ / Copper leaf
- (B) जैट्रोफा / Jatropha ✅
- (C) कैंडलनट ट्री / Candle nut tree
- (D) सर्पगंधा / Sarpagandha

**उत्तर : (B)**

---

**130.** यह सवाल पूछने पर "अगर एक महीने तक बिजली नहीं मिली तो हमारा जीवन कैसे प्रभावित होगा?" का उद्देश्य है –
*Asking the question "How will our life get affected if there were no electricity for a month?" aims at –*

- (A) विवेकपूर्ण ढंग से बिजली का उपयोग करने हेतु छात्रों को संवेदनशील बनाना ✅
- (B) बिजली के स्रोत पर छात्रों का आकलन करना
- (C) छात्रों की कल्पनाशीलता और सोच कौशल को बढ़ावा देना ✅
- (D) सामान्य जागरूकता पर छात्रों का आकलन करना

**उत्तर : (A)**  *(आधिकारिक कुंजी : (A) तथा (C) दोनों सही)*

---

**131.** कार्बोहाइड्रेट और प्रोटीन दोनों में पाया जाने वाला सामान्य तत्व है –
*Common element which is present in both Carbohydrate and Protein is –*

- (A) क्लोरीन / Chlorine
- (B) नाइट्रोजन / Nitrogen
- (C) कार्बन / Carbon ✅
- (D) सल्फर / Sulphur

**उत्तर : (C)**

---

**132.** 'झूम खेती' पायी जाती है –
*'Jhoom Cultivation' is practised in –*

- (A) केरल में / Kerala
- (B) बिहार में / Bihar
- (C) मेघालय में / Meghalaya ✅
- (D) मध्य प्रदेश में / Madhya Pradesh

**उत्तर : (C)**

---

**133.** निम्न में से कौन सी पराबैंगनी किरण सबसे खतरनाक है?
*Which of the following Ultraviolet rays is most dangerous?*

- (A) UV-A
- (B) UV-B ✅
- (C) UV-C ✅
- (D) कोई नहीं / None

**उत्तर : (C)**  *(आधिकारिक कुंजी : (B) तथा (C) दोनों सही)*

---

**134.** 'ग्रीन पीस इंटरनेशनल' का मुख्यालय स्थित है –
*Headquarter of 'Greenpeace International' is located at –*

- (A) न्यूयॉर्क / New York
- (B) एम्सटर्डम / Amsterdam ✅
- (C) नई दिल्ली / New Delhi
- (D) नागासाकी / Nagasaki

**उत्तर : (B)**

---

**135.** नदी के जल में प्रदूषण स्तर मापा जाता है –
*Pollution level in river water is measured by –*

- (A) ए.टी.पी. / ATP
- (B) एस.टी.पी. / STP
- (C) बी.ओ.डी. / BOD ✅
- (D) जी.टी.पी. / GTP

**उत्तर : (C)**

---

**136.** 'हरित मफलर' संबंधित है –
*'Green Muffler' relates to –*

- (A) मृदा प्रदूषण / Soil Pollution
- (B) वायु प्रदूषण / Air Pollution
- (C) ध्वनि प्रदूषण / Noise Pollution ✅
- (D) जल प्रदूषण / Water Pollution

**उत्तर : (C)**

---

**137.** विश्व पर्यावरण दिवस 2020 की विषयवस्तु क्या थी?
*What was the theme of World Environment Day 2020?*

- (A) वायु प्रदूषण / Air Pollution
- (B) 7 अरब लोग एक ग्रह, सावधानी के साथ उपभोग / Seven billion people one planet, consume with care
- (C) अपनी आवाज उठाओ, समुद्र का स्तर नहीं / Raise your voice not sea level
- (D) जैवविविधता / Biodiversity ✅

**उत्तर : (D)**

---

**138.** वायु प्रदूषण प्रकरण पढ़ाने के लिये चार अलग-अलग विज्ञान शिक्षक चार तरह की शिक्षण पद्धतियों का प्रयोग करते हैं। निम्नलिखित में से कौन सी पद्धति सबसे ज्यादा उचित है?
*To teach the chapter on Air pollution, four different Science teachers used different teaching methodologies. Which of them is best suited?*

- (A) प्रकरण पूरा करने के बाद अभ्यास में दिये गये सभी प्रश्नों के उत्तर लिखवाना।
- (B) विद्यार्थियों को वायु प्रदूषण पर वृत्तचित्र दिखाना। ✅
- (C) विद्यार्थियों से कहना कि वे दीपावली से पहले और बाद में वायु के नमूने इकट्ठा करें और उसकी गुणवत्ता का अध्ययन करते हुये निष्कर्षों को सारणीकृत करें। ✅
- (D) विद्यार्थियों को पाठ्यपुस्तक में से प्रकरण का सस्वर पाठन करने के लिए कहना और संकल्पना शब्दावली का अर्थ स्पष्ट करना।

**उत्तर : (C)**  *(आधिकारिक कुंजी : (B) तथा (C) दोनों सही)*

---

**139.** GIS का विस्तृत रूप है –
*Expanded form of GIS is –*

- (A) भौगोलिक सूचना प्रणाली / Geographical Information System ✅
- (B) भौगोलिक सूचना स्रोत / Geographical Information Source
- (C) भूगर्भीय सूचना प्रणाली / Geological Information System
- (D) कोई नहीं / None of these

**उत्तर : (A)**

---

**140.** मृत सागर क्या है?
*What is Dead Sea?*

- (A) ऐसा सागर जिसका पानी जहरीला है।
- (B) ऐसा सागर जो सभी सागरों व महासागरों से ज्यादा नमकीन है। ✅
- (C) ऐसा सागर जिसमें ज्वार-भाटे बहुत तीव्र गति से आते हैं।
- (D) ऐसा सागर जिसमें जहाज चलाना खतरनाक है।

**उत्तर : (B)**

---

**141.** मीरा और दिव्या छोटी लड़कियाँ हैं। मीरा समोसे, कटलेट और डबलरोटी खाना पसन्द करती है, जबकि दिव्या ऐसा भोजन पसन्द करती है जिसमें लौह तत्व की कमी हो। मीरा और दिव्या को क्रमशः कौन सी बीमारी हो सकती है?
*Mira and Divya can suffer which of the following diseases respectively?*

- (A) मोटापा और स्कर्वी / Obesity and Scurvy
- (B) स्कर्वी और एनीमिया / Scurvy and Anaemia
- (C) एनीमिया और रतौंधी / Anaemia and Night blindness
- (D) मोटापा और एनीमिया / Obesity and Anaemia ✅

**उत्तर : (D)**

---

**142.** निम्नलिखित में से कौन सा विटामिन कोशिकाओं की सुरक्षा में सहायक है?
*Which of the following vitamins helps in protecting the cells?*

- (A) विटामिन B₁₂
- (B) विटामिन K
- (C) विटामिन E ✅
- (D) विटामिन A

**उत्तर : (C)**

---

**143.** पर्यावरण अध्ययन के शिक्षक के रूप में आप बच्चों को चिड़ियाघर ले जाने की योजना बनाते हैं। आप बच्चों को निम्नलिखित में से कौन सी गतिविधि करने की अनुमति **नहीं** देंगे?
*As a teacher of EVS, you plan a trip to a zoo. Which of the following activities would you not permit?*

- (A) चिड़ियाघर के जानवरों के लिए बहुत सारी खाने की सामग्री ले जाना। ✅
- (B) चिड़ियाघर के विभिन्न जानवर कौन सा खाना खाते हैं, यह पता लगाना।
- (C) चिड़ियाघर में जिन जानवरों को देखेंगे उनकी फोटो लेना।
- (D) चिड़ियाघर में उन्होंने जो देखा उसका चित्र बनाने के लिए ड्राइंग कॉपी साथ ले जाना।

**उत्तर : (A)**

---

**144.** प्राथमिक स्तर पर ई.वी.एस. पाठ्यपुस्तक में कविताओं और कहानियों की भूमिका होती है –
*The role of poems and stories in the EVS textbook at primary level is to –*

- (A) मौलिक अवधारणाओं की बेहतर समझ को बढ़ाना।
- (B) नियमित शिक्षण शैली में बदलाव लाना।
- (C) छात्रों में साहित्यिक कौशल विकसित करना।
- (D) विषय को सीखने में अधिक रुचिकर एवं मनोरंजक बनाना। ✅

**उत्तर : (D)**

---

**145.** पर्यावरण अध्ययन के शिक्षक को –
*A teacher of EVS should –*

- (A) बच्चों के दृष्टिकोण को स्वीकार करना एवं सम्मान देना चाहिए। ✅
- (B) अभिभावक के विचार को स्वीकार करना एवं सम्मान देना चाहिए।
- (C) विशेषतः प्रयोगों पर ध्यान देना चाहिए। ✅
- (D) विशेषतः पुस्तकों और परीक्षाओं पर ध्यान देना चाहिए।

**उत्तर : (A)**  *(आधिकारिक कुंजी : (A) तथा (C) दोनों सही)*

---

**146.** पर्यावरण अध्ययन में एक अच्छे दत्त कार्य (assignment) का मुख्य लक्ष्य होना चाहिये –
*A good assignment in EVS should primarily aim at –*

- (A) प्रभावी अधिगम के लिये पाठ को दोहराना
- (B) समय का बेहतर उपयोग सुनिश्चित करना
- (C) शिक्षार्थियों में अनुशासन बनाये रखना
- (D) अधिगम विस्तार के अवसर उपलब्ध कराना ✅

**उत्तर : (D)**

---

**147.** मौसम का महत्वपूर्ण तत्व जो भारत में कृषि को प्रभावित करता है –
*The most important element of weather which affects agriculture in India is –*

- (A) तापमान / Temperature
- (B) आर्द्रता / Humidity
- (C) वायु की गुणवत्ता / Air quality
- (D) वर्षा / Rainfall ✅

**उत्तर : (D)**

---

**148.** माउन्ट एवरेस्ट कहाँ स्थित है?
*Where is Mount Everest located?*

- (A) भारत / India
- (B) चीन / China
- (C) तिब्बत / Tibet
- (D) नेपाल / Nepal ✅

**उत्तर : (D)**

---

**149.** भूकम्प के लिए उत्तरदायी पृथ्वी की प्लेटें पाई जाती हैं –
*The earth's plates responsible for causing earthquakes are found in –*

- (A) भू-पर्पटी में / the crust of the earth ✅
- (B) पृथ्वी के प्रावार में / the mantle of the earth
- (C) पृथ्वी की आन्तरिक क्रोड में / the inner core
- (D) पृथ्वी की बाह्य क्रोड में / the outer core

**उत्तर : (A)**

---

**150.** पेट्रोल और डीजल जैसे ईंधनों का अपूर्ण दहन देता है –
*Incomplete combustion of fuels such as petrol and diesel gives –*

- (A) नाइट्रोजन ऑक्साइड / nitrogen oxide
- (B) सल्फर डाइऑक्साइड / sulphur dioxide
- (C) कार्बन मोनोऑक्साइड / carbon monoxide ✅
- (D) कार्बन डाइऑक्साइड / carbon dioxide

**उत्तर : (C)**

---

*खण्ड 5 (पर्यावरण अध्ययन) समाप्त — प्रश्न पत्र समाप्त*
