# UTET 2020 — Paper I (Class I–V) — SET A

## Section 2 : First Language — English
**Questions 31 – 60** | 1 mark each

---

### Direction (Q. No. 31 to 35) :
Read the passage given below and answer the questions that follow by selecting the most appropriate option.

> Every year, a large number of Siberian cranes come to the bird sanctuary at Bharatpur. Year after year, in the beginning of winter these birds cover thousands of miles from Siberia in the north of Russia to come to Bharatpur, and then, as winter ends, they once again return to their original habitat, without making any mistake in the direction they have to take in their long flights. It is surprising how these birds find their way over such long distances, especially when vast stretches of land happen to be covered with clouds so that familiar landmarks, which could have guided them, are not even visible. The same phenomenon has been observed in other parts of the world as well. By way of experiment, light metal rings with specific information are put on the legs of some migratory birds, and it is observed that they keep returning to the winter sanctuary year after year without fail. Pigeons are well known for finding their way back home inspite of all odds. At one time, it was believed that they could find their way with the help of familiar landmarks which they had seen and remembered. In an experiment, some pigeons were carried to a considerable distance in cages covered with black cloth so that they could not see anything on the way. However, when they were released, they still managed to come back to the place from where they had been taken away in covered cages. To check whether the pigeons remembered the direction of movement even when they could not see anything, another experiment was undertaken. To confuse their sense of direction, some pigeons were carried in an aeroplane and then released. Many of them still managed to return home on their own.

---

**31.** When do the Siberian cranes come to the Bharatpur sanctuary?

- (A) In the end of winter
- (B) In the beginning of summer
- (C) In the beginning of winter ✅
- (D) In the beginning of spring

**Answer : (C)**

---

**32.** What is the original habitat of the cranes?

- (A) Bharatpur in India
- (B) Siberia in the north of Russia ✅
- (C) Mongolia in the north of China
- (D) Morocco in the north of Africa

**Answer : (B)**

---

**33.** How was it known that the same cranes returned to Bharatpur year after year?

- (A) By putting light metal rings with special information on the legs of these birds. ✅
- (B) By carrying them to a considerable distance in cages covered with black cloth.
- (C) By carrying them in an aeroplane and then releasing them.
- (D) By blindfolding them and carrying them to a long distance.

**Answer : (A)**

---

**34.** Find in the passage words that mean – (i) astonishing (ii) noticed

- (A) believed, remembered
- (B) surprising, observed ✅
- (C) managed, undertaken
- (D) released, taken

**Answer : (B)**

---

**35.** Which of the following options is correct : Migratory pigeons can't –

- (A) see anything on the way
- (B) remember familiar landscape
- (C) fly long distances
- (D) live at one place all the time ✅

**Answer : (D)**

---

### Direction (Q. No. 36 to 40) :
Read the poem given below and answer the questions that follow by selecting the most appropriate option.

> I heard a thousand blended notes,
> While in a grove I sat reclined,
> In that sweet mood when pleasant thoughts
> Bring sad thoughts to the mind.
>
> To her fair works did Nature link
> The human soul that through me ran;
> And much it grieved my heart to think
> What man has made of man.
>
> Through primrose tufts, in that green bower,
> The periwinkle trailed its wreaths;
> And 'tis my faith that every flower
> Enjoys the air it breathes.
>
> The birds around me hopped and played,
> Their thoughts I cannot measure;
> But the least motion which they made
> It seemed a thrill of pleasure.
>
> The budding twigs spread out their fan,
> To catch the breezy air,
> And I must think, do all I can,
> That there was pleasure there.
>
> If this belief from heaven be sent,
> If such be Nature's holy plan,
> Have I not reason to lament
> What man has made of man?

---

**36.** What kind of feelings does the poet have after being in the midst of nature?

- (A) Happy feelings
- (B) Sad feelings
- (C) Mixed feelings ✅
- (D) Painful feelings

**Answer : (C)**

---

**37.** Where did the poet hear the melodious music?

- (A) in a bower
- (B) in the breezy air
- (C) in a grove ✅
- (D) under the primrose tufts

**Answer : (C)**

---

**38.** As per the poem, one of the following statements is correct –

- (A) Humans have treated other humans in barbaric ways ✅
- (B) Pleasure is everywhere
- (C) Humans do not enjoy nature
- (D) Nature is beautiful and its plan is divine

**Answer : (A)**

---

**39.** What is the synonym of the words – (i) lament (ii) hopped

- (A) welcome, dived
- (B) satisfaction, romped
- (C) regret, jumped ✅
- (D) guilt, swam

**Answer : (C)**

---

**40.** Point out the figure of speech in the line "And 'tis my faith that every flower Enjoys the air it breathes".

- (A) Simile
- (B) Oxymoron
- (C) Metaphor
- (D) Personification ✅

**Answer : (D)**

---

**41.** Language acquisition occurs only when –

- (A) The child is taught the rules of grammar
- (B) The child is given a reward
- (C) The child has exposure to the language ✅
- (D) The child absorbs the language without conscious attention.

**Answer : (C)**

---

**42.** "Interactive" listening is –

- (A) Listening and responding ✅
- (B) Listening for mode of tone
- (C) Listening for word stress and emphasis
- (D) Listening for finding out speaker's attitude

**Answer : (A)**

---

**43.** To teach grammar, the most appropriate grammar that a teacher can use is –

- (A) Traditional grammar
- (B) Modern grammar
- (C) Pedagogic grammar ✅
- (D) No grammar is needed

**Answer : (C)**

---

**44.** Study of meaning in a language is known as –

- (A) Syntax
- (B) Morphology
- (C) Linguistics
- (D) Semantics ✅

**Answer : (D)**

---

**45.** Good evaluation of written material should not be based on –

- (A) Linguistic expression
- (B) Logical presentation
- (C) Ability to reproduce whatever is read ✅
- (D) Comprehension of subject

**Answer : (C)**

---

**46.** Audio-visual aids help ________ students in the class.

- (A) Playful
- (B) Curious
- (C) Intelligent
- (D) Slow-learning ✅

**Answer : (D)**

---

### Direction (Q. No. 47) :
Rearrange the following words and phrases to form a meaningful sentence. Choose the correct alternative sentence.

**47.** light up / in every home / good / the lamp / books / magazines / and / of / knowledge

- (A) Good books of magazines knowledge light up in every home the lamp knowledge.
- (B) Good books knowledge magazines of light up the lamp knowledge in every home.
- (C) Good books and magazines light up the lamp of knowledge in every home. ✅
- (D) Good books and magazines in every home light up the lamp of knowledge.

**Answer : (C)**

---

### Direction (Q. No. 48) :
Choose the most suitable option that describes the meaning of the underlined idiom/phrase.

**48.** On the eve of inspection, everything was kept **in apple pie order**.

- (A) In random order
- (B) In ascending order
- (C) In descending order
- (D) In perfect order ✅

**Answer : (D)**

---

### Direction (Q. No. 49) :
In the following sentence choose the antonym to the underlined word.

**49.** Excessive praise has the same impact as too many **extrinsic** rewards.

- (A) Reputable
- (B) Acquired
- (C) Ambitious
- (D) Inherent ✅

**Answer : (D)**

---

### Direction (Q. No. 50) :
Select the most suitable conjunction and fill in the blank.

**50.** I was tired, ________ I managed to finish the work.

- (A) and
- (B) although
- (C) but ✅
- (D) because

**Answer : (C)**  *(आधिकारिक UBSE कुंजी)*

---

### Direction (Q. No. 51) :
Select the correct alternative which can be substituted for the sentence below.

**51.** A person who eats too much –

- (A) Glutton ✅
- (B) Nibbler
- (C) Cannibal
- (D) Omnivore

**Answer : (A)**

---

**52.** Choose the word with the **incorrect** spelling –

- (A) Accomodate ✅  *(correct spelling: accommodate)*
- (B) Bizzare ✅
- (C) Chauffeur
- (D) Fluorescent

**Answer : (A)**  *(official key accepts both (A) and (B) — "Accomodate" & "Bizzare" are both misspelt)*

---

**53.** Choose the word with the **correct** spelling –

- (A) Idiosyncracy
- (B) Pavillion
- (C) Supercede
- (D) Caribbean ✅

**Answer : (D)**

---

### Direction (Q. No. 54) :
Select the word nearest in meaning to the underlined part.

**54.** The rain has brought **respite** to the people –

- (A) work
- (B) despite
- (C) relief ✅
- (D) hatred

**Answer : (C)**

---

### Direction (Q. No. 55) :
Choose the correct (reflexive) pronoun to complete the sentence.

**55.** We don't have an electrician; we can fix the light by ________.

- (A) herself
- (B) himself
- (C) myself
- (D) ourselves ✅

**Answer : (D)**

---

### Direction (Q. No. 56-57) :
Choose the correct auxiliary or modal verb out of the given alternatives.

**56.** Andy ________ eat five slices of pizza in just one meal.

- (A) must
- (B) have to
- (C) should
- (D) can ✅

**Answer : (D)**

---

**57.** I know how to do my work. She ________ help me.

- (A) don't have to
- (B) hasn't to
- (C) hasn't got to
- (D) doesn't have to ✅

**Answer : (D)**

---

### Direction (Q. No. 58) :
Select the most appropriate word to fill in the blank.

**58.** It would be unwise to ________ the plan at this stage.

- (A) grasp
- (B) abandon ✅
- (C) craggy
- (D) clutch

**Answer : (B)**

---

### Direction (Q. No. 59-60) :
Select the most suitable option for indirect narration.

**59.** I said to him, "Why are you working so hard?"

- (A) I asked him why he was working so hard. ✅
- (B) I asked him why was he working so hard.
- (C) I asked him why had he been working so hard.
- (D) I asked him why he had been working so hard.

**Answer : (A)**

---

**60.** He said to her, "What a cold day!"

- (A) He told her that it was a cold day.
- (B) He announced that it was a cold day.
- (C) He exclaimed sorrowfully that it was a cold day.
- (D) He exclaimed that it was a very cold day. ✅

**Answer : (D)**

---

*End of Section 2 (First Language – English)*
