# UTET 2020 — Paper I (Class I–V) — SET A

## खण्ड 4 : गणित / Mathematics
**प्रश्न 91 – 120** | प्रत्येक प्रश्न 1 अंक

---

**91.** निम्नलिखित मापों में कौन त्रिभुज का निर्माण कर सकता है?
*Which of the following measures can form a triangle?*

- (A) 2, 3, 6
- (B) 3, 4, 6 ✅
- (C) 3, 4, 7
- (D) 4, 6, 12

**उत्तर : (B)**  *(3 + 4 > 6)*

---

**92.** log<sub>√2</sub> √8 का मान है –
*The value of log<sub>√2</sub> √8 is –*

- (A) 4
- (B) 3 ✅
- (C) 2
- (D) 1.5

**उत्तर : (B)**  *(√8 = (√2)³)*

---

**93.** त्रिभुज की तीनों माध्यिकाओं का प्रतिच्छेद बिन्दु कहलाता है –
*The point of intersection of all three medians of a triangle is called –*

- (A) परिकेन्द्र / Circumcentre
- (B) अन्तःकेन्द्र / Incentre
- (C) लम्बकेन्द्र / Orthocentre
- (D) केन्द्रक / Centroid ✅

**उत्तर : (D)**

---

**94.** एक रेलगाड़ी 800 मीटर तथा 400 मीटर लम्बे दो पुलों को क्रमशः 100 सेकेण्ड तथा 60 सेकेण्ड में पार करती है, तो रेलगाड़ी की लम्बाई होगी –
*A train crosses two bridges of 800 m and 400 m long in 100 s and 60 s respectively. The length of the train will be –*

- (A) 100 मीटर
- (B) 200 मीटर ✅
- (C) 300 मीटर
- (D) 400 मीटर

**उत्तर : (B)**  *( (800+L)/100 = (400+L)/60 ⟹ L = 200 )*

---

**95.** 1559 डेसीग्राम बराबर है –
*1559 Decigram is equal to –*

- (A) 15.59 ग्राम / gram
- (B) 155.9 डेकाग्राम / Dekagram
- (C) 0.01559 किलोग्राम / Kilogram
- (D) 1.559 हेक्टोग्राम / Hectogram ✅

**उत्तर : (D)**  *(1559 dg = 155.9 g = 1.559 hg)*

---

**96.** 10 नल एक टैंक को 24 मिनट में भर सकते हैं। टैंक को 1 घण्टे में भरने के लिये कितने नलों की आवश्यकता होगी?
*10 taps can fill a tank in 24 minutes. How many taps will be required to fill the tank in one hour?*

- (A) 25
- (B) 4 ✅
- (C) 12
- (D) 8

**उत्तर : (B)**  *(10 × 24 / 60 = 4)*

---

**97.** तीन कक्षाओं में छात्रों का अनुपात 2 : 3 : 5 है। यदि तीनों कक्षाओं में 4 छात्र बढ़ा दिये जायें, तो अनुपात 4 : 5 : 7 हो जायेगा। तीनों कक्षाओं में कुल कितने छात्र हैं?
*The ratio of students in three classes is 2 : 3 : 5. If 4 students are added to each class, the ratio becomes 4 : 5 : 7. What is the total number of students?*

- (A) 20 ✅
- (B) 40
- (C) 70
- (D) 100

**उत्तर : (A)**  *(x = 2 ⟹ 4, 6, 10 = 20)*

---

**98.** √7 − √5, √5 − √3, √9 − √7, √11 − √9 में सबसे बड़ी संख्या है –
*The largest number among √7 − √5, √5 − √3, √9 − √7, √11 − √9 is –*

- (A) √7 − √5
- (B) √5 − √3 ✅
- (C) √9 − √7
- (D) √11 − √9

**उत्तर : (B)**  *(अंतर = 2/(√a+√b); हर सबसे छोटा ⟹ मान सबसे बड़ा)*

---

**99.** (17)²⁰⁰ को 18 से भाग देने पर शेषफल होगा –
*If (17)²⁰⁰ is divided by 18, the remainder will be –*

- (A) 1 ✅
- (B) 7
- (C) 9
- (D) 17

**उत्तर : (A)**  *(17 ≡ −1 (mod 18), (−1)²⁰⁰ = 1)*

---

**100.** बच्चों के मध्य गिनती के कौशल को विकसित करने के लिये निम्नलिखित में से कौन पूर्व-संख्या अवधारणा के रूप में सीखने के लिये आवश्यक **नहीं** है?
*To develop skill of counting among children, which one of the following is not required to be learned as pre-number concept?*

- (A) एक-एक संगतता / One-to-one correspondence
- (B) क्रमबद्धता / Seriation
- (C) संख्या नाम यादृच्छिक रूप से पढ़ना / Reciting number names randomly ✅
- (D) समूह बनाना / Creating groups

**उत्तर : (C)**

---

**101.** प्राथमिक कक्षाओं में बच्चे गणित में क्या सीखते हैं, इसके आकलन का ध्यान किस पर **नहीं** होना चाहिए?
*The assessment of what children learn in mathematics in primary classes should not focus on –*

- (A) गणितीय अवधारणाओं को समझना / Understanding of mathematical concepts
- (B) गणितीय भाषा का विकास / Development of mathematical language
- (C) गणित की समस्याओं का जवाब देने में सटीकता / Preciseness in answering mathematics problems ✅
- (D) तर्क कौशल का विकास / Development of reasoning skills

**उत्तर : (C)**

---

**102.** ज्यामितीय निरूपण, जो पूरे और उसके अंश के बीच सम्बन्ध दिखाता है, कहलाता है –
*A geometric representation showing the relationship between a whole and its part is called –*

- (A) आयत चित्र / histogram
- (B) पाई चार्ट / pie-chart ✅
- (C) दण्ड आलेख / bar-graph
- (D) चित्रलेख / picto-graph

**उत्तर : (B)**

---

**103.** निम्नलिखित में से कौन-सी एक गणितीय प्रक्रिया **नहीं** है?
*Which one of the following is not a mathematical process?*

- (A) मानसदर्शन / Visualization
- (B) रटना / Memorization ✅
- (C) आकलन / Estimation
- (D) मापन / Measurement

**उत्तर : (B)**

---

**104.** गणित में नैदानिक परीक्षण का उद्देश्य है –
*The purpose of a diagnostic test in mathematics is –*

- (A) बच्चों की समझ में अन्तर (कमियाँ) जानना / to know the gaps in children's understanding ✅
- (B) माता-पिता को प्रतिक्रिया देना / to give feedback to the parents
- (C) प्रगति रिपोर्ट भरना / to fill the progress report
- (D) अंतिम अवधि की परीक्षा के लिये प्रश्न पत्र की योजना बनाना / to plan the question paper for the end term examination

**उत्तर : (A)**

---

**105.** निम्नलिखित में से क्या प्रारम्भिक संख्या संकल्पना से संबंधित **नहीं** है?
*Which of the following is not related to early number concept?*

- (A) वर्गीकरण / Classification
- (B) वर्ग समावेश / Class inclusion
- (C) संरक्षण / Conservation
- (D) मापन / Measurement ✅

**उत्तर : (D)**

---

**106.** निम्नलिखित समुच्चयों में से कौन सा गणित में प्रश्न हल करने का कौशल है?
*Which one of the following sets are problem solving strategies in Mathematics?*

- (A) प्रयत्न-त्रुटि विधि, चित्रांकन करना, कंठस्थ करना / Trial-error, drawing, memorisation
- (B) चित्रांकन करना, पीछे से हल करना, रट लेना / Drawing, working back, rote learning
- (C) विवेचन करना, चर का प्रयोग करना, प्रतिरूप देखना / Reasoning, using variable, look for pattern ✅
- (D) कंठस्थ करना, अनुमान लगाकर परीक्षण करना, चित्रांकन करना / Memorisation, guess and test, drawing

**उत्तर : (C)**

---

**107.** 18² तथा 19² के बीच में कितनी प्राकृत संख्याएँ स्थित हैं?
*How many natural numbers lie between 18² and 19²?*

- (A) 30
- (B) 37
- (C) 35
- (D) 36 ✅

**उत्तर : (D)**  *(361 − 324 − 1 = 36)*

---

**108.** एक त्रिभुज के एक ही क्रम में लिये गये सभी बहिष्कोणों का योग कितना है?
*What is the sum of all the exterior angles taken in order of a triangle?*

- (A) 90°
- (B) 180°
- (C) 360° ✅
- (D) निर्धारित नहीं किया जा सकता / cannot be determined

**उत्तर : (C)**

---

**109.** दो भिन्नों का गुणनफल 14/15 है तथा उनका भागफल 35/24 है, तो बड़ी भिन्न है –
*The product of two fractions is 14/15 and their quotient is 35/24. The greater fraction is –*

- (A) 7/4
- (B) 7/6 ✅
- (C) 4/7
- (D) 4/5

**उत्तर : (B)**  *(a² = 14/15 × 35/24 = 49/36 ⟹ a = 7/6)*

---

**110.** एक तेल का टिन 4/5 भरा हुआ है। जब 6 बोतल तेल निकाल लिया जाता है और 4 बोतल तेल डाल दिया जाता है, तो यह 3/4 भरा हुआ है। पूरे टिन में कितने बोतल तेल भरा जा सकता है?
*A tank of oil is 4/5 full. When 6 bottles of oil are taken out and 4 bottles are poured in, it is 3/4 full. How many bottles of oil can the whole tank contain?*

- (A) 15
- (B) 20
- (C) 30
- (D) 40 ✅

**उत्तर : (D)**  *( (4/5 − 3/4)x = 2 ⟹ x/20 = 2 ⟹ x = 40 )*

---

**111.** यदि a तथा b दो अलग-अलग प्राकृत संख्यायें हैं, तो इनमें से कौन-सा कथन सत्य है?
*If a and b are two distinct natural numbers, which one of the following is true?*

- (A) √(a+b) > √a + √b
- (B) √(a+b) = √a + √b
- (C) √(a+b) < √a + √b ✅
- (D) ab = 1

**उत्तर : (C)**

---

**112.** किसी माह में, तीन रविवारों की दिनांक सम संख्या हैं, तब उस माह की 15 तारीख को क्या दिन होगा?
*For a certain month, the dates of three of the Sundays are even numbers. Then what day will be on 15th of that month?*

- (A) बृहस्पतिवार / Thursday
- (B) शुक्रवार / Friday
- (C) शनिवार / Saturday ✅
- (D) रविवार / Sunday

**उत्तर : (C)**  *(रविवार = 2, 9, 16, 23, 30 — सम दिनांक 2, 16, 30 ⟹ 15 शनिवार)*

---

**113.** X, Y तथा Z के लाभांश का अनुपात 2 : 3 : 7 है। यदि औसत लाभ ₹6000 है, तो Y का लाभांश है –
*X, Y and Z share the profit in the ratio 2 : 3 : 7. If the average gain is ₹6000, then Y's share is –*

- (A) ₹1500
- (B) ₹2000
- (C) ₹3000
- (D) ₹4500 ✅

**उत्तर : (D)**  *(कुल = 18000; Y = 3/12 × 18000 = 4500)*

---

**114.** उस कोण की माप क्या होगी, जिसका सम्पूरक कोण उसके कोटिपूरक कोण का तीन गुना है?
*The measure of an angle whose supplement is three times as large as its complement, is –*

- (A) 30°
- (B) 45° ✅
- (C) 60°
- (D) 75°

**उत्तर : (B)**  *(180 − x = 3(90 − x) ⟹ x = 45°)*

---

**115.** दो वर्गों के परिमाप 24 सेमी. तथा 32 सेमी. हैं। इन वर्गों के क्षेत्रफलों के योग के बराबर क्षेत्रफल वाले तीसरे वर्ग का परिमाप है –
*The perimeters of two squares are 24 cm and 32 cm. The perimeter of a third square, equal in area to the sum of the areas of these squares, is –*

- (A) 40 सेमी. ✅
- (B) 44 सेमी.
- (C) 48 सेमी.
- (D) 56 सेमी.

**उत्तर : (A)**  *(भुजाएँ 6, 8 ⟹ 36 + 64 = 100 ⟹ भुजा 10 ⟹ परिमाप 40)*

---

**116.** यदि 1 मिमी. भुजा वाले p वर्गों को मिलाकर 1 सेमी. भुजा का एक वर्ग बनाया जाता है तो p का मान है –
*If p squares of each side 1 mm make a square of side 1 cm, then p is equal to –*

- (A) 10
- (B) 100 ✅
- (C) 1000
- (D) 10000

**उत्तर : (B)**

---

**117.** चित्र में दिये गये ठोस का नाम है *(चित्र : त्रिभुजाकार फलक वाला प्रिज्म)* –
*The name of the solid in figure is :*

- (A) त्रिभुजाकार पिरामिड / triangular pyramid
- (B) आयताकार प्रिज्म / rectangular prism
- (C) त्रिभुजाकार प्रिज्म / triangular prism ✅
- (D) आयताकार पिरामिड / rectangular pyramid

**उत्तर : (C)**

---

**118.** पाँच क्रमागत प्राकृतिक संख्याओं का औसत M है। यदि अगली तीन प्राकृतिक संख्याओं को सम्मिलित किया जाये, तो नया औसत M से कितना अधिक है?
*The average of five consecutive natural numbers is M. If the next three natural numbers are also included, how much more is the new average than M?*

- (A) 1
- (B) 1.5 ✅
- (C) 2
- (D) 2.5

**उत्तर : (B)**

---

**119.** यदि मूलधन और 5 वर्षों के साधारण ब्याज का अनुपात 10 : 3 है, तो ब्याज की दर है –
*If the ratio of principal and the simple interest of 5 years is 10 : 3, then the rate of interest is –*

- (A) 6% ✅
- (B) 8%
- (C) 3%
- (D) 5%

**उत्तर : (A)**  *(3/10 = 5R/100 ⟹ R = 6%)*

---

**120.** यदि एक व्यक्ति अपनी चाल को कम करके 2/3 कर देता है, तो वह एक निश्चित यात्रा करने में 1 घण्टा अधिक लेता है। सामान्य चाल से यात्रा करने में लिया जाने वाला समय है –
*If a man reduces his speed to 2/3, he takes 1 hour more in walking a certain distance. The time to cover the distance with his normal speed is –*

- (A) 2 घण्टे / 2 hours ✅
- (B) 2.5 घण्टे
- (C) 3 घण्टे
- (D) 1.5 घण्टे

**उत्तर : (A)**  *(3t/2 = t + 1 ⟹ t = 2)*

---

*खण्ड 4 (गणित) समाप्त*
