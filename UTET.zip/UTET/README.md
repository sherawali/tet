# UTET Question Papers — Archive

Year-wise organized, cleaned-up question papers (OCR text corrected & formatted).

```
UTET/
├── 2021/
│   └── Paper-1-SET-C/        (Booklet XXI-1)
└── 2024/
    └── Paper-1-SET-D/        (Booklet XXIV-I)
```

Har paper folder me yeh files hoti hain:

| File | Content |
|---|---|
| `00-paper-info.md` | Paper details + structure |
| `01-child-development-pedagogy.md` | Q 1–30 |
| `02-language-1-hindi.md` | Q 31–60 (भाषा प्रथम हिन्दी) |
| `03-language-1-english.md` | Q 31–60 (First Language English) |
| `04-language-2-hindi.md` | Q 61–90 (भाषा द्वितीय हिन्दी) |
| `05-language-2-english.md` | Q 61–90 (Second Language English) |
| `06-language-2-sanskrit.md` | Q 61–90 (भाषा द्वितीय संस्कृत) |
| `07-mathematics.md` | Q 91–120 |
| `08-environmental-studies.md` | Q 121–150 |

## Index

| Year | Paper | Set | Booklet Code | Status |
|---|---|---|---|---|
| 2021 | Paper I (कक्षा 1–5) | C | XXI-1 | ✅ Added |
| 2022 | Paper I | — | XXII-I | ⬜ Pending (bolo to kar dunga) |
| 2023 | Paper I | — | — | ⬜ Pending |
| 2024 | Paper I (कक्षा 1–5) | D | XXIV-I | ✅ Added |
| 2025 | Paper I | — | — | ⬜ Pending |

## Naming convention

```
UTET/<YEAR>/Paper-<1 ya 2>-SET-<X>/<NN>-<section-name>.md
```

## Source
Official question booklets: **ukutet.com** (Uttarakhand Vidyalayi Shiksha Parishad)
- 2024 Paper I: `https://ukutet.com/API/Notices/utet_I_2024.pdf`
- 2022 Paper I: `https://ukutet.com/API/Notices/utet_I_2022.pdf`
- 2023 Paper I: `https://ukutet.com/API/Notices/utet_I_2023.pdf`
- 2025 Paper I: `https://ukutet.com/API/Notices/UTET_I_2025.pdf`

## Notes
- उर्दू खण्ड शामिल नहीं किया जाता (user की request के अनुसार)।
- Text official PDF se OCR karke manually clean kiya gaya hai; spelling/number errors theek kiye gaye hain.
- Jahan OCR ambiguous tha wahan *टिप्पणी* add ki gayi hai — original PDF se verify kar lena.
